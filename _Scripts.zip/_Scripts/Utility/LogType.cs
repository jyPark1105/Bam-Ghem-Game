// LogType.cs
public enum LogType
{
    Info,
    Warning,
    Error
}