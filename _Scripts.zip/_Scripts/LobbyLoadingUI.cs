﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;

public class LobbyLoadingUI : MonoBehaviour
{
    public static LobbyLoadingUI Instance { get; private set; }

    [Header("UI References")]
    public CanvasGroup loadingCanvasGroup;
    public Image spinner;

    [Header("Animation Settings")]
    public float fadeInDuration = 0.5f;
    public float fadeOutDuration = 1.0f;
    public float spinnerSpeed = 180f;

    private bool isVisible = false;
    private bool isAnimating = false;
    private Transform spinnerTr;

    private float showStartTime;
    private const float MIN_VISIBLE_TIME = 3f;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        //DontDestroyOnLoad(gameObject);

        if (spinner != null)
            spinnerTr = spinner.transform;

        loadingCanvasGroup.alpha = 0f;
        loadingCanvasGroup.blocksRaycasts = false;
        loadingCanvasGroup.interactable = false;
    }

    private void Update()
    {
        if (isVisible && spinnerTr != null)
        {
            spinnerTr.Rotate(Vector3.back * spinnerSpeed * Time.unscaledDeltaTime);
        }
    }

    // =========================
    // 🔹 Show
    // =========================
    public void Show()
    {
        if (isAnimating || isVisible) return;

        showStartTime = Time.unscaledTime;

        StopAllCoroutines();
        StartCoroutine(FadeTo(1f, fadeInDuration, true));
    }

    // =========================
    // 🔹 Hide (3초 보장 + 콜백)
    // =========================
    public void HideAfterMinimum(Action onFadeStart = null)
    {
        if (!isVisible) return;

        float elapsed = Time.unscaledTime - showStartTime;
        float waitTime = Mathf.Max(0f, MIN_VISIBLE_TIME - elapsed);

        StopAllCoroutines();
        StartCoroutine(HideRoutine(waitTime, onFadeStart)); // 🔥 여기 수정됨
    }

    private IEnumerator HideRoutine(float delay, Action onFadeStart)
    {
        if (delay > 0f)
            yield return new WaitForSecondsRealtime(delay);

        // 🔥 FadeOut 시작 직전에 패널 전환
        onFadeStart?.Invoke();

        yield return FadeTo(0f, fadeOutDuration, false);
    }

    private IEnumerator FadeTo(float targetAlpha, float duration, bool show)
    {
        isAnimating = true;

        float startAlpha = loadingCanvasGroup.alpha;
        float t = 0f;

        if (show)
            loadingCanvasGroup.blocksRaycasts = true;

        while (t < duration)
        {
            t += Time.unscaledDeltaTime;
            loadingCanvasGroup.alpha = Mathf.Lerp(startAlpha, targetAlpha, t / duration);
            yield return null;
        }

        loadingCanvasGroup.alpha = targetAlpha;
        isVisible = show;

        if (!show)
            loadingCanvasGroup.blocksRaycasts = false;

        isAnimating = false;
    }
}