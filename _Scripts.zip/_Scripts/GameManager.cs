﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using Firebase.Database;
using Firebase.Auth;
using System;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Stage Data")]
    public int totalStages = 5;
    public List<StageRecord> stages = new List<StageRecord>();

    [Header("Player Currency")]
    public int playerCoin = 0;
    public int playerTrophy = 0;
    public int playerExp = 0;

    public int totalCoin = 0;
    public int totalTrophy = 0;
    public int totalExp = 0;

    private bool firebaseLoaded = false;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            StartCoroutine(LoadUserDataFromFirebase());
        }
        else
        {
            Destroy(gameObject);
        }
    }

#if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void EditorAutoLoad()
    {
        var gm = FindFirstObjectByType<GameManager>();
        if (gm == null)
        {
            var prefab = Resources.Load<GameManager>("GameManager");
            if (prefab != null)
            {
                Instantiate(prefab);
                Debug.Log("[GameManager] Editor auto-created GameManager prefab.");
            }
            else
            {
                Debug.LogWarning("[GameManager] Resources/GameManager.prefab not found!");
            }
        }
    }
#endif

    // ============================================================
    // 🔹 기본 스테이지 초기화 (Firebase 데이터가 없을 때)
    // ============================================================
    private void InitializeStages()
    {
        stages.Clear();
        for (int i = 1; i <= totalStages; i++)
        {
            bool unlocked = (i == 1);
            stages.Add(new StageRecord(i, unlocked));
        }
    }

    // ============================================================
    // 🔹 Firebase에서 유저 스테이지 데이터 불러오기
    // ============================================================
    private IEnumerator LoadUserDataFromFirebase()
    {
        var user = FirebaseAuth.DefaultInstance.CurrentUser;
        if (user == null)
        {
            Debug.LogWarning("[Firebase] No user logged in. Using default stage data.");
            InitializeStages();
            yield break;
        }

        DatabaseReference dbRef = FirebaseDatabase.DefaultInstance
            .RootReference.Child("Users").Child(user.UserId);

        var dataTask = dbRef.Child("stages").GetValueAsync();
        yield return new WaitUntil(() => dataTask.IsCompleted);

        if (dataTask.Exception != null)
        {
            Debug.LogError($"[Firebase] Load failed: {dataTask.Exception.Message}");
            InitializeStages();
            yield break;
        }

        stages.Clear();
        DataSnapshot snapshot = dataTask.Result;

        if (!snapshot.Exists)
        {
            Debug.Log("[Firebase] No stage data found — resetting user as NEW USER.");

            InitializeNewUserData();  // ← 추가할 함수
            yield break;
        }
        else
        {
            foreach (var child in snapshot.Children)
            {
                int stageNum = int.Parse(child.Key);

                bool unlocked = SafeToBool(child.Child("isUnlocked").Value);
                bool cleared = SafeToBool(child.Child("isCleared").Value);
                int stars = SafeToInt(child.Child("starCount").Value);

                int coin = SafeToInt(child.Child("reward/coin").Value);
                int trophy = SafeToInt(child.Child("reward/trophy").Value);
                int exp = SafeToInt(child.Child("reward/exp").Value);

                stages.Add(new StageRecord(stageNum, unlocked)
                {
                    isCleared = cleared,
                    starCount = stars,
                    reward = new RewardData(coin, trophy, exp)
                });
            }

            Debug.Log($"[Firebase] Loaded {stages.Count} stages from database.");
        }

        // 🔹 통화 데이터 로드
        var currencyTask = dbRef.Child("currency").GetValueAsync();
        yield return new WaitUntil(() => currencyTask.IsCompleted);

        if (!currencyTask.IsCompletedSuccessfully || !currencyTask.Result.Exists)
        {
            Debug.Log("[Firebase] No currency data found — resetting to default...");
            totalCoin = 0;
            totalTrophy = 0;
            totalExp = 0;
        }
        else
        {
            totalCoin = SafeToInt(currencyTask.Result.Child("coin").Value);
            totalTrophy = SafeToInt(currencyTask.Result.Child("trophy").Value);
            totalExp = SafeToInt(currencyTask.Result.Child("exp").Value);
        }

        firebaseLoaded = true;
        Debug.Log("[Firebase] All user data loaded successfully.");

        // ✅ UI 자동 갱신 (메인 스레드에서 실행 보장)
        StartCoroutine(DelayedRefreshUI());
    }

    // 새 사용자 초기화 함수
    private void InitializeNewUserData()
    {
        Debug.Log("[GameManager] Initializing NEW USER data...");

        // 🔹 재화 초기화
        totalCoin = 0;
        totalTrophy = 0;
        totalExp = 0;

        // 🔹 스테이지 초기화
        InitializeStages(); // 스테이지 1만 해금, 나머지 잠금

        // 🔹 즉시 Firebase에 초기값 저장 (새 유저의 기본값 생성)
        SaveUserDataToFirebase();
    }

    private IEnumerator DelayedRefreshUI()
    {
        yield return new WaitForSeconds(0.3f); // Firebase 초기 로드 안정 대기
        var loader = FindFirstObjectByType<StagePanelLoader>();
        if (loader != null)
        {
            //loader.LoadStagePanels();
            Debug.Log("[Firebase] StagePanelLoader refreshed after Firebase load.");
        }
        else
        {
            Debug.LogWarning("[Firebase] StagePanelLoader not found at load time — will refresh on scene change.");
        }
    }

    // ============================================================
    // 🔹 스테이지 데이터 관리
    // ============================================================
    public StageRecord GetStageRecord(int stageNumber)
    {
        Debug.Log("GetStageRecord Called");
        return stages.Find(s => s.stageNumber == stageNumber);
    }

    public void UpdateStageClear(
    int stageNumber,
    string difficulty,
    float clearTime,
    int kills,
    int criticalKills,
    int damageDealt,
    RewardData baseReward)
    {
        StageRecord record = GetStageRecord(stageNumber);
        if (record == null) return;

        record.isCleared = true;
        record.lastClearTime = clearTime;
        record.clearTimestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        record.difficulty = difficulty;

        // =============================================
        // 1. 기본 별 계산
        // =============================================
        int baseStar = difficulty switch
        {
            "Easy" => 1,
            "Normal" => 2,
            "Hard" => 3,
            _ => 1
        };

        int finalStar = baseStar;

        // =============================================
        // 2. Best 갱신 체크
        // =============================================
        bool isBest = false;

        if (clearTime < record.bestClearTime)
        {
            record.bestClearTime = clearTime;
            isBest = true;
        }

        if (kills > record.bestKills) { record.bestKills = kills; isBest = true; }
        if (criticalKills > record.bestCriticalKills) { record.bestCriticalKills = criticalKills; isBest = true; }
        if (damageDealt > record.bestDamageDealt) { record.bestDamageDealt = damageDealt; isBest = true; }

        // =============================================
        // 3. Best 달성 시 보정 로직
        // =============================================
        RewardData finalReward = baseReward.Clone();

        if (isBest)
        {
            if (difficulty == "Easy" || difficulty == "Normal")
            {
                finalStar = Mathf.Min(baseStar + 1, 3);
            }
            else if (difficulty == "Hard")
            {
                finalStar = 3;
                finalReward.Multiply(3);   // ★ 보상 3배
            }
        }

        record.starCount = Mathf.Max(record.starCount, finalStar);

        // =============================================
        // 4. 플레이어 재화 지급
        // =============================================
        playerCoin += finalReward.coin;
        playerTrophy += finalReward.trophy;
        playerExp += finalReward.exp;

        // TODO: 여기서 레벨업 처리 가능

        // =============================================
        // 5. 다음 스테이지 해금
        // =============================================
        int next = stageNumber + 1;
        if (next <= totalStages)
        {
            StageRecord nextRecord = GetStageRecord(next);
            if (nextRecord != null && !nextRecord.isUnlocked)
                nextRecord.isUnlocked = true;
        }

        // =============================================
        // 6. Firebase 저장
        // =============================================
        SaveUserDataToFirebase();

        // =============================================
        // 7. UI 갱신
        // =============================================
        //var loader = FindFirstObjectByType<StagePanelLoader>();
        //if (loader != null) loader.LoadStagePanels();

        Debug.Log($"[GameManager] Stage {stageNumber} Clear! star={finalStar} reward x{(isBest && difficulty == "Hard" ? "3" : "1")}");
    }

    // ============================================================
    // 🔹 씬 로드
    // ============================================================
    public void LoadStage(string stageName)
    {
        StartCoroutine(LoadStageRoutine(stageName));
    }

    private IEnumerator LoadStageRoutine(string stageName)
    {
        AsyncOperation async = SceneManager.LoadSceneAsync(stageName, LoadSceneMode.Additive);
        while (!async.isDone)
            yield return null;
    }

    // ============================================================
    // 🔹 Firebase 저장
    // ============================================================
    public void SaveUserDataToFirebase()
    {
        var user = FirebaseAuth.DefaultInstance.CurrentUser;
        if (user == null)
        {
            Debug.LogWarning("[Firebase] SaveUserDataToFirebase: No current user!");
            return;
        }

        DatabaseReference dbRef = FirebaseDatabase.DefaultInstance
            .RootReference.Child("Users").Child(user.UserId);

        // 🔹 재화 저장
        var currencyRef = dbRef.Child("currency");
        currencyRef.Child("coin").SetValueAsync(totalCoin);
        currencyRef.Child("trophy").SetValueAsync(totalTrophy);
        currencyRef.Child("exp").SetValueAsync(totalExp);

        // 🔹 스테이지 데이터 저장
        var stagesRef = dbRef.Child("stages");
        foreach (var record in stages)
        {
            var stageRef = stagesRef.Child(record.stageNumber.ToString());
            stageRef.Child("isUnlocked").SetValueAsync(record.isUnlocked);
            stageRef.Child("isCleared").SetValueAsync(record.isCleared);
            stageRef.Child("starCount").SetValueAsync(record.starCount);
            stageRef.Child("reward/coin").SetValueAsync(record.reward.coin);
            stageRef.Child("reward/trophy").SetValueAsync(record.reward.trophy);
            stageRef.Child("reward/exp").SetValueAsync(record.reward.exp);
        }

        Debug.Log("[Firebase] User data successfully saved.");
    }

    // ============================================================
    // 🔹 안전 변환 함수들 (Firebase Value → C# 타입)
    // ============================================================
    private bool SafeToBool(object value)
    {
        if (value == null) return false;
        if (value is bool b) return b;
        if (bool.TryParse(value.ToString(), out bool result)) return result;
        return false;
    }

    private int SafeToInt(object value)
    {
        if (value == null) return 0;
        if (int.TryParse(value.ToString(), out int result)) return result;
        return 0;
    }
}