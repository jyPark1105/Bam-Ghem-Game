using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class LogPanel : MonoBehaviour
{
    public static LogPanel Instance { get; private set; }

    [SerializeField] private CanvasGroup canvasGroup;
    [SerializeField] private GameObject showLogButton;

    [Header("UI References")]
    public ScrollRect scrollRect;
    public Transform content;
    public GameObject logItemPrefab;

    private class LogEntry
    {
        public string message;
        public int count;
        public TMP_Text textComponent;
        public Image statusImage;
    }

    private List<LogEntry> logEntries = new List<LogEntry>();
    public int maxLogs = 50;

    private Sprite warningSprite;
    private Sprite errorSprite;
    private Sprite infoSprite;

    public void SetLogPanelAlpha(GameObject target, float a)
    {
        if (!target.activeSelf)
            target.SetActive(true);

        if (target == null)
            return;

        target.GetComponent<CanvasGroup>().alpha = a;

        // �α� ���� �� ��Ȱ��ȭ
        if (a == 1.0f)
            target.SetActive(false);
    }

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;

            // Root�� �ƴϸ� �θ�(Canvas)�� ����
            var root = transform.root.gameObject;
            DontDestroyOnLoad(root);
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        warningSprite = Resources.Load<Sprite>("LogStatus/Warning");
        errorSprite = Resources.Load<Sprite>("LogStatus/Error");
        infoSprite = Resources.Load<Sprite>("LogStatus/Info");

#if UNITY_EDITOR

        if (canvasGroup != null)
        {
            canvasGroup.alpha = 1f;
            canvasGroup.interactable = true;
            canvasGroup.blocksRaycasts = true;
        }

        if (showLogButton != null)
            showLogButton.SetActive(true);

#else

        if (canvasGroup != null)
        {
            canvasGroup.alpha = 0f;
            canvasGroup.interactable = false;
            canvasGroup.blocksRaycasts = false;
        }

        if (showLogButton != null)
            showLogButton.SetActive(false);

#endif
    }

    // �α� �г� ��� �Լ�
    public void ToggleLogPanel()
    {
        if (canvasGroup == null) return;

        bool visible = canvasGroup.alpha > 0.5f;

        canvasGroup.alpha = visible ? 0f : 1f;
        canvasGroup.interactable = !visible;
        canvasGroup.blocksRaycasts = !visible;
    }

    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public static void Log(string message, LogType type)
    {
        if (Instance == null) return;
        Instance.AddOrUpdateLog(message, type);
    }

    private void AddOrUpdateLog(string message, LogType type)
    {
#if UNITY_EDITOR
        // ���� �α� ã��
        var existingEntry = logEntries.Find(entry => entry.message == message);
        if (existingEntry != null)
        {
            existingEntry.count++;

            Transform countFrame = existingEntry.textComponent.transform.parent.Find("LogCountFrame");
            if (countFrame != null)
            {
                TMP_Text countText = countFrame.Find("LogCount").GetComponent<TMP_Text>();
                countFrame.gameObject.SetActive(true);

                countText.text = existingEntry.count.ToString();

                float rt_size = existingEntry.count >= 100 ? 40f : 35f;
                ChangeLogCountSize(countFrame, rt_size);

                float ft_size = existingEntry.count >= 100 ? 14f :
                                existingEntry.count >= 10 ? 16f : 18f;
                countText.fontSize = ft_size;
            }

            existingEntry.textComponent.text = existingEntry.message;
            return;
        }

        // �� �α� ����
        GameObject newLog = Instantiate(logItemPrefab, content, false);
        TMP_Text textComponent = newLog.transform.Find("LogText").GetComponent<TMP_Text>();
        Image statusImage = newLog.transform.Find("LogStatusImage").GetComponent<Image>();
        textComponent.text = message;

        // Ÿ�Ժ� ��������Ʈ ����
        switch (type)
        {
            case LogType.Warning:
                statusImage.sprite = warningSprite;
                break;
            case LogType.Error:
                statusImage.sprite = errorSprite;
                break;
            default:
                statusImage.sprite = infoSprite;
                break;
        }

        Transform countFrameNew = newLog.transform.Find("LogCountFrame");
        if (countFrameNew != null)
            countFrameNew.gameObject.SetActive(false);

        logEntries.Add(new LogEntry
        {
            message = message,
            count = 1,
            textComponent = textComponent,
            statusImage = statusImage
        });

        if (logEntries.Count > maxLogs)
        {
            Destroy(logEntries[0].textComponent.gameObject);
            logEntries.RemoveAt(0);
        }

        Canvas.ForceUpdateCanvases();
        scrollRect.verticalNormalizedPosition = 0f;
#endif
    }

    private void ChangeLogCountSize(Transform countFrame, float size)
    {
        RectTransform rect = countFrame.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(size, size);
    }
}