﻿using UnityEngine;
using TMPro;

public class StatusTextUI : MonoBehaviour
{
    public static StatusTextUI Instance { get; private set; }

    [Header("Status UI")]
    [SerializeField] public TMP_Text statusText;

    private void Awake()
    {
        // ✅ 싱글턴 보장
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        // ✅ 자동 할당 보조
        if (statusText == null)
        {
            statusText = GetComponentInChildren<TMP_Text>(true);
            if (statusText == null)
                Debug.LogError("[StatusUI] TMP_Text component not found in children!");
        }
    }

    private void Start()
    {
        // ✅ 초기 상태 정리
        ClearStatus();
    }

    /// <summary>
    /// 상태 메시지 즉시 표시
    /// </summary>
    public void UpdateStatus(string message)
    {
        // ✅ 안전 가드 (씬 전환 중 파괴된 경우 방지)
        if (this == null || gameObject == null)
        {
            Debug.LogWarning("[StatusUI] Object was destroyed, skipping UpdateStatus.");
            return;
        }

        if (Instance == null)
        {
            Debug.LogWarning("[StatusUI] Instance is null! (Auto-recovery attempt)");
            return;
        }

        if (statusText == null)
        {
            statusText = GetComponentInChildren<TMP_Text>(true);
            if (statusText == null)
            {
                Debug.LogError("[StatusUI] No TMP_Text assigned or found!");
                return;
            }
        }

        statusText.text = message;
    }

    /// <summary>
    /// 일정 시간 뒤 자동으로 사라지는 메시지
    /// </summary>
    public void ShowTemporary(string message, float duration = 2f)
    {
        UpdateStatus(message);
        CancelInvoke(nameof(ClearStatus));
        Invoke(nameof(ClearStatus), duration);
    }

    /// <summary>
    /// 상태 텍스트 초기화
    /// </summary>
    public void ClearStatus()
    {
        if (statusText != null)
            statusText.text = "";
    }
}