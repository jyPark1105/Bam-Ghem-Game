﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class LoadingUI : MonoBehaviour
{
    public static LoadingUI Instance { get; private set; }

    [Header("UI References")]
    public CanvasGroup loadingCanvasGroup;
    public Image spinner;
    public Image progressBar;
    public TMP_Text progressText;
    public TMP_Text loadingStatusText;

    [Header("Animation Settings")]
    public float fadeDuration = 1.2f;
    public float spinnerSpeed = 180f;

    private float currentProgress = 0f;
    private bool isShowing = false;
    private bool isFading = false;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        HideInstant();
    }

    private void Update()
    {
        if (isShowing && spinner != null)
            spinner.transform.Rotate(Vector3.back * spinnerSpeed * Time.deltaTime);
    }

    public void Show()
    {
        StopAllCoroutines();

        if (loadingCanvasGroup != null)
        {
            loadingCanvasGroup.alpha = 1f;
            loadingCanvasGroup.interactable = true;
            loadingCanvasGroup.blocksRaycasts = true;
        }

        isShowing = true;
        isFading = false;
        currentProgress = 0f;

        if (progressBar != null)
            progressBar.fillAmount = 0f;

        if (progressText != null)
            progressText.text = "0%";

        if (loadingStatusText != null)
            loadingStatusText.text = "Firebase 초기화 중입니다...";
    }

    public void SetProgress(float percent, string message = "")
    {
        percent = Mathf.Clamp01(percent);
        currentProgress = percent;

        if (progressBar != null)
            progressBar.fillAmount = currentProgress;

        if (progressText != null)
            progressText.text = Mathf.RoundToInt(currentProgress * 100f) + "%";

        if (!string.IsNullOrEmpty(message) && loadingStatusText != null)
            loadingStatusText.text = message;
    }

    public void Hide()
    {
        if (!isShowing || isFading)
            return;

        StartCoroutine(FadeOutCoroutine());
    }

    private void HideInstant()
    {
        if (loadingCanvasGroup != null)
        {
            loadingCanvasGroup.alpha = 0f;
            loadingCanvasGroup.interactable = false;
            loadingCanvasGroup.blocksRaycasts = false;
        }

        isShowing = false;
        isFading = false;
    }

    private IEnumerator FadeOutCoroutine()
    {
        isFading = true;

        if (loadingStatusText != null)
            loadingStatusText.text = "로딩 완료!";

        if (progressText != null)
            progressText.text = "100%";

        if (progressBar != null)
            progressBar.fillAmount = 1f;

        UIManager.Instance?.ShowLoginSelectionPanel();

        float elapsed = 0f;
        float startAlpha = loadingCanvasGroup != null ? loadingCanvasGroup.alpha : 1f;

        while (elapsed < fadeDuration)
        {
            elapsed += Time.deltaTime;

            if (loadingCanvasGroup != null)
                loadingCanvasGroup.alpha = Mathf.Lerp(startAlpha, 0f, elapsed / fadeDuration);

            yield return null;
        }

        if (loadingCanvasGroup != null)
        {
            loadingCanvasGroup.alpha = 0f;
            loadingCanvasGroup.interactable = false;
            loadingCanvasGroup.blocksRaycasts = false;
        }

        isShowing = false;
        isFading = false;

        if (LogPanel.Instance != null)
            LogPanel.Instance.SetLogPanelAlpha(LogPanel.Instance.gameObject, 1.0f);

        LobbyBGM_Player.Instance?.PlayAuthLobby();
    }
}