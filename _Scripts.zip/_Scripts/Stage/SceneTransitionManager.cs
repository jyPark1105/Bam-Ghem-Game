﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using UnityEngine.InputSystem;

public class SceneTransitionManager : MonoBehaviour
{
    public static SceneTransitionManager Instance { get; private set; }

    private StarterAssets.ThirdPersonController cachedPlayer;

    private bool _isReturning = false; // 🔒 중복 Return 방지

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    // Player 등록용 API 추가
    public void RegisterPlayer(StarterAssets.ThirdPersonController player)
    {
        if (player == null) return;

        cachedPlayer = player;
        Debug.Log("[SceneTransition] Player registered");
    }

    public void UnregisterPlayer(StarterAssets.ThirdPersonController player)
    {
        if (cachedPlayer == player)
            cachedPlayer = null;
    }

    // =====================================================
    // 🔥 Lobby → Stage (단순 / 확정 버전)
    // =====================================================
    public void LoadStage(int stageNumber, string difficulty)
    {
        StageManager.Instance.SetDifficulty(difficulty);
        StartCoroutine(LoadStageRoutine(stageNumber));
    }

    private IEnumerator LoadStageRoutine(int stageNumber)
    {
        // 🔥 로비 브금 정지
        LobbyBGM_Player.Instance?.Stop();

        string loading = "LoadingScene";
        string stage = $"Stage_{stageNumber:D2}";

        SceneTrace.Instance?.Dump($"LOAD_STAGE start target={stage}");

        const float MIN_LOADING_TIME = 7f;

        float loadingStartTime = Time.time;

        // =====================================================
        // 🔥 0️⃣ PersistentMap 먼저 차단 (B 로드 직전)
        // =====================================================
        if (PersistentMapController.Instance != null)
        {
            PersistentMapController.Instance.SetActive(false);
            Debug.Log("[SceneTransition] PersistentMap disabled BEFORE loading scene.");
        }

        // =====================================================
        // 1️⃣ LoadingScene 로드
        // =====================================================
        yield return SceneManager.LoadSceneAsync(loading, LoadSceneMode.Additive);

        Scene loadingScene = SceneManager.GetSceneByName(loading);
        SceneManager.SetActiveScene(loadingScene);

        SceneTrace.Instance?.Dump("after load LoadingScene");

        // =====================================================
        // 2️⃣ Stage 백그라운드 로딩
        // =====================================================
        AsyncOperation stageLoadOp =
            SceneManager.LoadSceneAsync(stage, LoadSceneMode.Additive);

        stageLoadOp.allowSceneActivation = false;

        while (stageLoadOp.progress < 0.9f)
        {
            yield return null;
        }

        // =====================================================
        // 3️⃣ 최소 7초 보장
        // =====================================================
        while (Time.time - loadingStartTime < MIN_LOADING_TIME)
        {
            yield return null;
        }

        // =====================================================
        // 4️⃣ Stage 활성화
        // =====================================================
        stageLoadOp.allowSceneActivation = true;

        while (!stageLoadOp.isDone)
        {
            yield return null;
        }

        SceneManager.SetActiveScene(SceneManager.GetSceneByName(stage));
        SceneTrace.Instance?.Dump("after active=Stage");

        // =====================================================
        // 5️⃣ Persistent UI 입력 차단
        // =====================================================
        PersistentUIRoot.Instance?.LockUI();
        LobbyUIRootBlocker.Instance?.BlockForStage();

        // =====================================================
        // 6️⃣ LoadingScene 언로드
        // =====================================================
        yield return SceneManager.UnloadSceneAsync(loading);
        SceneTrace.Instance?.Dump("after unload LoadingScene");

        // =====================================================
        // 7️⃣ Stage 초기 로직
        // =====================================================
        yield return null;

        if (ChatManager.Instance != null)
        {
            ChatManager.Instance.StartDialogue();
            Debug.Log("[SceneTransition] Chat dialogue started safely.");
        }

        // =====================================================
        // 8️⃣ 카메라 복구
        // =====================================================
        yield return null;

        Camera cam = Camera.main;
        if (cam != null)
        {
            var aspect = cam.GetComponent<FixedAspectRatio>();
            if (aspect != null)
            {
                aspect.EnableLetterbox(false);
                Debug.Log("[Aspect] Letterbox disabled for Stage");
            }
        }

        // =====================================================
        // 9️⃣ 입력 복구
        // =====================================================
        yield return null;
        ForceRestoreInputAfterStageLoad();

        Debug.Log($"[SceneTransition] Stage {stageNumber} entered cleanly");
    }

    private void ForceRestoreInputAfterStageLoad()
    {
        if (cachedPlayer == null)
        {
            Debug.LogWarning("[SceneTransition] Cached Player is null");
            return;
        }

        cachedPlayer.SetBusy(false);
        cachedPlayer.EnableAllInputs();

#if ENABLE_INPUT_SYSTEM
        var input = cachedPlayer.GetComponent<PlayerInput>();
        if (input != null && !input.enabled)
        {
            input.enabled = true;
            Debug.Log("[SceneTransition] PlayerInput re-enabled");
        }

        InputSystem.ResetHaptics();
#endif

        Debug.Log("🔥 ForceRestoreInputAfterStageLoad DONE (cached)");
    }

    // =====================================================
    // 🔥 Stage → Lobby
    // =====================================================
    public void ReturnToLobby()
    {
        if (_isReturning)
        {
            Debug.LogWarning("[SceneTransition] ReturnToLobby ignored (already returning)");
            return;
        }

        _isReturning = true;
        StartCoroutine(ReturnToLobbyRoutine());
    }

    /// <summary>
    /// Stage 내부 → 로비로의 안전한 복귀 작업(중간에 가벼운 로딩 씬을 거쳐감으로써 메모리 소모를 줄이는 방식을 택함)
    /// </summary>
    /// <returns></returns>
    private IEnumerator ReturnToLobbyRoutine()
    {
        string loading = "LoadingScene";
        string persistent = "PersistentScene";

        Scene activeScene = SceneManager.GetActiveScene();
        SceneTrace.Instance?.Dump($"RETURN start activeScene={activeScene.name}");

        // 1. B 로드(Scene: B+C)
        yield return SceneManager.LoadSceneAsync(loading, LoadSceneMode.Additive);
        SceneTrace.Instance?.Dump("after load B (C+B expected)");

        // 2. Active = B(Scene: B+C)
        Scene loadingScene = SceneManager.GetSceneByName(loading);
        SceneManager.SetActiveScene(loadingScene);
        SceneTrace.Instance?.Dump("after active=B");
        yield return null;

        // 3. C 언로드(Scene: B)
        if (activeScene.isLoaded && activeScene.name.StartsWith("Stage_"))
            yield return SceneManager.UnloadSceneAsync(activeScene);

        SceneTrace.Instance?.Dump("after unload C (B expected)");

        // 4. A 로드(Scene: A+B)
        if (!SceneManager.GetSceneByName(persistent).isLoaded)
            yield return SceneManager.LoadSceneAsync(persistent, LoadSceneMode.Additive);

        SceneTrace.Instance?.Dump("after load A (B+A expected)");

        // 5. Active = A(Scene: A+B)
        SceneManager.SetActiveScene(SceneManager.GetSceneByName(persistent));
        SceneTrace.Instance?.Dump("after active=A");
        yield return null;

        // 카메라 원복
        Camera cam = PersistentCameraProvider.Main;
        if (cam != null)
        {
            var aspect = cam.GetComponent<FixedAspectRatio>();
            if (aspect != null)
            {
                aspect.EnableLetterbox(true); // 🔒 Lobby는 16:9 고정
                Debug.Log("[Aspect] Letterbox restored for Lobby");
            }
        }

        // 6. UI 복구
        UIManager.Instance?.SafeShowMainPanel();

        // 🔥 여기 추가
        if (PersistentMapController.Instance != null)
        {
            PersistentMapController.Instance.SetActive(false);
        }

        // Lobby 복귀 시
        LobbyUIRootBlocker.Instance?.RestoreForLobby();
        // 🔓🔥 Persistent UI 입력 복구 (추가)
        PersistentUIRoot.Instance?.UnlockUI();

        // 7. B 언로드(Scene: A)
        yield return SceneManager.UnloadSceneAsync(loading);
        SceneTrace.Instance?.Dump("after unload B (A expected)");

        // 🔓 복귀 완료 → 플래그 해제
        _isReturning = false;

        Debug.Log("[SceneTransition] Returned to Lobby cleanly");
    }
}