﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

public class StageManager : MonoBehaviour
{
    public static StageManager Instance { get; private set; }

    // ============================================================
    // 🔥 몬스터 타입별 전투 기록 저장 구조
    // ============================================================
    private class MonsterStatsRuntime
    {
        public int total = 0;
        public int killed = 0;
        public int criticalKilled = 0;
        public int totalMonsterKilled = 0;
        public int totalMonsterCriticalKilled = 0;
        public int attackCount = 0;
        public int extinctionCount = 0;
    }

#if UNITY_EDITOR
    [Header("Editor Auto-Init")]
    public bool autoInitInEditor = true;
    public int editorStageNumber = 1;
    public string editorDifficulty = "Beginner";
#endif

    [Header("Clear Conditions (Difficulty별 필요 처치 수)")]
    public int beginner_Slime = 3;
    public int beginner_Turtle = 1;

    public int expert_Slime = 8;
    public int expert_Turtle = 3;

    private Dictionary<EnemyAI.MonsterType, MonsterStatsRuntime> monsterStatsDict =
        new Dictionary<EnemyAI.MonsterType, MonsterStatsRuntime>();

    // ============================================================
    // 🔥 플레이어 전투 기록
    // ============================================================
    private int damageTaken = 0;
    private int damageDealt = 0;

    private float stageTimer = 0f;  
    private float stageTimeLimit = 0f;
    private bool isStageRunning = false;

    // ============================================================
    // 🔥 흡수 관련
    // ============================================================
    private string absorbedElement = "None";
    private int absorbedCount = 0;

    // ============================================================
    // 🔥 스킬 사용 횟수
    // ============================================================
    private int useAttack = 0;
    private int useAttackSlash = 0;
    private int useSkillA = 0;
    private int useClimb = 0;
    private int useDodge = 0;
    private int useJump = 0;
    private int useGetItem = 0;

    // ============================================================
    // 🔥 상태 정보
    // ============================================================
    private string selectedDifficulty = "Beginner";
    private int currentStageNumber = -1;
    public int CurrentStageNumber => currentStageNumber;
    private bool isStageLoaded = false;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    void Update()
    {
        if (!isStageRunning) return;

        stageTimer += Time.deltaTime;
    }

#if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void EditorAutoLoad()
    {
        // 🚀 최신 Unity API로 변경 (FindObjectOfType deprecated)
        var existing = Object.FindFirstObjectByType<StageManager>();

        if (existing == null)
        {
            var prefab = Resources.Load<StageManager>("StageManager");
            if (prefab != null)
            {
                StageManager instance = GameObject.Instantiate(prefab);
                Debug.Log("[StageManager] Editor auto-created StageManager instance.");
            }
            else
            {
                Debug.LogWarning("[StageManager] Resources/StageManager.prefab 을 찾을 수 없습니다!");
            }
        }
    }
#endif

    // ============================================================
    // 🔥 스테이지 난이도 선택
    // ============================================================
    public void SetDifficulty(string difficulty)
    {
        selectedDifficulty = difficulty;
        DebugManager.Log($"[StageManager] Difficulty set to {difficulty}");
    }

    public string GetDifficulty()
    {
        if (selectedDifficulty == null)
            selectedDifficulty = "Beginner";

        return selectedDifficulty;
    }

    public int ConvertDifficulty2Int(string difficulty)
    {
        switch(selectedDifficulty)
        {
            case "Beginner":
                return 1;
            case "Expert":
                return 3;
            default:
                return 0;
        }
    }

    // ============================================================
    // 🔥 스테이지 초기화
    // ============================================================
    public void InitStageData(float stageLimitTime, string difficulty)
    {
        // 몬스터 딕셔너리 초기화
        monsterStatsDict.Clear();
        foreach (EnemyAI.MonsterType type in System.Enum.GetValues(typeof(EnemyAI.MonsterType)))
            monsterStatsDict[type] = new MonsterStatsRuntime();

        // 플레이어 정보 초기화
        damageTaken = 0;
        damageDealt = 0;

        absorbedElement = "None";
        absorbedCount = 0;

        useAttack = 0;
        useAttackSlash = 0;
        useSkillA = 0;
        useClimb = 0;
        useDodge = 0;
        useJump = 0;
        useGetItem = 0;

        // 타이머
        stageTimer = 0f;
        stageTimeLimit = stageLimitTime;

        selectedDifficulty = difficulty;
        isStageRunning = true;
    }

    // ============================================================
    // 🔥 스테이지 로드
    // ============================================================
    public void LoadStage(int stageNumber)
    {
        if (isStageLoaded) return;

        string sceneName = $"Stage_{stageNumber:D2}";

        StartCoroutine(LoadStageRoutine(sceneName, stageNumber));
    }

    private IEnumerator LoadStageRoutine(string sceneName, int stageNumber)
    {
        var asyncLoad = SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Additive);
        while (!asyncLoad.isDone)
            yield return null;

        isStageLoaded = true;
        currentStageNumber = stageNumber;

        UIManager.Instance?.HideMainPanel();
    }

    // ============================================================
    // 🔥 몬스터 이벤트 기록
    // ============================================================
    public void OnMonsterSpawned(EnemyAI.MonsterType type)
    {
        monsterStatsDict[type].total++;
    }

    public void OnMonsterKilled(EnemyAI.MonsterType type, bool isCritical)
    {
        monsterStatsDict[type].killed++;

        StageLogPanel.Log(
            $"현재까지 {type}을 {monsterStatsDict[type].killed}마리 처치하였습니다!",
            LogType.Info
        );

        if (isCritical)
            monsterStatsDict[type].criticalKilled++;

        // 🔥 여기서 클리어 조건 검사!
        CheckStageClearCondition();
    }

    private void CheckStageClearCondition()
    {
        const int REQUIRED_KILL = 10;

        bool isClear =
            monsterStatsDict[EnemyAI.MonsterType.Slime].killed >= REQUIRED_KILL &&
            monsterStatsDict[EnemyAI.MonsterType.TurtleShell].killed >= REQUIRED_KILL &&
            monsterStatsDict[EnemyAI.MonsterType.Cactus].killed >= REQUIRED_KILL &&
            monsterStatsDict[EnemyAI.MonsterType.Beholder].killed >= REQUIRED_KILL;

        if (isClear)
        {
            StageLogPanel.Log("🎉 모든 몬스터를 10마리씩 처치했습니다! 스테이지 클리어!");
            FinishStage(true);
        }
    }

    public void OnMonsterAttack(EnemyAI.MonsterType type)
    {
        monsterStatsDict[type].attackCount++;
    }

    public void OnMonsterExtinction(EnemyAI.MonsterType type)
    {
        monsterStatsDict[type].extinctionCount++;

        StageLogPanel.Log(
            $"현재까지 {type}이 {monsterStatsDict[type].extinctionCount}마리 소멸되었습니다!",
            LogType.Info
        );
    }

    // ============================================================
    // 🔥 플레이어 데이터 기록
    // ============================================================
    public void OnDamageTaken(int amount) => damageTaken += amount;
    public void OnDamageDealt(int amount) => damageDealt += amount;
    public void OnAbsorb(string element)
    {
        absorbedElement = element;
        absorbedCount++;
    }

    public void OnSkillUsed(string skill)
    {
        switch (skill)
        {
            case "Attack": useAttack++; break;
            case "AttackSlash": useAttackSlash++; break;
            case "SkillA": useSkillA++; break;
            case "Climb": useClimb++; break;
            case "Dodge": useDodge++; break;
            case "Jump": useJump++; break;
            case "GetItem": useGetItem++; break;
        }
    }

    // ============================================================
    // 🔥 결과 데이터 패킹
    // ============================================================
    private StageResultData BuildResultData(bool isClear)
    {
        StageResultData result = new StageResultData();

        result.stageNumber = currentStageNumber;
        result.difficulty = selectedDifficulty;
        result.starCount = ConvertDifficulty2Int(selectedDifficulty);
        result.isClear = isClear;

        result.clearTime = stageTimer;
        result.totalStageTime = stageTimeLimit;

        // 🔥 몬스터 타입별 데이터 저장
        foreach (var kvp in monsterStatsDict)
        {
            EnemyAI.MonsterType type = kvp.Key;
            var src = kvp.Value;
            
            result.monsterResults[type] = new MonsterResult
            {
                total = src.total,
                killed = src.killed,
                criticalKilled = src.criticalKilled,
                attackCount = src.attackCount,
                extinctionCount = src.extinctionCount
            };
        }

        // 피해 정보
        result.damageTaken = damageTaken;
        result.damageDealt = damageDealt;

        // 전체 처치(크리티컬) 정보
        result.totalKills = 0;
        result.totalCriticalKills = 0;

        foreach (var kvp in monsterStatsDict)
        {
            result.totalKills += kvp.Value.killed;
            result.totalCriticalKills += kvp.Value.criticalKilled;
        }

        // 스킬 정보
        result.useSkillAttack = useAttack;
        result.useSkillAttackSlash = useAttackSlash;
        result.useSkillSkillA = useSkillA;
        result.useSkillClimb = useClimb;
        result.useSkillDodge = useDodge;
        result.useSkillJump = useJump;
        result.useSkillGetItem = useGetItem;

        // 흡수
        result.absorbedElement = absorbedElement;
        result.absorbedCount = absorbedCount;

        // ============================================================
        // 🔥🔥🔥 Reward 계산 구간 추가
        // ============================================================
        /*
        int totalKills = 0;
        int totalCritKills = 0;

        foreach (var kvp in monsterStatsDict)
        {
            totalKills += kvp.Value.killed;
            totalCritKills += kvp.Value.criticalKilled;
        }
        */

        // 기본 보상 생성 (기본값 0이면 절대 Null 안 생김)
        result.rewardBase = new RewardData(
            coin: result.totalKills * 10,       // 킬마다 코인 +10
            exp: result.totalKills * 3,         // 킬마다 exp +3
            trophy: result.totalCriticalKills * 1   // 크리티컬 킬마다 트로피 +1
        );

        // 난이도 배수
        float multiplier = 1f;
        switch (selectedDifficulty)
        {
            case "Normal": multiplier = 1.2f; break;
            case "Hard": multiplier = 1.5f; break;
        }

        result.rewardFinal = new RewardData(
            coin: Mathf.RoundToInt(result.rewardBase.coin * multiplier),
            exp: Mathf.RoundToInt(result.rewardBase.exp * multiplier),
            trophy: result.rewardBase.trophy
        );

        return result;
    }

    // ============================================================
    // 🔥 스테이지 종료
    // ============================================================
    public void FinishStage(bool isClear)
    {
        isStageRunning = false;

        // 🔥 Stage 씬 먼저 멈추기
        SetStageSceneActive(false);

        StageResultData result = BuildResultData(isClear);

        // UI만 표시. 언로드는 ConfirmButton 클릭 시 실행됨
        StageResultPanel.Instance.Show(result);
        // Show 함수가 오류나면 제발 StageResultPanel 루트가 꺼져있는지 확인할 것.
        // Show 함수가 실행되기 위해 루트만 키고 차일드(Panel) 오브젝트 끄기.

        // 클리어 시 기록 저장
        if (isClear)
            SendToGameManager(result);
    }

    private void SetStageSceneActive(bool active)
    {
        if (currentStageNumber < 0) return;

        var scene = SceneManager.GetSceneByName($"Stage_{currentStageNumber:D2}");
        if (!scene.isLoaded) return;

        foreach (var root in scene.GetRootGameObjects())
            root.SetActive(active);
    }

    public void OnResultConfirmed()
    {
        // 🔥 씬 전환은 전부 SceneTransitionManager에게 위임
        SceneTransitionManager.Instance.ReturnToLobby();
    }

    private void SendToGameManager(StageResultData result)
    {
        // 기본 보상 (없으면 0으로 생성)
        RewardData baseReward =
            result.rewardBase != null ? result.rewardBase : new RewardData(0, 0, 0);

        // 🔥 몬스터 전체 킬/크리티컬 킬 계산
        int totalKills = 0;
        int totalCriticalKills = 0;

        foreach (var kvp in result.monsterResults)
        {
            totalKills += kvp.Value.killed;
            totalCriticalKills += kvp.Value.criticalKilled;
        }

        GameManager.Instance.UpdateStageClear(
            result.stageNumber,
            result.difficulty,
            result.clearTime,
            totalKills,
            totalCriticalKills,
            result.damageDealt,
            baseReward
        );
    }

    // ============================================================
    // 🔥 스테이지 언로드
    // ============================================================
    private IEnumerator UnloadStageRoutine(int stageNumber)
    {
        string sceneName = $"Stage_{stageNumber:D2}";

        var asyncUnload = SceneManager.UnloadSceneAsync(sceneName);
        while (!asyncUnload.isDone)
            yield return null;

        isStageLoaded = false;
        currentStageNumber = -1;

        UIManager.Instance?.SafeShowMainPanel();
    }
}