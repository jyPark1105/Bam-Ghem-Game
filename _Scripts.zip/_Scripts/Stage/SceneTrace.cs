using UnityEngine;
using UnityEngine.SceneManagement;
using System.Text;

public class SceneTrace : MonoBehaviour
{
    public static SceneTrace Instance { get; private set; }

    private void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        SceneManager.sceneLoaded += OnSceneLoaded;
        SceneManager.sceneUnloaded += OnSceneUnloaded;
        SceneManager.activeSceneChanged += OnActiveSceneChanged;

        Dump("BOOT");
    }

    private void OnDestroy()
    {
        if (Instance != this) return;
        SceneManager.sceneLoaded -= OnSceneLoaded;
        SceneManager.sceneUnloaded -= OnSceneUnloaded;
        SceneManager.activeSceneChanged -= OnActiveSceneChanged;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        Dump($"sceneLoaded: {scene.name} mode={mode}");
    }

    private void OnSceneUnloaded(Scene scene)
    {
        Dump($"sceneUnloaded: {scene.name}");
    }

    private void OnActiveSceneChanged(Scene oldScene, Scene newScene)
    {
        Dump($"activeSceneChanged: {oldScene.name} -> {newScene.name}");
    }

    public void Dump(string reason)
    {
        var sb = new StringBuilder();
        sb.Append($"[SCENETRACE] {reason} | Active={SceneManager.GetActiveScene().name} | Loaded(");

        int count = SceneManager.sceneCount;
        sb.Append(count);
        sb.Append("): ");

        for (int i = 0; i < count; i++)
        {
            var s = SceneManager.GetSceneAt(i);
            sb.Append(s.name);
            sb.Append(s.isLoaded ? "[L]" : "[?]");
            if (i < count - 1) sb.Append(", ");
        }

        Debug.Log(sb.ToString());
    }
}
