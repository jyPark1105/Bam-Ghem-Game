﻿using UnityEngine;

public class PersistentUIRoot : MonoBehaviour
{
    public static PersistentUIRoot Instance { get; private set; }

    private CanvasGroup cg;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        cg = GetComponent<CanvasGroup>();
        if (cg == null)
            cg = gameObject.AddComponent<CanvasGroup>();
    }

    public void LockUI()
    {
        cg.alpha = 0f;
        cg.interactable = false;
        cg.blocksRaycasts = false;

        Debug.Log("🔒 PersistentUIRoot LockUI");
    }

    public void UnlockUI()
    {
        cg.alpha = 1f;
        cg.interactable = true;
        cg.blocksRaycasts = true;

        Debug.Log("🔓 PersistentUIRoot UnlockUI");
    }
}