﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ClickCursorController : MonoBehaviour
{
    public static ClickCursorController Instance;

    [Header("UI")]
    public RectTransform cursorRect;
    public Image cursorImage;

    [Header("Animation")]
    public float animDuration = 0.15f;
    public float scaleUp = 1.1f;

    [Header("Lifetime")]
    public float hideDelay = 3f; // 🔥 3초 유지

    private Coroutine animRoutine;
    private Coroutine hideRoutine;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        //DontDestroyOnLoad(gameObject);

        cursorRect.localScale = Vector3.one;
        cursorImage.enabled = false;
    }

    private void Update()
    {
#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetMouseButtonDown(0))
            ShowAt(Input.mousePosition);
#endif

#if UNITY_ANDROID
        if (Input.touchCount > 0 &&
            Input.GetTouch(0).phase == TouchPhase.Began)
            ShowAt(Input.GetTouch(0).position);
#endif
    }

    public void ShowAt(Vector2 screenPos)
    {
        cursorRect.position = screenPos;
        cursorImage.enabled = true;

        // 🔥 기존 애니메이션 정리
        if (animRoutine != null)
            StopCoroutine(animRoutine);

        if (hideRoutine != null)
            StopCoroutine(hideRoutine);

        animRoutine = StartCoroutine(ClickAnim());
        hideRoutine = StartCoroutine(HideAfterDelay());
    }

    private IEnumerator ClickAnim()
    {
        float t = 0f;
        Vector3 start = Vector3.one;
        Vector3 peak = Vector3.one * scaleUp;

        while (t < animDuration)
        {
            t += Time.unscaledDeltaTime;
            cursorRect.localScale = Vector3.Lerp(start, peak, t / animDuration);
            yield return null;
        }

        t = 0f;

        while (t < animDuration)
        {
            t += Time.unscaledDeltaTime;
            cursorRect.localScale = Vector3.Lerp(peak, start, t / animDuration);
            yield return null;
        }

        cursorRect.localScale = Vector3.one;
    }

    private IEnumerator HideAfterDelay()
    {
        yield return new WaitForSecondsRealtime(hideDelay);

        cursorImage.enabled = false;
        cursorRect.localScale = Vector3.one;
    }
}