﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class StageSceneController : MonoBehaviour
{
    [Header("Player Ref")]
    public StarterAssets.ThirdPersonController player;

    [Tooltip("Stage_01 씬의 ChatManager 등록")]
    public ChatManager chatManager;

    [Header("UI Canvases")]
    public CanvasGroup canvasStarterInputsGroup;    // Joystick & Button Controller Canvas
    public CanvasGroup canvasChatGroup;             // Chat Canvas
    public CanvasGroup canvasCameraGroup;           // Log & Setting Canvas
    public CanvasGroup canvasOverlayGroup;          // UI_PlayerStatus Canvas

    [Header("Stage Settings")]
    public int stageNumber = 1;
    private float maxTime;

    [Header("Camera")]
    public CameraCCTVPresetController cctvController;

    [Header("Stage UI")]
    public Button exitButton;
    public TMP_Text timerText;
    [Header("Exit Confirm UI")]
    public CanvasGroup exitConfirmPanelGroup;
    public Button cancelExitButton;     // "계속하다"
    public Button confirmExitButton;    // "그만두다"

    [Header("Portal Room")]
    public Transform portalRoomSpawn;

    [Header("Battle Map")]
    public Transform battleSpawn;

    [Header("Spawner")]
    public MonsterSpawner monsterSpawner;

    [Header("Difficulty")]
    public DifficultyMode difficultyMode = DifficultyMode.Beginner;

    private WaitForSeconds wait_Chat2Tutorial = new WaitForSeconds(1f);

    private float timer = 0f;
    private bool stageStarted = false;
    private bool stageEnded = false;

    public bool IsStageStarted => stageStarted;

    void Start()
    {
        maxTime = 1800f;    // 30 minutes

        StartCoroutine(InitRoutine());
    }

    void Update()
    {
        if (!stageStarted || stageEnded) return;

        timer += Time.deltaTime;

        float remaining = Mathf.Max(0, maxTime - timer);

        if (timerText != null)
        {
            int m = Mathf.FloorToInt(remaining / 60f);
            int s = Mathf.FloorToInt(remaining % 60f);
            timerText.text = $"{m:00}:{s:00}";
        }

        if (remaining <= 0f)
        {
            DebugManager.Log($"[Stage_{stageNumber}] Time over — stage failed.");
            EndStage(false);
        }
    }

    private IEnumerator InitRoutine()
    {
        while (StageManager.Instance == null)
            yield return null;

        // ✅ StageManager 값 기반으로 난이도 매핑
        string raw = StageManager.Instance.GetDifficulty();
        DifficultyManager.SetDifficulty(raw);

        // ✅ 인스펙터에도 반영(디버그 보기 편하게)
        difficultyMode = DifficultyManager.Mode;

        StageLogPanel.Log($"[Stage_{stageNumber}] DifficultyMode: {difficultyMode}");

        BindStageUI();

        // 스테이지 데이터 초기화는 StartStage 함수에서 실행
        //StageManager.Instance.InitStageData(maxTime, difficultyMode.ToString());

        // UI 초기 상태
        SetCanvasGroup(canvasStarterInputsGroup, false);
        SetCanvasGroup(canvasCameraGroup, false);
        SetCanvasGroup(canvasOverlayGroup, false);
        SetCanvasGroup(canvasChatGroup, true);

        // 여기서 Chat 시작
        if (chatManager != null)
        {
            chatManager.OnDialogueFinished += OnChatFinished;
            chatManager.gameObject.SetActive(true);
        }
    }

    // Chat 종료 후 처리
    private void OnChatFinished()
    {
        chatManager.OnDialogueFinished -= OnChatFinished;

        MovePlayerToPortalRoom();

        StartCoroutine(AfterChatRoutine());
    }

    void MovePlayerToPortalRoom()
    {
        if (player == null || portalRoomSpawn == null)
            return;

        CharacterController cc = player.GetComponent<CharacterController>();

        if (cc != null)
            cc.enabled = false;

        player.transform.position = portalRoomSpawn.position;
        player.transform.rotation = portalRoomSpawn.rotation;

        if (cc != null)
            cc.enabled = true;

        // 🔥 CCTV 비활성
        if (cctvController != null)
            cctvController.DisableCCTV();
    }

    public void TeleportPlayerToBattle(GameObject playerObj)
    {
        if (battleSpawn == null)
        {
            Debug.LogError("battleSpawn not set");
            return;
        }

        CharacterController cc = playerObj.GetComponent<CharacterController>();

        if (cc != null)
            cc.enabled = false;

        playerObj.transform.SetPositionAndRotation(
            battleSpawn.position,
            battleSpawn.rotation
        );

        Physics.SyncTransforms(); // 🔥 중요

        if (cc != null)
            cc.enabled = true;

        // 🔥 CCTV 활성
        if (cctvController != null)
            cctvController.EnableCCTV();

        Debug.Log("Teleport success → " + battleSpawn.position);

        StartStage();
    }

    // 1초 후 튜토리얼 → 스테이지 시작
    private IEnumerator AfterChatRoutine()
    {
        // Chat 유지한 채 1초
        yield return wait_Chat2Tutorial;

        // Chat 끄고
        SetCanvasGroup(canvasChatGroup, false);

        // Tutorial 켜기
        SetCanvasGroup(canvasCameraGroup, true);

        TutorialManager.Instance?.OpenTutorial();
    }

    void SetCanvasGroup(CanvasGroup cg, bool visible)
    {
        if (cg == null) return;

        cg.alpha = visible ? 1f : 0f;
        cg.interactable = visible;
        cg.blocksRaycasts = visible;
    }

    public void RegisterPlayer(StarterAssets.ThirdPersonController p)
    {
        player = p;
    }

    public StarterAssets.ThirdPersonController GetPlayer()
    {
        return player;
    }

    // 스테이지 시작(Chat → Tutorial → MonsterSpawning)
    public void StartStage()
    {
        if (stageStarted) return;
        stageStarted = true;

        // 🔥 StageManager 초기화 여기서!
        StageManager.Instance.InitStageData(maxTime, difficultyMode.ToString());

        // 🔥 타이머 시작 허용
        stageStarted = true;

        SetCanvasGroup(canvasChatGroup, false);
        SetCanvasGroup(canvasStarterInputsGroup, true);
        SetCanvasGroup(canvasOverlayGroup, true);
        SetCanvasGroup(canvasCameraGroup, true);

        if (monsterSpawner != null)
        {
            monsterSpawner.spawnDuration = maxTime;   // ⬅ 동기화 추천
            monsterSpawner.StartSpawning();
        }

        Debug.Log("[StageSceneController] Stage Started!");
    }

    private void BindStageUI()
    {
        if (exitButton != null)
        {
            exitButton.onClick.RemoveAllListeners();
            exitButton.onClick.AddListener(OnExitButtonClicked);
        }

        if (confirmExitButton != null)
        {
            confirmExitButton.onClick.RemoveAllListeners();
            confirmExitButton.onClick.AddListener(ConfirmExitToLobby);
        }

        if (cancelExitButton != null)
        {
            cancelExitButton.onClick.RemoveAllListeners();
            cancelExitButton.onClick.AddListener(CloseExitConfirmPanel);
        }
    }

    public void OnExitButtonClicked()
    {
        OpenExitConfirmPanel();
    }

    private void OpenExitConfirmPanel()
    {
        SetCanvasGroup(exitConfirmPanelGroup, true);

        // 🔥 게임 일시정지
        PauseManager.RequestPause();
    }

    private void CloseExitConfirmPanel()
    {
        SetCanvasGroup(exitConfirmPanelGroup, false);

        // 🔥 게임 재개
        PauseManager.ReleasePause();
    }

    // 로비로 나가기
    private void ConfirmExitToLobby()
    {
        SetCanvasGroup(exitConfirmPanelGroup, false);

        PauseManager.ReleasePause();

        CursorManager.SetUI();
        SceneTransitionManager.Instance.ReturnToLobby();
    }

    private void EndStage(bool cleared)
    {
        if (stageEnded) return;
        stageEnded = true;

        if (monsterSpawner != null)
            monsterSpawner.StopSpawning();

        CursorManager.SetUI();
        StageManager.Instance.FinishStage(cleared);
    }
}