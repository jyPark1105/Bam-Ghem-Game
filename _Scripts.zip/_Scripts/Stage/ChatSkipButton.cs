using UnityEngine;
using UnityEngine.UI;

public class ChatSkipButton : MonoBehaviour
{
    [SerializeField] private Button button;
    [SerializeField] private ChatManager chatManager;

    private void Awake()
    {
        if (button != null)
            button.onClick.AddListener(OnSkip);
    }

    void OnSkip()
    {
        chatManager?.SkipToSummary();
    }
}