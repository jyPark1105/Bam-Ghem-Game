﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Collections;
using UnityEngine.SceneManagement;

public class StagePanelLoader : MonoBehaviour
{
    [Header("Prefabs")]
    public GameObject panelNoRecordPrefab;
    public GameObject panelRecordedPrefab;
    public GameObject panelLockedPrefab;

    [Header("Parent Holder (가로로 쌓일 곳)")]
    public Transform panelHolder;      // StagePanelHolder
    public ScrollRect scrollRect;      // Horizontal Scroll View

    [Header("Stage Info")]
    public int visibleCount = 3;       // 한 화면에 보일 패널 개수

    private List<GameObject> spawnedPanels = new();

    void Start()
    {
        //LoadStagePanels();
    }

    // ================================================================
    //                          LOAD PANELS
    // ================================================================
    public void LoadStagePanels()
    {
        ClearPanels();

        for (int i = 0; i < GameManager.Instance.stages.Count; i++)
        {
            StageRecord record = GameManager.Instance.stages[i];
            GameObject prefabToUse;

            if (!record.isUnlocked)
                prefabToUse = panelLockedPrefab;
            else if (record.isCleared)
                prefabToUse = panelRecordedPrefab;
            else
                prefabToUse = panelNoRecordPrefab;

            GameObject panel = Instantiate(prefabToUse);
            panel.transform.SetParent(panelHolder, false);

            panel.name = $"StagePanel_{record.stageNumber}";
            SetupPanel(panel, record);

            spawnedPanels.Add(panel);
        }

        AdjustScrollContentSize();
        SetupScrollMask();
    }

    // ================================================================
    //                      SETUP EACH STAGE PANEL
    // ================================================================
    private void SetupPanel(GameObject panel, StageRecord record)
    {
        var stageTitle = panel.transform.Find("N_Stage/Stage_Num")?.GetComponent<TMP_Text>();
        if (stageTitle != null)
            stageTitle.text = $"STAGE {record.stageNumber}";

        // Recorded Panel
        var recorded = panel.GetComponent<StageRecordedPanel>();
        if (recorded != null)
            recorded.Setup(record.stageNumber, record);

        // 기본 패널 + 난이도 팝업
        Transform panelDefault = panel.transform.Find("Panel_Default");
        Transform difficultyPopup = panel.transform.Find("Panel_DifficultyPopup");

        if (difficultyPopup != null)
            difficultyPopup.gameObject.SetActive(false);

        // ------------------ 도전하기 버튼 ------------------
        var challengeBtn = panelDefault?.Find("ChallengeBtn")?.GetComponent<Button>();
        if (challengeBtn != null)
        {
            challengeBtn.onClick.RemoveAllListeners();

            if (record.isUnlocked)
            {
                challengeBtn.interactable = true;
                int capturedStage = record.stageNumber;

                challengeBtn.onClick.AddListener(() =>
                {
                    panelDefault.gameObject.SetActive(false);
                    difficultyPopup.gameObject.SetActive(true);
                });
            }
            else
            {
                challengeBtn.interactable = false;
            }
        }

        // ------------------ EXIT 버튼 ------------------
        var exitBtn = difficultyPopup?.Find("ExitBtn")?.GetComponent<Button>();
        if (exitBtn != null)
        {
            exitBtn.onClick.RemoveAllListeners();
            exitBtn.onClick.AddListener(() =>
            {
                difficultyPopup.gameObject.SetActive(false);
                panelDefault.gameObject.SetActive(true);
            });
        }

        // ------------------ 난이도 버튼 ------------------
        int stageNum = record.stageNumber;
        var beginnerBtn = difficultyPopup?.Find("BeginnerBtn")?.GetComponent<Button>();
        var expertBtn = difficultyPopup?.Find("ExpertBtn")?.GetComponent<Button>();

        if (beginnerBtn != null)
        {
            beginnerBtn.onClick.RemoveAllListeners();
            beginnerBtn.onClick.AddListener(() =>
            {
                SceneTransitionManager.Instance.LoadStage(stageNum, "Beginner");
            });
        }
        if (expertBtn != null)
        {
            expertBtn.onClick.RemoveAllListeners();
            expertBtn.onClick.AddListener(() =>
            {
                SceneTransitionManager.Instance.LoadStage(stageNum, "Expert");
            });
        }
    }

    // ================================================================
    //        ⚙️ Horizontal Layout 기반 Content Size 자동 조정
    // ================================================================
    private void AdjustScrollContentSize()
    {
        var holderRect = panelHolder.GetComponent<RectTransform>();
        var layoutGroup = panelHolder.GetComponent<HorizontalLayoutGroup>();

        float panelWidth = 400f; // 너 패널 기본 width
        float spacing = layoutGroup != null ? layoutGroup.spacing : 30f;

        int stageCount = GameManager.Instance.stages.Count;

        float totalWidth = (panelWidth + spacing) * stageCount;

        holderRect.sizeDelta = new Vector2(totalWidth, holderRect.sizeDelta.y);

        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(panelHolder.GetComponent<RectTransform>());
        scrollRect.horizontalNormalizedPosition = 0f;
    }

    // ================================================================
    //                ✔ Viewport(스크롤 영역) 자동 설정
    // ================================================================
    private void SetupScrollMask()
    {
        // Mask 존재하지 않으면 추가
        var viewport = scrollRect.viewport;
        if (viewport.GetComponent<Mask>() == null)
        {
            var mask = viewport.gameObject.AddComponent<Mask>();
            mask.showMaskGraphic = false;
        }

        // visibleCount 기준으로 Viewport width 조정
        float panelWidth = 400f;
        float spacing = panelHolder.GetComponent<HorizontalLayoutGroup>()?.spacing ?? 30f;
        float visibleWidth = (panelWidth + spacing) * visibleCount;

        var viewportRect = viewport.GetComponent<RectTransform>();
        viewportRect.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, visibleWidth);
    }

    // ================================================================
    private void ClearPanels()
    {
        foreach (var p in spawnedPanels)
            if (p != null) Destroy(p);

        spawnedPanels.Clear();
    }

    // ================================================================
    private IEnumerator LoadSceneRoutine(string sceneName)
    {
        var asyncLoad = SceneManager.LoadSceneAsync(sceneName);
        while (!asyncLoad.isDone)
            yield return null;
    }
}
