﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class LobbyUIRootBlocker : MonoBehaviour
{
    public static LobbyUIRootBlocker Instance;

    private CanvasGroup cg;

    private void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        cg = GetComponent<CanvasGroup>();
        if (cg == null)
            cg = gameObject.AddComponent<CanvasGroup>();
    }

    private void OnEnable()
    {
        // Stage 중에 로비 UI 루트가 켜지면 즉시 차단
        if (SceneManager.GetActiveScene().name.StartsWith("Stage_"))
        {
            BlockForStage();
            Debug.Log("⚠ Lobby UI Root enabled during Stage → auto blocked");
        }
    }

    public void BlockForStage()
    {
        cg.alpha = 0f;
        cg.interactable = false;
        cg.blocksRaycasts = false; // 🔥 핵심
        Debug.Log("🚫 Lobby UI Root Raycast OFF");
    }

    public void RestoreForLobby()
    {
        cg.alpha = 1f;
        cg.interactable = true;
        cg.blocksRaycasts = true;
        Debug.Log("✅ Lobby UI Root Raycast ON");
    }
}