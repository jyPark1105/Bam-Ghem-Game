﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StagePanel : MonoBehaviour
{
    [Header("Stage Info")]
    public int stageNumber;
    public GameObject recordedPrefab;

    [Header("Panel References")]
    public GameObject panelDefault;         // Panel_Default
    public GameObject panelDifficultyPopup; // Panel_DifficultyPopup

    [Header("Buttons")]
    public Button challengeBtn;
    public Button beginnerBtn;
    public Button expertBtn;
    public Button exitBtn;

    private void Awake()
    {
        // 기본 패널 상태
        if (panelDifficultyPopup != null)
            panelDifficultyPopup.SetActive(false);

        // 이벤트 등록
        if (challengeBtn != null)
        {
            challengeBtn.onClick.RemoveAllListeners();
            challengeBtn.onClick.AddListener(OpenDifficultyPopup);
        }

        if (beginnerBtn != null)
            beginnerBtn.onClick.AddListener(() => SelectDifficulty("Beginner"));
        if (expertBtn != null)
            expertBtn.onClick.AddListener(() => SelectDifficulty("Expert"));

        if (exitBtn != null)
            exitBtn.onClick.AddListener(ClosePopup);
    }

    private void OpenDifficultyPopup()
    {
        panelDefault.SetActive(false);
        panelDifficultyPopup.SetActive(true);

        DebugManager.Log($"[StagePanel] Stage {stageNumber}: Difficulty popup opened.");
    }

    private void ClosePopup()
    {
        panelDifficultyPopup.SetActive(false);
        panelDefault.SetActive(true);

        DebugManager.Log($"[StagePanel] Stage {stageNumber}: Difficulty popup closed.");
    }

    private void SelectDifficulty(string difficulty)
    {
        DebugManager.Log($"[StagePanel] Difficulty Selected: {difficulty}");

        SceneTransitionManager.Instance.LoadStage(stageNumber, difficulty);

        gameObject.SetActive(false);
    }

    // =========================================================
    // 🔥 클리어 시 Recorded 프리펩으로 교체
    // =========================================================
    public void ReplaceWithRecordedPrefab()
    {
        DebugManager.Log($"[StagePanel] Stage {stageNumber} cleared → replacing prefab...");

        Transform parent = transform.parent;
        int index = transform.GetSiblingIndex();

        GameObject newPanel = Instantiate(recordedPrefab, parent);
        newPanel.transform.SetSiblingIndex(index);

        var record = GameManager.Instance.GetStageRecord(stageNumber);
        var recordedScript = newPanel.GetComponent<StageRecordedPanel>();

        if (recordedScript != null && record != null)
            recordedScript.Setup(stageNumber, record);
        else
            DebugManager.Log("[StagePanel] Missing record or recordedScript!", LogType.Warning);

        Destroy(gameObject);
    }
}