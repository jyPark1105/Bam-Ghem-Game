﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

public class StageRecordedPanel : MonoBehaviour
{
    [Header("UI Components")]
    public TMP_Text stageTitle;
    public TMP_Text clearLevelText;
    public Button retryButton;
    public Image[] stars;

    [Header("Panels")]
    public GameObject panelDefault;          // 기존 기본 패널
    public GameObject panelDifficultyPopup;  // 추가된 난이도 선택 팝업

    [Header("Difficulty Buttons")]
    public Button beginnerBtn;
    public Button expertBtn;
    public Button exitPopupBtn;

    [HideInInspector] public int stageNumber;

    private Sprite goldenStar;
    private Sprite grayStar;

    private void Awake()
    {
        // ===============================
        // 🔥 리소스 로드
        // ===============================
        goldenStar = Resources.Load<Sprite>("Stage/GoldenStar");
        grayStar = Resources.Load<Sprite>("Stage/GrayStar");

        if (goldenStar == null || grayStar == null)
            Debug.LogError("[StageRecordedPanel] GoldenStar or GrayStar not found in Resources/Stage!");


        // ===============================
        // 🔥 별 이미지 자동 연결
        // ===============================
        if (stars == null || stars.Length == 0)
        {
            var starGroup = transform.Find("Panel_Default/CompleteStar");
            if (starGroup != null)
            {
                stars = new Image[3];
                for (int i = 0; i < 3; i++)
                    stars[i] = starGroup.Find($"Stars_{i + 1}")?.GetComponent<Image>();
            }
        }


        // ===============================
        // 🔥 버튼 연결
        // ===============================
        retryButton = transform.Find("Panel_Default/Clear/RestartBtn")?.GetComponent<Button>();

        if (retryButton != null)
        {
            retryButton.onClick.RemoveAllListeners();
            retryButton.onClick.AddListener(OnRetryClicked);
        }

        stageTitle = transform.Find("N_Stage/Stage_Num")?.GetComponent<TMP_Text>();
        clearLevelText = transform.Find("Panel_Default/Clear/ClearLevelText")?.GetComponent<TMP_Text>();


        // ===============================
        // 🔥 난이도 팝업 버튼 연결
        // ===============================
        panelDifficultyPopup.SetActive(false);

        beginnerBtn.onClick.AddListener(() => SelectDifficulty("Beginner"));
        expertBtn.onClick.AddListener(() => SelectDifficulty("Expert"));

        exitPopupBtn.onClick.AddListener(ClosePopup);
    }

    // ===================================================================
    // 🔥 StagePanelLoader에서 호출되는 설정 함수
    // ===================================================================
    public void Setup(int stageNum, StageRecord record)
    {
        stageNumber = stageNum;

        if (stageTitle != null)
            stageTitle.text = $"STAGE {stageNumber}";

        if (clearLevelText != null)
        {
            clearLevelText.text = record.starCount switch
            {
                1 => "Beginner",
                3 => "Expert",
                _ => "Beginner"
            };
        }

        // 별 세팅
        for (int i = 0; i < 3; i++)
        {
            if (stars[i] != null)
                stars[i].sprite = (record.starCount > i) ? goldenStar : grayStar;
        }

        DebugManager.Log($"[StageRecordedPanel] Setup complete → STAGE {stageNumber}, Stars={record.starCount}");
    }

    // ===================================================================
    // 🔥 Restart(재도전) 버튼을 눌렀을 때
    // ===================================================================
    private void OnRetryClicked()
    {
        DebugManager.Log($"[StageRecordedPanel] Retry clicked → difficulty 선택 창 열기!");

        // 버튼 클릭 FX
        if (ParticleController.Instance != null && retryButton != null)
        {
            RectTransform rect = retryButton.GetComponent<RectTransform>();
            Vector3 screenPos = RectTransformUtility.WorldToScreenPoint(
                ParticleController.Instance.uiCamera, rect.position);

            ParticleController.Instance.PlayFX("ButtonClickFX", screenPos);
        }

        // 팝업 열기
        panelDefault.SetActive(false);
        panelDifficultyPopup.SetActive(true);
    }

    // ===================================================================
    // 🔥 난이도 선택
    // ===================================================================
    private void SelectDifficulty(string difficulty)
    {
        DebugManager.Log($"[StageRecordedPanel] 난이도 선택 → {difficulty}");

        StageManager.Instance.SetDifficulty(difficulty);
        SceneTransitionManager.Instance.LoadStage(stageNumber, difficulty);

        // 패널 닫기 (로비 UI 숨김)
        this.gameObject.SetActive(false);
    }

    // ===================================================================
    // 🔥 팝업 닫기 (X 버튼)
    // ===================================================================
    private void ClosePopup()
    {
        panelDifficultyPopup.SetActive(false);
        panelDefault.SetActive(true);
    }
}
