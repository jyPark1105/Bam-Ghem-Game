﻿using UnityEngine;

public enum DifficultyMode
{
    Beginner,   // 초급자
    Veteran     // 숙련자
}

public static class DifficultyManager
{
    // ===============================
    // 기존 스탯 배율 (유지)
    // ===============================
    public static float HP_Multiplier = 1f;
    public static float MoveSpeed_Multiplier = 1f;
    public static float Detect_Multiplier = 1f;
    public static float AttackCooldown_Multiplier = 1f;

    // ===============================
    // 신규: 난이도 모드
    // ===============================
    public static DifficultyMode Mode { get; private set; } = DifficultyMode.Beginner;

    // ===============================
    // 신규: 감지/전투 체감 수치
    // ===============================
    public static float ViewAngle =>
        Mode == DifficultyMode.Beginner ? 60f : 120f;

    public static float ViewDistance =>
        Mode == DifficultyMode.Beginner ? 3f : 5f;

    public static float RangedAttackChance =>
        Mode == DifficultyMode.Beginner ? 0.20f : 0.40f;

    // ===============================
    // 난이도 설정 (문자열 기반)
    // ===============================
    public static void SetDifficulty(string diff)
    {
        if (string.IsNullOrEmpty(diff))
            diff = "Beginner";

        diff = diff.Trim().ToLowerInvariant();

        // ---------------------------------
        // 1️⃣ 초급자 모드
        // ---------------------------------
        if (diff.Contains("easy") || diff.Contains("beginner"))
        {
            Mode = DifficultyMode.Beginner;

            HP_Multiplier = 0.8f;
            MoveSpeed_Multiplier = 0.9f;
            Detect_Multiplier = 0.85f;
            AttackCooldown_Multiplier = 1.2f;

            DebugManager.Log("[Difficulty] BEGINNER (초급자) 적용됨");
            return;
        }

        // ---------------------------------
        // 2️⃣ 숙련자 모드
        // ---------------------------------
        if (diff.Contains("hard") || diff.Contains("veteran"))
        {
            Mode = DifficultyMode.Veteran;

            HP_Multiplier = 1.4f;
            MoveSpeed_Multiplier = 1.2f;
            Detect_Multiplier = 1.3f;
            AttackCooldown_Multiplier = 0.8f;

            DebugManager.Log("[Difficulty] VETERAN (숙련자) 적용됨");
            return;
        }

        // ---------------------------------
        // 3️⃣ Normal → 초급자 상위 버전으로 처리
        // ---------------------------------
        Mode = DifficultyMode.Beginner;

        HP_Multiplier = 1f;
        MoveSpeed_Multiplier = 1f;
        Detect_Multiplier = 1f;
        AttackCooldown_Multiplier = 1f;

        DebugManager.Log("[Difficulty] NORMAL → BEGINNER 기준값 적용됨");
    }
}