﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class SceneLoadingUI : MonoBehaviour
{
    [Header("UI")]
    public CanvasGroup canvasGroup;
    public Image spinner;
    public TMP_Text systemText;
    public Button retryButton;

    [Header("Anim")]
    public float fadeSpeed = 2f;
    public float rotateSpeed = 180f;

    // 🔥 재시도 콜백 (SceneTransitionManager에서 연결)
    public Action OnRetryRequested;

    private Transform _spinnerTrans;    // 캐싱
    private bool isTimeout = false;

    private void Awake()
    {
        if (spinner != null)
            _spinnerTrans = spinner.transform;

        if (retryButton != null)
        {
            retryButton.gameObject.SetActive(false);
            retryButton.onClick.RemoveAllListeners();
            retryButton.onClick.AddListener(OnRetryButtonClicked);
        }
    }

    private void Start()
    {
        canvasGroup.alpha = 1f;
        SetLoading();   // 기본 상태
    }

    private void Update()
    {
        if (_spinnerTrans != null && !isTimeout)
            _spinnerTrans.Rotate(Vector3.back * (rotateSpeed * Time.deltaTime));
    }

    // =====================================================
    // 🔹 기본 로딩 상태
    // =====================================================
    public void SetLoading()
    {
        isTimeout = false;

        if (systemText != null)
            systemText.text = "스테이지 로딩 중입니다. 잠시 기다려주세요...";

        if (retryButton != null)
            retryButton.gameObject.SetActive(false);
    }

    // =====================================================
    // 🔹 타임아웃 상태
    // =====================================================
    public void SetTimeout()
    {
        isTimeout = true;

        if (systemText != null)
            systemText.text = "네트워크 상태가 좋지 않습니다.";

        if (retryButton != null)
            retryButton.gameObject.SetActive(true);
    }

    // =====================================================
    // 🔹 다시 시도 버튼
    // =====================================================
    private void OnRetryButtonClicked()
    {
        SetLoading();
        OnRetryRequested?.Invoke();
    }
}