﻿using UnityEngine;
using UnityEngine.UI;

public class TutorialManager : MonoBehaviour
{
    public static TutorialManager Instance;

    [Header("Canvas")]
    public Canvas targetCanvas;
    public Camera uiCamera;   // MainCamera

    [Header("Root")]
    public GameObject tutorialRoot;

    [Header("Panels (0: Control, 1: Augment, 2: Goal)")]
    public GameObject[] panels;

    [Header("Navigation Buttons")]
    public Button leftButton;
    public Button rightButton;
    public Button exitButton;

    [Header("Page Indicator")]
    public Image[] pageDots;

    public Color activeDotColor = Color.white;
    public Color inactiveDotColor = new Color(1f, 1f, 1f, 0.3f);

    [Header("External")]
    public Button guideButton;   // 우측 상단 Guide 버튼

    private int currentIndex = 0;
    private bool isActive = false;

    private StageSceneController stageController;
    private bool stageStarted = false; // 최초 1회용

    private StarterAssets.ThirdPersonController cachedPlayer;

    // =========================
    // Life Cycle
    // =========================
    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    private void Start()
    {
        stageController = FindFirstObjectByType<StageSceneController>();

        if (stageController != null)
            cachedPlayer = stageController.GetPlayer(); // ← 없으면 아래 참고

        InitButtons();
    }

    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.N))
            CloseTutorial();
    }

    private void InitButtons()
    {
        leftButton.onClick.RemoveAllListeners();
        leftButton.onClick.AddListener(PrevPage);

        rightButton.onClick.RemoveAllListeners();
        rightButton.onClick.AddListener(NextPage);

        exitButton.onClick.RemoveAllListeners();
        exitButton.onClick.AddListener(CloseTutorial);

        if (guideButton != null)
        {
            guideButton.onClick.RemoveAllListeners();
            guideButton.onClick.AddListener(OpenTutorial);
        }

        StageLogPanel.Log("InitButtons 실행됨? ");
    }

    // =========================
    // Public API (Guide 버튼)
    // =========================
    public void OpenTutorial()
    {
        StageLogPanel.Log("OpenTutorial 실행");

        CursorManager.SetUI();                 // 🔓 커서 보이기

        SetCanvasOverlayMode();

        tutorialRoot.SetActive(true);
        tutorialRoot.transform.localScale = Vector3.one;

        isActive = true;
        currentIndex = 0;

        UpdatePanels();
        UpdateNavButtons();
        UpdatePageIndicator();
    }

    // =========================
    // Navigation
    // =========================
    private void NextPage()
    {
        if (currentIndex >= panels.Length - 1)
            return;

        currentIndex++;
        UpdatePanels();
        UpdateNavButtons();
        UpdatePageIndicator();
    }

    private void PrevPage()
    {
        if (currentIndex <= 0)
            return;

        currentIndex--;
        UpdatePanels();
        UpdateNavButtons();
        UpdatePageIndicator();
    }

    private void UpdatePanels()
    {
        for (int i = 0; i < panels.Length; i++)
            panels[i].SetActive(i == currentIndex);
    }

    private void UpdateNavButtons()
    {
        if (leftButton != null)
            leftButton.gameObject.SetActive(currentIndex > 0);

        if (rightButton != null)
            rightButton.gameObject.SetActive(currentIndex < panels.Length - 1);
    }

    // =========================
    // Exit / Finish
    // =========================
    private void CloseTutorial()
    {
        isActive = false;
        currentIndex = 0;

        foreach (var p in panels)
            p.SetActive(false);

        tutorialRoot.SetActive(false);

        SetCanvasCameraMode();
        UpdatePageIndicator();

        // =========================
        // 🔥 플레이어 입력 복구
        // =========================
        if (cachedPlayer != null)
        {
            cachedPlayer.SetBusy(false);
            cachedPlayer.EnableAllInputs();
            //cachedPlayer.DebugInputState("TUTORIAL_EXIT");
        }
        else
        {
            Debug.LogWarning("[Tutorial] cachedPlayer is null");
        }

        CursorManager.SetGameplay(); // 🔒 커서 원복 (있다면)

        // =========================
        // 🔥 실제 게임 시작 (중복 방지)
        // =========================
        if (!stageStarted)
        {
            stageStarted = true;

            if (stageController != null)
            {
                stageController.StartStage();   // 🔥 모든 시작은 여기로 위임
            }
            else
            {
                Debug.LogError("[Tutorial] stageController is NULL");
            }
        }
    }

    // 인디케이터 갱신 함수
    private void UpdatePageIndicator()
    {
        if (pageDots == null || pageDots.Length == 0)
            return;

        for (int i = 0; i < pageDots.Length; i++)
        {
            if (pageDots[i] == null) continue;

            pageDots[i].transform.localScale =
                (i == currentIndex) ? Vector3.one * 1.2f : Vector3.one;

            pageDots[i].color =
                (i == currentIndex) ? activeDotColor : inactiveDotColor;
        }
    }

    // Canvas 모드 전환 유틸 함수 추가
    private void SetCanvasOverlayMode()
    {
        if (targetCanvas == null) return;

        targetCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        targetCanvas.worldCamera = null;
    }

    private void SetCanvasCameraMode()
    {
        if (targetCanvas == null) return;

        targetCanvas.renderMode = RenderMode.ScreenSpaceCamera;
        targetCanvas.worldCamera = uiCamera;
    }
}
