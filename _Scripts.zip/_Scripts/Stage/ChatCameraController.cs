﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class ChatCameraController : MonoBehaviour
{
    public Animator animator;

    [Header("Monster Intro (Scene Objects)")]
    public GameObject slime;
    public GameObject turtleShell;
    public GameObject cactus;
    public GameObject beholder;

    [Header("VFX")]
    public GameObject vfxPrefab;

    [Header("Timing")]
    public float spawnInterval = 0.2f;
    public float despawnDelay = 3f;

    private Coroutine monsterRoutine;

    [SerializeField] float monsterCameraViewDuration = 1.2f;

    private static readonly int ExitCameraViewHash =
        Animator.StringToHash("ExitCameraView");

    private static readonly int DoScaryHash = Animator.StringToHash("DoScary");

    public event Action OnCameraViewIdleReached;
    private bool hasNotifiedViewIdle = false;

    // 🔥 몬스터 소개 연출 종료 이벤트
    public event Action OnMonsterPresentationFinished;

    // =========================
    // Dialogue Index 진입
    // =========================
    public void OnDialogueIndex(int index)
    {
        // 🔥 새로운 카메라 연출 시작 → ViewIdle 재진입 준비
        hasNotifiedViewIdle = false;

        switch (index)
        {
            case 0:
                animator.Play("D0_CameraAnim");
                break;

            case 8:
                animator.Play("D8_CameraAnim");
                break;

            case 17:
                PlayMonsterIntro();
                break;
        }
    }

    public void NotifyViewIdleReached()
    {
        // 🔒 이미 한 번 알렸으면 무시
        if (hasNotifiedViewIdle)
            return;

        hasNotifiedViewIdle = true;
        OnCameraViewIdleReached?.Invoke();
    }

    // =========================
    // 🔥 17번 몬스터 연출 시작
    // =========================
    void PlayMonsterIntro()
    {
        if (monsterRoutine != null)
            StopCoroutine(monsterRoutine);

        monsterRoutine = StartCoroutine(MonsterIntroRoutine());
    }

    IEnumerator MonsterIntroRoutine()
    {
        // 1️⃣ 카메라 연출 시작
        animator.Play("D17_CameraAnim");

        // ⚠️ 카메라 애니메이션 클립 길이 직접 지정 권장
        yield return new WaitForSeconds(monsterCameraViewDuration);

        // 2️⃣ 마지막 프레임 고정용 Idle
        animator.Play("D17_CameraViewIdle");

        // 3️⃣ 몬스터 순차 등장
        GameObject[] order =
        {
            slime,
            turtleShell,
            cactus,
            beholder
        };

        foreach (var monster in order)
        {
            if (monster == null) continue;

            monster.SetActive(true);
            SpawnVFX(monster.transform.position);

            // NavMesh 정지
            var agent = monster.GetComponent<NavMeshAgent>();
            if (agent != null)
                agent.speed = 0f;

            // 공포 연출 트리거
            var anim = monster.GetComponent<Animator>();
            if (anim != null)
            {
                anim.ResetTrigger(DoScaryHash);
                anim.SetTrigger(DoScaryHash);
            }

            yield return new WaitForSeconds(spawnInterval);
        }

        // 4️⃣ 연출 유지
        yield return new WaitForSeconds(despawnDelay);

        // 5️⃣ 몬스터 소멸
        foreach (var monster in order)
        {
            if (monster == null) continue;

            SpawnVFX(monster.transform.position);
            monster.SetActive(false);
        }

        // 연출 끝났다고 알리기
        OnMonsterPresentationFinished?.Invoke();
    }

    // =========================
    // VFX Helper
    // =========================
    void SpawnVFX(Vector3 pos)
    {
        if (vfxPrefab == null) return;

        Instantiate(
            vfxPrefab,
            pos + Vector3.up * 0.3f,
            Quaternion.identity
        );
    }

    // =========================
    // 🔥 17 → 18 전환
    // =========================
    public void Go17To18()
    {
        animator.SetTrigger("Go17To18");
    }

    // =========================
    // 스킵 / 종료
    // =========================
    public void ResetToIdle()
    {
        if (animator == null) return;

        animator.Play("Idle", 0, 0f);
    }

    // CameraViewIdle 탈출 함수
    public void ExitCameraView()
    {
        if (animator == null) return;
        animator.SetTrigger(ExitCameraViewHash);
    }
}