﻿using System.Collections.Generic;
using TMPro;
using UnityEngine;

[System.Serializable]
public class MonsterResult
{
    public int total;
    public int killed;
    public int criticalKilled;
    public int attackCount;
    public int extinctionCount;
}

[System.Serializable]
public class StageResultData
{
    // 스테이지 정보
    public int stageNumber;
    public string difficulty;
    public int starCount;

    // 시간
    public float clearTime;
    public float totalStageTime;

    // 🔥 몬스터 정보 (MonsterType → MonsterResult)
    public Dictionary<EnemyAI.MonsterType, MonsterResult> monsterResults =
        new Dictionary<EnemyAI.MonsterType, MonsterResult>();

    // 피해 정보
    public int damageTaken;
    public int damageDealt;

    // 처치 정보
    public int totalKills;
    public int totalCriticalKills;

    // 스킬 정보
    public int useSkillAttack;
    public int useSkillAttackSlash;
    public int useSkillSkillA;
    public int useSkillClimb;
    public int useSkillDodge;
    public int useSkillJump;
    public int useSkillGetItem;

    // 흡수 데이터
    public string absorbedElement;
    public int absorbedCount;

    // 보상
    public RewardData rewardBase;
    public RewardData rewardFinal;

    // 클리어 여부
    public bool isClear;
}