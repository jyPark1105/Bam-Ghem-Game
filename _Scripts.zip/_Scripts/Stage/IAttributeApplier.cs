public interface IAttributeApplier
{
    void ApplyAttribute(PlayerAbsorbEffect.ColorType type);
}