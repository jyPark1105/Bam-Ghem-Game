﻿using UnityEngine;
using TMPro;

public class TypeEffect : MonoBehaviour
{
    public int charPerSeconds = 15;
    public GameObject endCursor;

    TMP_Text msgText;
    string targetMsg;
    int index;
    float interval;

    bool isTyping;

    private void Awake()
    {
        msgText = GetComponent<TMP_Text>();
        interval = 1f / charPerSeconds;
    }

    // =========================
    // 🔹 외부에서 호출
    // =========================
    public void SetMsg(string msg)
    {
        targetMsg = msg;
        EffectStart();
    }

    // =========================
    // 🔹 타이핑 시작
    // =========================
    void EffectStart()
    {
        msgText.text = "";
        index = 0;
        isTyping = true;

        if (endCursor != null)
            endCursor.SetActive(false);

        CancelInvoke();

        // 타이핑 사운드 시작
        AudioManager.Instance?.PlayChatTyping();

        InvokeRepeating(nameof(Effecting), interval, interval);
    }

    // =========================
    // 🔹 타이핑 진행
    // =========================
    void Effecting()
    {
        if (!isTyping) return;

        // 끝 도달
        if (index >= targetMsg.Length)
        {
            EffectEnd();
            return;
        }

        msgText.text += targetMsg[index];
        index++;
    }

    // =========================
    // 🔹 타이핑 종료
    // =========================
    void EffectEnd()
    {
        if (!isTyping) return;

        isTyping = false;
        CancelInvoke();

        msgText.text = targetMsg;

        if (endCursor != null)
            endCursor.SetActive(true);

        // 타이핑 사운드 정지
        AudioManager.Instance?.StopChatTyping();
    }

    // =========================
    // 🔹 즉시 출력 (스킵용)
    // =========================
    public void Skip()
    {
        if (!isTyping) return;

        EffectEnd(); // 여기서 사운드도 같이 정지됨
    }

    public bool IsTyping()
    {
        return isTyping;
    }
}