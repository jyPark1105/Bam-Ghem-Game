[System.Serializable]
public class StageRecord
{
    public int stageNumber;
    public bool isUnlocked;
    public bool isCleared;

    public int starCount;

    public string difficulty;
    public float lastClearTime;
    public float bestClearTime = 99999f;

    public int bestKills = 0;
    public int bestCriticalKills = 0;
    public int bestDamageDealt = 0;

    public long clearTimestamp;

    public RewardData reward;

    public StageRecord(int number, bool unlocked)
    {
        stageNumber = number;
        isUnlocked = unlocked;
        isCleared = false;
        starCount = 0;
        reward = new RewardData(0, 0, 0);
    }
}

[System.Serializable]
public class RewardData
{
    public int coin;
    public int trophy;
    public int exp;

    public RewardData(int coin, int trophy, int exp)
    {
        this.coin = coin;
        this.trophy = trophy;
        this.exp = exp;
    }

    public RewardData Clone()
    {
        return new RewardData(coin, trophy, exp);
    }

    public void Multiply(int amount)
    {
        coin *= amount;
        trophy *= amount;
        exp *= amount;
    }
}
