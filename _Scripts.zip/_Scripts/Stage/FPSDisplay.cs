﻿using UnityEngine;

public class FPSDisplay : MonoBehaviour
{
    [Header("Display")]
    [SerializeField] private Color textColor = Color.green;

    private const int FONT_SIZE = 15;

    private float deltaTime = 0f;
    private bool isShow = true;

    private GUIStyle cachedStyle;

    private void Awake()
    {
        cachedStyle = new GUIStyle
        {
            alignment = TextAnchor.UpperRight,
            fontSize = FONT_SIZE,
            normal = { textColor = textColor }
        };
    }

    private void Update()
    {
        // 🔥 실제 FPS (Pause 영향 없음)
        deltaTime += (Time.unscaledDeltaTime - deltaTime) * 0.1f;
    }

    // UI 버튼에서 호출 가능 (표시 ON/OFF)
    public void ToggleDisplay()
    {
        isShow = !isShow;
    }

    private void OnGUI()
    {
        if (!isShow) return;

        float ms = deltaTime * 1000.0f;
        float fps = 1.0f / deltaTime;

        string text = string.Format(
            "{0:0.} FPS ({1:0.0} ms)",
            fps,
            ms
        );

        Rect rect = new Rect(
            0,
            30,
            Screen.width - 30,
            Screen.height
        );

        GUI.Label(rect, text, cachedStyle);
    }
}