﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
using System.Collections;
using StarterAssets;

public enum SpeakerType
{
    YBot = 0,
    Unknown = 1,
    Manager = 2
}

public enum EmotionType
{
    Normal = 0,
    Surprised = 1,
    Scared = 2,
    Depressed = 3,
    ThinkingOrCurious = 4,
    Enlightened = 5
}

[System.Serializable]
public class Dialogue
{
    public SpeakerType speaker;   // 누가 말하는가
    public EmotionType emotion;   // 어떤 감정인가
    [TextArea(2, 4)]
    public string text;           // 실제 출력할 대사
}

public class ChatManager : MonoBehaviour
{
    public static ChatManager Instance { get; private set; }

    public ChatCameraController chatCamera;
    public ThirdPersonController player;

    [Header("UI")]
    public TMP_Text nameTextUI;
    public Image portraitImage;
    public TypeEffect typeEffect;

    [Header("Name Mapping")]
    public string[] nameText;
    /*
        0 : Y Bot (플레이어)
        1 : 매니저
        2 : ???
    */

    [Header("Portrait Mapping")]
    public Sprite[] portraitArr;

    [Header("Dialogue Data")]
    public List<Dialogue> dialogues = new List<Dialogue>();

    private bool hasStarted = false;

    int currentIndex = 0;

    public Action OnDialogueFinished;
    public event Action<int> OnDialogueIndexChanged;

    bool isWaitingForEndConfirm = false;
    bool isMonsterPresentationDone = false; // Dialogue 17: 몬스터 연출이 끝났을 때 true로 변경
    bool hasSent17To18 = false;

    // CameraViewIdle → ROOT 탈출용
    private readonly HashSet<int> exitCameraViewIndices = new HashSet<int> { 0, 8, 17 };

    // YBot 애니메이션 트리거용
    private readonly HashSet<int> triggerD0AnimIndices = new HashSet<int> { 0 };
    private readonly HashSet<int> triggerD8AnimIndices = new HashSet<int> { 8 };

    [Header("Skip")]
    public GameObject skipButton;   // 스킵 버튼 UI
    private const int SUMMARY_INDEX = 25;
    private bool skipEnabled = false;

    private void Awake()
    {
        Instance = this;

        if (chatCamera != null)
        {
            chatCamera.OnMonsterPresentationFinished += () =>
            {
                isMonsterPresentationDone = true;
            };

            // 🔥 추가
            chatCamera.OnCameraViewIdleReached += OnCameraViewIdleReached;
        }

        // ShowDialogue(0); 자동 시작 제거
    }

    // 수동 시작 함수
    public void StartDialogue()
    {
        if (hasStarted) return;

        hasStarted = true;

        // 다이얼로그 데이터 생성
        GenerateData();
        BackgroundMusicManager.Instance?.PlayChatBgm();
        player?.SetChatMode(true);

        // 첫번째 다이얼로그 표시
        ShowDialogue(0);
        StartCoroutine(EnableSkipAfterDelay());
    }

    // =========================
    // 🔹 대사 표시
    // =========================
    void ShowDialogue(int index)
    {
        Dialogue d = dialogues[index];

        nameTextUI.text = nameText[(int)d.speaker];

        int portraitIndex = GetPortraitIndex(d.speaker, d.emotion);
        portraitImage.sprite = portraitArr[portraitIndex];

        portraitImage.color =
            d.speaker == SpeakerType.Unknown
                ? new Color(1f, 1f, 1f, 0.2f)
                : Color.white;

        portraitImage.gameObject.SetActive(true);

        typeEffect.SetMsg(d.text);

        chatCamera?.OnDialogueIndex(index);
        OnDialogueIndexChanged?.Invoke(index);

        // 🔥 스킵 버튼 표시 조건
        if (skipButton != null)
        {
            skipButton.SetActive(index >= 0 && index <= 24);
        }
    }

    IEnumerator EnableSkipAfterDelay()
    {
        skipEnabled = false;

        if (skipButton != null)
            skipButton.SetActive(false);

        yield return new WaitForSeconds(3f);

        skipEnabled = true;

        if (skipButton != null)
            skipButton.SetActive(true);
    }

    public void SkipToSummary()
    {
        if (!skipEnabled)
            return;

        if (currentIndex >= SUMMARY_INDEX)
            return;

        if (typeEffect.IsTyping())
            typeEffect.Skip();

        chatCamera?.ExitCameraView();

        isMonsterPresentationDone = true;
        hasSent17To18 = true;

        currentIndex = SUMMARY_INDEX;
        ShowDialogue(currentIndex);
    }

    // =========================
    // 🔹 다음 대사 (버튼/클릭)
    // =========================
    public void OnNext()
    {
        // =========================
        // 17번 다이얼로그는 스킵 불가(연출 씬)
        // =========================
        if (currentIndex == 17 && !isMonsterPresentationDone)
        {
            return;
        }

        // =========================
        // 1️⃣ 타이핑 중이면 스킵만
        // =========================
        if (typeEffect.IsTyping())
        {
            typeEffect.Skip();

            // 🔥 17번 몬스터 연출 중에는 Idle로 복귀하지 않음
            if (ShouldExitCameraView(currentIndex))
                chatCamera?.ExitCameraView();

            return;
        }

        // =========================
        // 2️⃣ 마지막 대사 종료 대기
        // =========================
        if (isWaitingForEndConfirm)
        {
            EndDialogue();
            return;
        }

        // =========================
        // 3️⃣ 17 → 18 전환 처리
        // =========================
        // 17 → 18 트랜지션
        if (currentIndex == 17 && isMonsterPresentationDone && !hasSent17To18)
        {
            chatCamera?.Go17To18();
            hasSent17To18 = true;
        }

        // 🔥 CameraViewIdle 탈출 처리
        if (ShouldExitCameraView(currentIndex))
        {
            chatCamera?.ExitCameraView();
        }

        currentIndex++;

        // =========================
        // 4️⃣ 마지막 대사는 보여주기만
        // =========================
        if (currentIndex == dialogues.Count - 1)
        {
            ShowDialogue(currentIndex);
            isWaitingForEndConfirm = true;
            return;
        }

        // =========================
        // 5️⃣ 일반 대사
        // =========================
        if (currentIndex < dialogues.Count)
        {
            ShowDialogue(currentIndex);
        }
    }

    // ViewIdle 도착 시 YBot 애니메이션 트리거
    void OnCameraViewIdleReached()
    {
        if (player == null) return;

        Animator anim = player.GetComponent<Animator>();
        if (anim == null) return;

        if (triggerD0AnimIndices.Contains(currentIndex))
        {
            anim.SetTrigger("D0_DoAnim");
        }
        else if (triggerD8AnimIndices.Contains(currentIndex))
        {
            anim.SetTrigger("D8_DoAnim");
        }
    }


    bool ShouldExitCameraView(int index)
    {
        return exitCameraViewIndices.Contains(index);
    }

    // =========================
    int GetPortraitIndex(SpeakerType speaker, EmotionType emotion)
    {
        switch (speaker)
        {
            case SpeakerType.YBot:
                return GetYBotPortraitIndex(emotion);

            // Unknown = Manager
            case SpeakerType.Unknown:
            case SpeakerType.Manager:
                return 6;

            default:
                return 0;
        }
    }

    int GetYBotPortraitIndex(EmotionType emotion)
    {
        switch (emotion)
        {
            case EmotionType.Normal:
                return 0;
            case EmotionType.Surprised:
                return 1;
            case EmotionType.Scared:
                return 2;
            case EmotionType.Depressed:
                return 3;
            case EmotionType.ThinkingOrCurious:
                return 4;
            case EmotionType.Enlightened:
                return 5;
            default:
                return 0;
        }
    }

    void EndDialogue()
    {
        portraitImage.gameObject.SetActive(false);
        nameTextUI.text = "";

        chatCamera?.ResetToIdle();

        // ChatBGM 종료 → BGM 0(스테이지 내부 브금) 재생
        BackgroundMusicManager.Instance?.EndChatBgmAndPlayNormalBgm(0);

        Debug.Log("Dialogue End");
        OnDialogueFinished?.Invoke();

        player?.SetChatMode(false);  // 🔓 게임 재개
    }

    // =========================
    // 🔹 샘플 데이터
    // =========================
    void GenerateData()
    {
        dialogues.Clear();

        dialogues.Add(new Dialogue  // 0 : 캐릭터 줌인, 놀라는 애니메이션
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.Surprised,
            text = "어라, 여기가 어디지? 내 모습은 또 왜 이래?" // 놀란 Y Bot
        });

        dialogues.Add(new Dialogue  // 1 : 주위를 살피는 애니메이션
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.Scared,
            text = "어디선가 인기척이 느껴져. 누가 여기에 있나?"  // 겁먹은 Y Bot
        });

        dialogues.Add(new Dialogue  // 2 : 멀리서 렌더
        {
            speaker = SpeakerType.Unknown,
            emotion = EmotionType.Normal,
            text = "뱀젬 게임에 참여하게 된 것을 진심으로 환영한다."    // ???
        });

        dialogues.Add(new Dialogue  // 3 : 놀라는 애니메이션
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.Scared,
            text = "깜짝이야!! 누구세요?? 어디서 얘기하는 거예요?"    // 겁먹은 Y Bot
        });

        dialogues.Add(new Dialogue  // 4 : 멀리서 렌더
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "나는 이 게임을 창조한 매니저다. 너는 쉽게 이 곳에서 탈출할 수 없을 것이다!"

        });
        dialogues.Add(new Dialogue  // 5 : 멀리서 렌더
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "너는 앞으로 30분 동안 험악하게 생긴 많은 몬스터들을 죽여야만 한다!\n"
                    + "그것이 이 게임에서 살아남는 유일한 방법이다."
        });

        dialogues.Add(new Dialogue  // 6 : 놀라는 애니메이션, 카메라 쉐이크
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.ThinkingOrCurious,
            text = "네?? 제가 여기에 갇힌 것도 모자라서, 탈출을 하라고요?"
        });

        dialogues.Add(new Dialogue  // 7: 멀리서 렌더
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "그래. 이것은 너에게 주는 형벌이다. 난 처음부터 너의 그 얼굴이 마음에 안 들었어!!"
        });

        dialogues.Add(new Dialogue  // 8 : 카메라 쉐이크 이후 낙담한 애니메이션
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.Depressed,
            text = "아... 이 시대에 외모를 무시하다니. 정말로 너무하군요."
        });

        dialogues.Add(new Dialogue  // 9 : 애니메이션 8 마지막 프레임 위치를 유지
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.ThinkingOrCurious,
            text = "그런데, 그 몬스터들이 누구인가요?"
        });

        dialogues.Add(new Dialogue  // 10
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "내가 친절히 알려주마. 몬스터들은 총 5종류다. 일반 몬스터 4종류와 보스 몬스터로 구성되어있다.\n"
                    + "또한 이 게임의 전체 플레이타임은 총 30분이지."
        });

        dialogues.Add(new Dialogue  // 11
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "초반 20분 동안은 일반 몬스터들이 끊임없이 너에게 다가올거야.\n" 
                    + "그 일반 몬스터들을 잡으면 등장하는 증강을 획득하여 너를 성장시켜라."
        });

        dialogues.Add(new Dialogue  // 12
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "그리고 남은 10분 동안은 너를 지옥으로 이끌어가는 무시무시한 보스 몬스터를 잡아야 한다!\n"
                    + "보스 몬스터는 너가 상상했던 그 이상으로 무서울 것이다!! 흐흐흐."
        });

        dialogues.Add(new Dialogue  // 13
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "스테이지를 클리어하기 위해서는 너가 속성을 잘 골라야 할 것이다."
        });

        dialogues.Add(new Dialogue  // 14
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "처음 너는 속성을 갖고있지 않아. 몬스터를 처치하면 떨어지는 크리스탈을 흡수해서 너의 색상을 얻도록 해!"
        });

        dialogues.Add(new Dialogue  // 15
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "설명이 부족하다고 느끼나? 더 자세하게 알려주마."
        });

        dialogues.Add(new Dialogue  // 16 : 속성 띄워주기
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "속성은 각각 레드, 그린, 블루, 퍼플 네 가지로 나뉜다."
        });

        dialogues.Add(new Dialogue  // 17
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "또한 몬스터도 각각 레드 슬라임, 그린 캑터스, 블루 터틀쉘, 퍼플 비홀더로 나뉘지."
        });

        dialogues.Add(new Dialogue  // 18
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "속성을 흡수한 후에는 몬스터를 통해 능력치를 향상시킬 수 있는 \'증강 상자\'를 보게 될 거야."
        });

        dialogues.Add(new Dialogue  // 19
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.ThinkingOrCurious,
            text = "\'증강 상자\'요? 그게 무엇인가요? 더 자세히 알려주세요!"
        });

        dialogues.Add(new Dialogue  // 20
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "증강은 버프 증강과 디버프 증강으로 나뉜다."
        });

        dialogues.Add(new Dialogue  // 21
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "너의 속성과 다른 속성의 몬스터를 잡으면 버프 증강 상자를 얻을 수 있고, 처치한 위치에 상자가 드랍될 거야."
        });

        dialogues.Add(new Dialogue  // 22
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "하지만 너의 속성과 같은 속성의 몬스터를 처치하면 디버프 증강 상자를 강제로 선택해야 한다!"
        });

        dialogues.Add(new Dialogue  // 23
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "그 상자는 너에게 불이익을 줄 것이다. 선택하지 않으면 내가 랜덤으로 골라주지. 흐흐."
        });

        dialogues.Add(new Dialogue  // 24
        {
            speaker = SpeakerType.Manager,
            emotion = EmotionType.Normal,
            text = "더 궁금한 것이 있다면 우측 상단의 도움말 버튼을 눌러보도록 하게나. 나는 여기까지일세."
        });

        dialogues.Add(new Dialogue  // 25
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.ThinkingOrCurious,
            text = "음... 정리하자면 전체 플레이타임은 30분이고,"
        });

        dialogues.Add(new Dialogue  // 26
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.ThinkingOrCurious,
            text = "초반 20분 동안 일반 몬스터를 처치하면서 속성을 얻고 증강 상자로 능력치를 강화한 뒤,"
        });

        dialogues.Add(new Dialogue  // 27
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.ThinkingOrCurious,
            text = "남은 10분 동안 보스 몬스터를 처치하면 스테이지를 이기는 뱀서라이크 장르의 게임이구나."
        });

        dialogues.Add(new Dialogue  // 28
        {
            speaker = SpeakerType.YBot,
            emotion = EmotionType.Enlightened,
            text = "오케이! 이제 이해됐다. 그럼, 시작해볼까?"
        });
    }
}