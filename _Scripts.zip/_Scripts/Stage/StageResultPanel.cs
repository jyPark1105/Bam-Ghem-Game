﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class StageResultPanel : MonoBehaviour
{
    public static StageResultPanel Instance;

    [Header("Panel Root")]
    public GameObject panelRoot;

    [Header("Title")]
    public TMP_Text titleText;

    [Header("Stars")]
    public Image star1;
    public Image star2;
    public Image star3;
    public Sprite starOn;
    public Sprite starOff;

    [Header("Monster Dynamic UI")]
    public Transform monsterContentParent;    // Content 오브젝트
    public GameObject monsterRowPrefab;       // MonsterRow 행 Prefab    

    [Header("Monster Icons")]
    public Sprite slimeIcon;
    public Sprite turtleIcon;

    private Dictionary<EnemyAI.MonsterType, Sprite> monsterIcons;

    [Header("Damage Info")]
    public TMP_Text damageDealtText;
    public TMP_Text damageTakenText;

    [Header("Total Kill Info")]
    public TMP_Text totalKillText;

    [Header("Skill Usage")]
    public TMP_Text attackText;
    public TMP_Text attackSlashText;
    public TMP_Text skillAText;
    public TMP_Text climbText;
    public TMP_Text dodgeText;
    public TMP_Text jumpText;
    public TMP_Text getItemText;

    //[Header("Absorb Info (Optional)")]
    //public TMP_Text absorbElementText;
    //public TMP_Text absorbCountText;

    [Header("Stage UI")]
    public TMP_Text clearTimeText;
    public TMP_Text clearModeText;
    //public 

    [Header("Reward")]
    public TMP_Text coinText;
    public TMP_Text trophyText;
    public TMP_Text expText;

    [Header("Buttons")]
    public Button confirmButton;

    // ==================================================
    // 🔥 Singleton 설정
    // ==================================================
    private void Awake()
    {
        Instance = this;
        panelRoot.SetActive(false);

        monsterIcons = new Dictionary<EnemyAI.MonsterType, Sprite>()
        {
            { EnemyAI.MonsterType.Slime, slimeIcon },
            { EnemyAI.MonsterType.TurtleShell, turtleIcon }
        };
    }

    // ==================================================
    // 🔥 UI 보여주기
    // ==================================================
    public void Show(StageResultData result)
    {
        panelRoot.SetActive(true);

        // 타이틀
        titleText.text = result.isClear ? "STAGE CLEAR!" : "FAILED";

        // ⭐ 별 표시
        int starCount = 0;
        int stageNumber;
#if UNITY_EDITOR
        stageNumber = 1;
#else
        stageNumber = result.stageNumber;
#endif

        var record = GameManager.Instance?.GetStageRecord(stageNumber); // result.stageNumber 인자로 투입
        Debug.Log("record: " + record);

        if (record != null)
        {
            // 기록 있는데 깬 경우
            if (record.starCount >= 1)
            {
                if (result.starCount >= record.starCount)
                {
                    StageLogPanel.Log("최고 기록 갱신!");
                    starCount = result.starCount;   // 최고 기록 갱신
                }
                else
                {
                    StageLogPanel.Log("최고 기록 갱신 실패");
                    starCount = record.starCount;   // 갱신 x
                }
            }
            else
            {
                StageLogPanel.Log("최초 기록 갱신함");
                starCount = result.starCount;   // 새 기록 갱신
            } 
        }
        else
        {
            StageLogPanel.Log($"[StageResultPanel] StageRecord is NULL for stage {result.stageNumber}");
        }

        UpdateStars(starCount);

        // 시간 및 난이도
        clearTimeText.text = $"{result.clearTime:F1} / {result.totalStageTime:F1} sec";
        clearModeText.text = "(" + result.difficulty + ")";

        // 🔥 몬스터 UI 동적 생성
        foreach (Transform child in monsterContentParent)
            Destroy(child.gameObject);

        foreach (var kv in result.monsterResults)
        {
            EnemyAI.MonsterType type = kv.Key;
            MonsterResult r = kv.Value;

            GameObject row = Instantiate(monsterRowPrefab, monsterContentParent);
            MonsterRowUI ui = row.GetComponent<MonsterRowUI>();

            Sprite icon = monsterIcons.ContainsKey(type) ? monsterIcons[type] : null;

            ui.Setup(
                icon,
                r.total,
                r.killed,
                r.criticalKilled,
                r.attackCount,
                r.extinctionCount
            );
        }

        // 데미지 정보
        damageDealtText.text = result.damageDealt.ToString();
        damageTakenText.text = result.damageTaken.ToString();

        // 처치 정보
        totalKillText.text = $"{result.totalKills} ({result.totalCriticalKills})";

        // 스킬 정보
        attackText.text = result.useSkillAttack.ToString();
        //attackSlashText.text = result.useSkillAttackSlash.ToString();
        skillAText.text = result.useSkillSkillA.ToString();
        climbText.text = result.useSkillClimb.ToString();
        dodgeText.text = result.useSkillDodge.ToString();
        jumpText.text = result.useSkillJump.ToString();
        getItemText.text = result.useSkillGetItem.ToString();

        // 흡수 정보
        //if (absorbElementText != null) absorbElementText.text = result.absorbedElement;
        //if (absorbCountText != null) absorbCountText.text = result.absorbedCount.ToString();

        // 🔥 보상 정보 (rewardFinal NULL 방지)
        int coin = 0;
        int trophy = 0;
        int exp = 0;

        if (result.rewardFinal != null)
        {
            coin = result.rewardFinal.coin;
            trophy = result.rewardFinal.trophy;
            exp = result.rewardFinal.exp;
        }
        else
        {
            Debug.LogWarning("[StageResultPanel] rewardFinal is NULL → fallback to 0");
        }

        // UI 적용
        coinText.text = $" + {coin}";
        trophyText.text = $" + {trophy}";
        expText.text = $" + {exp}";

        // 버튼
        confirmButton.onClick.RemoveAllListeners();
        confirmButton.onClick.AddListener(() =>
        {
            panelRoot.SetActive(false);
            DebugManager.Log("[StageResultPanel] Confirm clicked → unloading stage");

            // 🔥 StageManager로 언로드 요청
            StageManager.Instance.OnResultConfirmed();
        });
    }

    // ==================================================
    // ⭐ 별 갱신
    // ==================================================
    private void UpdateStars(int starCount)
    {
        star1.sprite = (starCount >= 1) ? starOn : starOff;
        star2.sprite = (starCount >= 2) ? starOn : starOff;
        star3.sprite = (starCount >= 3) ? starOn : starOff;
    }
}