﻿using UnityEngine;
using System.Collections.Generic;

public static class PauseManager
{
    private static int pauseRequestCount = 0;
    public static bool IsPaused => pauseRequestCount > 0;

    // 🔥 등록된 Enemy 캐시
    private static readonly List<EnemyPauseBridge> enemies = new List<EnemyPauseBridge>(64);

    public static void RequestPause()
    {
        pauseRequestCount++;
        Apply();
    }

    public static void ReleasePause()
    {
        pauseRequestCount = Mathf.Max(0, pauseRequestCount - 1);
        Apply();
    }

    private static void Apply()
    {
        // UI 보호
        Time.timeScale = 1f;

        ApplyEnemyPause(IsPaused);

        if (!IsPaused)
        {
            RestorePlayerState();
        }
    }

    // =========================
    // Player 복구 (기존 유지)
    // =========================
    private static void RestorePlayerState()
    {
        var player = Object.FindFirstObjectByType<StarterAssets.ThirdPersonController>();
        if (player == null) return;

        player.SetBusy(false);
        player.EnableAllInputs();
    }

    // =========================
    // Enemy Pause 처리
    // =========================
    private static void ApplyEnemyPause(bool paused)
    {
        // 🔥 Find 없음, 캐시 순회만
        for (int i = enemies.Count - 1; i >= 0; i--)
        {
            var e = enemies[i];
            if (e == null)
            {
                enemies.RemoveAt(i);
                continue;
            }

            e.SetPaused(paused);
        }
    }

    // =========================
    // Enemy 등록 API
    // =========================
    public static void RegisterEnemy(EnemyPauseBridge enemy)
    {
        if (enemy == null) return;
        if (!enemies.Contains(enemy))
            enemies.Add(enemy);
    }

    public static void UnregisterEnemy(EnemyPauseBridge enemy)
    {
        if (enemy == null) return;
        enemies.Remove(enemy);
    }
}