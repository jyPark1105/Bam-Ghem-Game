﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum StatusEffectType
{
    Bleed,      // Red
    Slow,       // Green
    Shock,      // Blue (DEF 감소)
    Poison      // Purple
}

public class EnemyStatusController : MonoBehaviour
{
    private EnemyAI enemy;

    private Dictionary<StatusEffectType, Coroutine> activeEffects
        = new();

    private void Awake()
    {
        enemy = GetComponent<EnemyAI>();
    }

    public void ApplyStatus(StatusEffectType type, float duration)
    {
        if (activeEffects.ContainsKey(type))
        {
            StopCoroutine(activeEffects[type]);
            activeEffects.Remove(type);
        }

        Coroutine c = StartCoroutine(StatusRoutine(type, duration));
        activeEffects.Add(type, c);
    }

    IEnumerator StatusRoutine(StatusEffectType type, float duration)
    {
        switch (type)
        {
            case StatusEffectType.Bleed:
                yield return Bleed(duration);
                break;

            case StatusEffectType.Slow:
                yield return Slow(duration);
                break;

            case StatusEffectType.Shock:
                yield return Shock(duration);
                break;

            case StatusEffectType.Poison:
                yield return Poison(duration);
                break;
        }

        activeEffects.Remove(type);
    }

    // =============================
    // 🔴 BLEED (Red)
    // =============================
    IEnumerator Bleed(float duration)
    {
        float timer = 0f;

        while (timer < duration)
        {
            enemy.TakeDamage(new DamageInfo
            {
                physical = 6f,
                magical = 0f,
                isCritical = false,
                damageType = DamageText.DamageType.Physical
            });

            yield return new WaitForSeconds(1f);
            timer += 1f;
        }
    }

    // =============================
    // 🟢 SLOW (Green)
    // =============================
    IEnumerator Slow(float duration)
    {
        float originalRun = enemy.stats.runSpeed;
        float originalWalk = enemy.stats.walkSpeed;

        enemy.stats.runSpeed *= 0.6f;
        enemy.stats.walkSpeed *= 0.6f;

        yield return new WaitForSeconds(duration);

        enemy.stats.runSpeed = originalRun;
        enemy.stats.walkSpeed = originalWalk;
    }

    // =============================
    // 🔵 SHOCK (Blue)
    // =============================
    IEnumerator Shock(float duration)
    {
        float originalPDEF = enemy.stats.physicalDEF;
        float originalMDEF = enemy.stats.magicDEF;

        enemy.stats.physicalDEF *= 0.6f;
        enemy.stats.magicDEF *= 0.6f;

        yield return new WaitForSeconds(duration);

        enemy.stats.physicalDEF = originalPDEF;
        enemy.stats.magicDEF = originalMDEF;
    }

    // =============================
    // 🟣 POISON (Purple)
    // =============================
    IEnumerator Poison(float duration)
    {
        float timer = 0f;

        while (timer < duration)
        {
            enemy.TakeDamage(new DamageInfo
            {
                physical = 0f,
                magical = 6f,
                isCritical = false,
                damageType = DamageText.DamageType.Magical
            });

            yield return new WaitForSeconds(1f);
            timer += 1f;
        }
    }
}