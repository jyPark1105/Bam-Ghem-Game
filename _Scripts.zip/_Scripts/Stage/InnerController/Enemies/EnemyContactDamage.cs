﻿using UnityEngine;

public class EnemyContactDamage : MonoBehaviour
{
    public EnemyAI enemy;
    public float contactDamage = 1f; // ⭐ 몬스터별 설정

    private void Awake()
    {
        if (enemy == null)
            enemy = GetComponent<EnemyAI>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        PlayerStatus player = other.GetComponent<PlayerStatus>();
        if (player == null) return;

        player.TakeContactDamage(contactDamage);
        StageManager.Instance?.OnDamageTaken(Mathf.RoundToInt(contactDamage));
    }
}