﻿using UnityEngine;
using UnityEngine.AI;
using System.Collections;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using System.Threading;

[System.Serializable]
public struct MonsterStats
{
    public float health;

    // Defense
    public float physicalDEF;
    public float magicDEF;

    // Attack
    public float physicalATK;   // 🔥 추가
    public float magicATK;      // 🔥 추가

    // Move & AI
    public float walkSpeed;
    public float runSpeed;
    public float detectDistance;
    public float attackDistance;
    public float attackCooldown;
}

public class EnemyAI : MonoBehaviour
{
    [Header("Attack Type Ratio")]
    [Range(0f, 1f)]
    public float rangedAttackChance = 0.3f; // 30%

    private EnemyRangedAttack rangedAttack;
    public enum ElementType
    {
        Red,
        Blue,
        Green,
        Purple
    }

    [Header("Element")]
    public ElementType elementType;

    [Header("Absorb Drop")] // 몬스터 처치 시 드랍하는 "속성 아이템"
    public GameObject absorbItemPrefab; // Absorb_Red, Absorb_Blue 등

    public enum State
    {
        Idle,
        Walk,
        Run,
        Attack,
        GetHit,
        Defend,        // 🔥 추가
        Die
    }
    public State currentState = State.Idle;

    public enum MonsterType
    {
        Slime,
        TurtleShell,
        Cactus,
        Beholder
    }
    public MonsterType monsterType;

    // Beholder 전용 공격 토글
    [SerializeField] bool beholderUseRepeat = false;

    [Header("Monster Stats")]
    public MonsterStats stats;

    [Header("Monster Status")]
    // =========================
    // Status Effects
    // =========================
    public bool isBleeding = false;
    public bool isSlowed = false;
    public bool isShocked = false;
    public bool isPoisoned = false;

    private float bleedTimer;
    private float poisonTimer;

    private float slowTimer;
    private float shockTimer;

    // =========================
    // ORIGINAL STAT STORAGE
    // =========================
    private float originalRunSpeed;
    private float originalWalkSpeed;
    private float originalPDEF;
    private float originalMDEF;

    private const float BLEED_INTERVAL = 1f;
    private const float POISON_INTERVAL = 1f;

    private float bleedTick;
    private float poisonTick;

    [Header("Separation Settings")]
    public float separationRadius = 0.2f;
    public float separationForce = 0.2f;
    public LayerMask monsterMask;

    [Header("FOV Settings")]
    public float viewAngle = 60f;      // 시야각
    public float viewDistance = 0.75f;    // 시야 거리
    public Transform eyePoint;         // 몬스터의 눈 위치(Transform)
    public LayerMask obstacleMask;     // 벽 등 장애물 레이어
    public LayerMask playerMask;       // 플레이어 레이어

    [Header("추적 유지 거리 (공격 후 따라가는 범위)")]
    public float chaseKeepDistance = 1f;

    [Header("Rotation Settings")]
    public float rotationSpeed = 7f;

    [Header("Target")]
    public Transform player;
    public PlayerStatus playerStatus;

    [Header("Death VFX")]
    public GameObject deathVFXPrefab;

    [SerializeField]
    private Transform hpAnchor; // 기존 HPAnchor 그대로 사용

    private Animator animator;
    private NavMeshAgent agent;

    private float timeMult = 1f;

    private bool attackCommitted = false;   // 공격 락 변수
    private Coroutine attackDelayRoutine;

    // =========================
    // Walk State
    // =========================
    private float walkDuration = 0f;
    private float walkTimer = 0f;
    private Vector3 walkDir;

    public float currentHealth;
    private float idleTimer;
    private float attackTimer;
    private bool hasAttackedThisState = false; // 몬스터가 때리고 있는지

    // =========================
    // Die State
    // =========================
    private bool isDead = false;
    public bool IsDead() => isDead;
    private bool freezeLogic = false; // Die 이후 모든 로직 차단 목적 변수

    // =========================
    // Defend State
    // =========================
    private bool isDefending = false;
    private Coroutine defendRoutine;

    [Header("Defend Settings")]
    public float defendDuration = 3f;
    [Range(0f, 1f)]
    public float defendDamageMultiplier = 0.7f; // 🔥 30% 감소

    private bool isJumping = false;

    // Knockback 전용 상태
    private Coroutine knockbackRoutine;
    private bool isInKnockback = false;
    public bool IsInKnockback => isInKnockback;

    // 몬스터 넉백 시 회전값 저장
    private bool prevUpdateRotation;

    // ====================
    // Hit Sound Control
    // ====================
    private bool canPlayHitSound = true;
    private float hitSoundCooldown = 1f;
    private float nextHitSoundTime = 0f;

    // ====================
    // Outline (Hit Feedback)
    // ====================
    private Outline outline;
    // 🔥 타이머 방식 제어
    private bool outlineActive = false;
    private float outlineTimer = 0f;
    public float outlineHitDuration = 1f;

    // SkillR suppression (유지!)
    private bool suppressDamageFeedback = false;
    // ============================
    // 🔊 SkillR Hit Sound Lock
    // ============================
    private static bool skillRHitSoundLocked = false;

    private static Coroutine unlockRoutine;

    // ====================================================================
    private void Awake()
    {
        animator = GetComponent<Animator>();
        agent = GetComponent<NavMeshAgent>();
        rangedAttack = GetComponent<EnemyRangedAttack>();

        outline = GetComponent<Outline>();
        if (outline != null)
            outline.enabled = false;
    }

    private void Start()
    {
        InitializeMonsterStats();
        ApplyDifficultyToStats();

        currentHealth = stats.health;

        if (hpAnchor == null)
            hpAnchor = transform;


        if (HPBarPoolManager.Instance != null)
        {
            HPBarPoolManager.Instance.Register(this, hpAnchor);
        }

        agent.updateRotation = false;
        ChangeState(State.Idle);
        StartCoroutine(IdleRandomRoutine());
    }

    // ====================================================================
    // --- Update ---
    private void Update()
    {
        if (isDead || freezeLogic)
            return;

        if (player == null || playerStatus == null || playerStatus.isDead)
            return;

        float distance = Vector3.Distance(transform.position, player.position);

        attackTimer -= Time.deltaTime;

        // 🔥 이미 공격 결심했으면 거리 무시
        if (attackCommitted)
            return;

        if (distance <= stats.attackDistance && attackTimer <= 0f)
        {
            CommitAttack();   // 🔥 여기 변경
            return;
        }

        ChasePlayer();
        UpdateStatusEffects();  // 몬스터 상태 처리
    }

    private void CommitAttack()
    {
        attackCommitted = true;
        currentState = State.Attack;

        agent.isStopped = true;
        agent.ResetPath();

        if (attackDelayRoutine != null)
            StopCoroutine(attackDelayRoutine);

        attackDelayRoutine = StartCoroutine(AttackDelayRoutine());
    }

    private IEnumerator AttackDelayRoutine()
    {
        yield return new WaitForSeconds(0.15f);  // 🔥 묵직한 선딜

        StartAttack();
    }

    private void StartAttack()
    {
        attackTimer = stats.attackCooldown;

        if (monsterType == MonsterType.Beholder)
        {
            bool useRepeat = !beholderUseRepeat && Random.value < 0.5f;

            animator.SetTrigger(useRepeat ? "AttackRepeat" : "AttackOnce");
            beholderUseRepeat = useRepeat;
        }
        else
        {
            animator.SetTrigger("Attack");
        }
    }

    private void ChasePlayer()
    {
        if (!agent.isOnNavMesh) return;

        agent.isStopped = false;
        agent.speed = stats.runSpeed;

        agent.SetDestination(player.position);

        Vector3 dir = (player.position - transform.position).normalized;
        dir.y = 0f;

        if (dir.sqrMagnitude > 0.01f)
        {
            Quaternion targetRot = Quaternion.LookRotation(dir);
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                targetRot,
                rotationSpeed * Time.deltaTime
            );
        }

        animator.SetFloat("Speed", agent.velocity.magnitude);
    }

    // 몬스터 상태 초기화 함수(생성 시 호출)
    private void InitializeMonsterStats()
    {
        switch (monsterType)
        {
            case MonsterType.Slime:
                stats.health = 30f;

                // 🛡 DEF
                stats.physicalDEF = 1f;
                stats.magicDEF = 1f;

                // ⚔ ATK
                stats.physicalATK = 5f;
                stats.magicATK = 0f;

                // Move
                stats.walkSpeed = 1.4f;
                stats.runSpeed = 2.4f;

                // Attack
                stats.detectDistance = 2.5f;
                stats.attackDistance = 0.75f;
                stats.attackCooldown = 1.1f;
                break;

            case MonsterType.TurtleShell:
                stats.health = 85f;

                // 🛡 DEF
                stats.physicalDEF = 6f;
                stats.magicDEF = 4f;

                // ⚔ ATK
                stats.physicalATK = 8f;
                stats.magicATK = 0f;

                // Move
                stats.walkSpeed = 1.2f;
                stats.runSpeed = 2.0f;

                // Attack
                stats.detectDistance = 3f;
                stats.attackDistance = 0.75f;
                stats.attackCooldown = 2.5f;
                break;

            case MonsterType.Cactus:
                stats.health = 55f;

                stats.physicalDEF = 2f;
                stats.magicDEF = 3f;

                stats.physicalATK = 14f;
                stats.magicATK = 0f;

                stats.walkSpeed = 1.0f;
                stats.runSpeed = 1.8f;

                stats.detectDistance = 3.0f;
                stats.attackDistance = 1.0f;
                stats.attackCooldown = 1.4f;
                break;

            case MonsterType.Beholder:
                stats.health = 70f;

                stats.physicalDEF = 2f;
                stats.magicDEF = 6f;

                stats.physicalATK = 0f;
                stats.magicATK = 18f;

                stats.walkSpeed = 0.8f;
                stats.runSpeed = 1.6f;

                stats.detectDistance = 3.5f;
                stats.attackDistance = 2.5f; // 원거리
                stats.attackCooldown = 1.8f;
                break;
        }

        agent.speed = stats.walkSpeed;
        agent.stoppingDistance = stats.attackDistance * 0.8f;
    }

    private void ApplyDifficultyToStats()
    {
        stats.health *= DifficultyManager.HP_Multiplier;
        stats.walkSpeed *= DifficultyManager.MoveSpeed_Multiplier;
        stats.runSpeed *= DifficultyManager.MoveSpeed_Multiplier;
        stats.detectDistance *= DifficultyManager.Detect_Multiplier;
        stats.attackCooldown *= DifficultyManager.AttackCooldown_Multiplier;
        viewAngle = DifficultyManager.ViewAngle;
        viewDistance = DifficultyManager.ViewDistance;
    }

    // ====================================================================
    // Idle
    // ========================= Idle =========================
    private void IdleUpdate(float distance)
    {
        // FOV로 실제로 보고 있을 때만 Run 전환
        if (CanSeePlayer())
        {
            ChangeState(State.Run);
            return;
        }

        idleTimer -= Time.deltaTime;
        if (idleTimer <= 0)
            ChangeState(State.Walk);
    }

    private IEnumerator IdleRandomRoutine()
    {
        while (!isDead)
        {
            if (currentState == State.Idle)
            {
                float wait = Random.Range(2f, 5f);
                yield return new WaitForSeconds(wait);

                if (currentState == State.Idle)
                {
                    animator.SetTrigger("RandomIdle");
                    animator.SetBool("RandomIdlePlaying", true);
                }
            }
            yield return null;
        }
    }

    public void OnRandomIdleEnd()
    {
        animator.SetBool("RandomIdlePlaying", false);
    }

    // ====================================================================
    // Walk (천천히 접근)
    // ====================================================================
    // Walk (랜덤 이동)
    private void WalkUpdate(float distance)
    {
        if (!agent.isOnNavMesh) return;

        if (CanSeePlayer())
        {
            ChangeState(State.Run);
            return;
        }

        if (walkTimer <= 0)
        {
            walkDuration = Random.Range(1.0f, 3.0f);
            walkTimer = walkDuration;

            float angle = Random.Range(0f, 360f);
            walkDir = Quaternion.Euler(0, angle, 0) * Vector3.forward;
        }

        walkTimer -= Time.deltaTime;

        // 장애물 감지
        if (Physics.Raycast(transform.position + Vector3.up * 0.2f, walkDir, 0.7f, obstacleMask))
            walkDir = -walkDir;

        // Separation 적용
        Vector3 sep = GetSeparationVector();
        Vector3 moveDir = (walkDir + sep).normalized;
        // 회전 보간 적용
        SmoothRotate(moveDir);

        Vector3 targetPos = transform.position + moveDir * 1f;

        agent.isStopped = false;
        agent.speed = stats.walkSpeed;
        agent.SetDestination(targetPos);

        if (walkTimer <= 0)
            ChangeState(State.Idle);
    }

    // ====================================================================
    // Run (빠르게 추격)
    private void RunUpdate(float distance)
    {
        if (!agent.isOnNavMesh) return;

        if (!CanSeePlayer())
        {
            ChangeState(State.Idle);
            return;
        }

        agent.isStopped = false;
        agent.speed = stats.runSpeed;

        Vector3 moveDir = (player.position - transform.position).normalized;
        SmoothRotate(moveDir);
        agent.SetDestination(player.position);

        // 🔥 쿨타임 끝났고 + 사거리면 공격
        if (distance <= stats.attackDistance && attackTimer <= 0f)
        {
            ChangeState(State.Attack);
        }
    }

    // ====================================================================
    // Attack
    // ========================= Attack =========================
    private void AttackUpdate(float distance)
    {
        if (player == null || !CanSeePlayer())
        {
            ChangeState(State.Idle);
            return;
        }

        if (playerStatus != null && playerStatus.isDead)
            return;

        if (hasAttackedThisState)
            return;

        hasAttackedThisState = true;

        // 🔥 공격은 들어오는 순간 1회만
        agent.isStopped = true;

        attackTimer = stats.attackCooldown;

        if (monsterType == MonsterType.Beholder)
        {
            bool useRepeat = !beholderUseRepeat && Random.value < 0.5f;

            animator.SetTrigger(useRepeat ? "AttackRepeat" : "AttackOnce");
            beholderUseRepeat = useRepeat;
        }
        else
        {
            animator.SetTrigger("Attack");
        }

        StageManager.Instance.OnMonsterAttack(monsterType);
    }

    private void EnableOutline(bool on)
    {
        // Outline 컴포넌트 or 머티리얼 키워드
        //outline.enabled = on;
    }

    public void OnRangedFire()
    {
        rangedAttack.Fire();
    }

    // Attack: Last frame event function of the attack animation
    public void OnAttackAnimationEnd()
    {
        if (isDead) return;

        attackCommitted = false;   // 🔥 다시 추적 가능
        currentState = State.Run;
    }

    // ====================================================================
    // Get Hit 이후: Animation Event에서 호출
    public void OnGetHitAnimationEnd()
    {
        if (isDead) return;

        ChangeState(State.Defend);
        animator.SetTrigger("Defend");
    }

    // 기본 공격 & 기본 스킬으로 데미지를 맞았을 때
    public void TakeDamage(DamageInfo info)
    {
        if (isDead) return;

        bool ignoreGetHit = isInKnockback;

        float finalPhysical =
            Mathf.Max(info.physical - stats.physicalDEF, 1f);

        float finalMagical =
            Mathf.Max(info.magical - stats.magicDEF, 1f);

        float finalDamage = finalPhysical + finalMagical;

        if (isDefending)
            finalDamage *= defendDamageMultiplier;

        currentHealth -= finalDamage;
        currentHealth = Mathf.Max(currentHealth, 0f);

        // ==============================
        // 🔥 DamageText (일반 공격만)
        // ==============================
        DamageTextManager.Instance?.ShowDamage(
            transform,
            Mathf.RoundToInt(finalDamage),
            info.damageType,
            false
        );

        if (HPBarPoolManager.Instance != null)
        {
            HPBarPoolManager.Instance.Register(this, hpAnchor);
            HPBarPoolManager.Instance.UpdateHP(this, currentHealth, stats.health);
        }

        // ==============================
        // 🔥 Outline (쿨타임 방식, GC 0)
        // ==============================
        if (outline != null && !outlineActive)
        {
            outlineActive = true;
            outlineTimer = outlineHitDuration;
            outline.enabled = true;
        }

        if (currentHealth <= 0f)
        {
            Die();
            return;
        }

        // ==============================
        // 🔥 GetHit (일반 공격만)
        // ==============================
        if (!ignoreGetHit && !isDefending)
        {
            ChangeState(State.GetHit);
            animator.SetTrigger("GetHit");
        }
    }

    // ==============================
    // 🔥 궁극 스킬 전용 경량 데미지
    // ==============================
    public void TakeDamage_Lite(DamageInfo info)
    {
        if (isDead) return;

        // =========================
        // 데미지 계산 (기존 유지)
        // =========================
        float finalPhysical =
            Mathf.Max(info.physical - stats.physicalDEF, 1f);

        float finalMagical =
            Mathf.Max(info.magical - stats.magicDEF, 1f);

        float finalDamage = finalPhysical + finalMagical;

        if (isDefending)
            finalDamage *= defendDamageMultiplier;

        currentHealth -= finalDamage;
        currentHealth = Mathf.Max(currentHealth, 0f);

        // HP UI는 유지
        HPBarPoolManager.Instance?.UpdateHP(this, currentHealth, stats.health);

        // =========================
        // 🔊 SkillR 사운드 (딱 1번)
        // =========================
        if (!skillRHitSoundLocked)
        {
            skillRHitSoundLocked = true;

            // 👉 이 몬스터만 사운드 담당
            TryPlayHitSound();

            bool diedByThisHit = currentHealth <= 0f;

            if (diedByThisHit)
            {
                AudioManager.Instance?.PlayEnemyDie();
            }

            // 🔓 unlock 예약
            float unlockDelay = GetSkillRSoundUnlockDelay(diedByThisHit);

            if (unlockRoutine != null)
                StopCoroutine(unlockRoutine);

            unlockRoutine =
                StartCoroutine(UnlockSkillRHitSound(unlockDelay));
        }

        // =========================
        // 사망 처리 (사운드는 위에서)
        // =========================
        if (currentHealth <= 0f)
        {
            Die();
        }
    }

    private float GetSkillRSoundUnlockDelay(bool died)
    {
        float hitLen = AudioManager.Instance != null
            ? AudioManager.Instance.GetEnemyHitLength()
            : 0.3f;

        float dieLen = AudioManager.Instance != null
            ? AudioManager.Instance.GetEnemyDieLength()
            : 0.5f;

        float baseLen = died ? Mathf.Max(hitLen, dieLen) : hitLen;

        return baseLen + 0.5f; // 🔥 원복 시간
    }

    private IEnumerator UnlockSkillRHitSound(float delay)
    {
        yield return new WaitForSeconds(delay);
        skillRHitSoundLocked = false;
    }

    // Defend: Last frame event function of the animation
    public void OnDefendAnimationEnd()
    {
        if (isDead) return;

        if (defendRoutine != null)
            StopCoroutine(defendRoutine);

        defendRoutine = StartCoroutine(DefendRoutine());
    }

    // Defend 상태 로직
    private IEnumerator DefendRoutine()
    {
        isDefending = true;

        // 🔒 상태 고정
        State prevState = currentState;
        currentState = State.Defend;

        agent.isStopped = true;

        yield return new WaitForSeconds(defendDuration);

        isDefending = false;
        defendRoutine = null;

        // 🔥 플레이어 존재 여부에 따라 복귀
        if (player != null && CanSeePlayer())
            ChangeState(State.Run);
        else
            ChangeState(State.Idle);
    }

    public void Die()
    {
        if (isDead) return;
        isDead = true;
        freezeLogic = true;

        // 🔥 HP UI 즉시 OFF
        HPBarPoolManager.Instance?.Unregister(this);

        // 🔥 Knockback만 개별 종료
        if (knockbackRoutine != null)
        {
            StopCoroutine(knockbackRoutine);
            knockbackRoutine = null;
        }
        isInKnockback = false;

        // 🔥 Outline OFF
        if (outline != null)
            outline.enabled = false;

        // 🔥 NavMesh 완전 정지
        // 🔥 NavMesh 완전 정지 (안전)
        if (agent != null && agent.enabled)
        {
            if (agent.isOnNavMesh)
            {
                agent.isStopped = true;
                agent.ResetPath();
            }

            agent.enabled = false;
        }

        // 🔥 드랍 처리
        TryDropAbsorbItem();
        TryDropItems();

        // 🔥 사운드
        AudioManager.Instance?.PlayEnemyDie();

        // 🔥 상태 & 애니메이션
        currentState = State.Die;
        animator.ResetTrigger("GetHit");
        animator.ResetTrigger("Attack");
        animator.SetTrigger("Die");

        // 🔥 VFX는 여기서 OK (즉시)
        SpawnDeathVFX();

        // ❗❗ Pool 반환은 여기서 절대 하지 않음
    }

    public void OnDieAnimationFinished()
    {
        if (!gameObject.activeInHierarchy)
            return;

        MonsterPool.Instance.Return(gameObject, monsterType);
    }

    private void TryDropAbsorbItem()
    {
        var absorb = FindFirstObjectByType<PlayerAbsorbEffect>();
        if (absorb == null) return;

        bool playerHasElement = absorb.HasElement();

        // 속성 변환 확률
        float dropChance = playerHasElement ? 0.01f : 1f; // 0.2f;

        if (Random.value > dropChance) return;
        if (absorbItemPrefab == null) return;

        Vector3 dropPos = transform.position + Vector3.up * 0.3f;
        Instantiate(absorbItemPrefab, dropPos, Quaternion.identity);
    }

    // ====================================================================
    // Jump
    // ====================================================================
    private IEnumerator JumpAcrossLink()
    {
        isJumping = true;
        animator.SetBool("IsJumping", true);

        OffMeshLinkData data = agent.currentOffMeshLinkData;
        Vector3 startPos = transform.position;
        Vector3 endPos = data.endPos;

        float duration = 0.45f;
        float t = 0;

        agent.updatePosition = false;
        agent.updateRotation = false;

        while (t < 1f)
        {
            t += Time.deltaTime / duration;
            float height = Mathf.Sin(t * Mathf.PI);
            transform.position = Vector3.Lerp(startPos, endPos, t) + Vector3.up * height * 0.5f;
            yield return null;
        }

        agent.CompleteOffMeshLink();
        agent.updatePosition = true;
        agent.updateRotation = true;

        isJumping = false;
        animator.SetBool("IsJumping", false);
    }

    // ====================================================================
    // Utilities
    // ====================================================================
    private void ChangeState(State newState)
    {
        animator.ResetTrigger("RandomIdle");
        animator.SetBool("RandomIdlePlaying", false);

        currentState = newState;

        switch (newState)
        {
            case State.Idle:
                idleTimer = Random.Range(1f, 3f);
                agent.isStopped = false;
                break;

            case State.Walk:
                walkTimer = 0f;
                agent.isStopped = false;
                break;

            case State.Run:
                agent.isStopped = false;
                break;

            case State.Attack:
                agent.isStopped = true;
                hasAttackedThisState = false;
                break;

            case State.GetHit:
                agent.isStopped = true; // 🔥 맞는 동안만 멈춤
                agent.ResetPath();
                break;
        }
    }

    // 🔥 공격 타격 타이밍 (Animation Event)
    public void OnEnemyAttackHit()
    {
        if (isDead) return;

        AudioManager.Instance?.PlayEnemyAttack();
    }

    // 몬스터 상태 리셋 함수
    public void ResetAI()
    {
        isDead = false;
        freezeLogic = false;
        isJumping = false;

        if (beholderUseRepeat) beholderUseRepeat = false;

        if (animator == null) animator = GetComponent<Animator>();
        if (agent == null) agent = GetComponent<NavMeshAgent>();

        agent.enabled = true;
        agent.isStopped = false;

        // ✅ 여기서 스탯을 "다시" 만든다 (풀 재사용 대응 핵심)
        InitializeMonsterStats();
        ApplyDifficultyToStats();
        ApplyTimeScaling(timeMult);   // ⬅️ 새로 추가한 함수

        currentHealth = stats.health;
        agent.ResetPath();

        ChangeState(State.Idle);

        animator.SetFloat("Speed", 0f);

        // 🔥 HPBar 다시 등록
        HPBarPoolManager.Instance?.Register(this, hpAnchor);
    }

    // ====================================================================
    // Separation
    private Vector3 GetSeparationVector()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, separationRadius, monsterMask);
        Vector3 force = Vector3.zero;
        int count = 0;

        foreach (var h in hits)
        {
            if (h.transform == transform) continue;

            Vector3 diff = transform.position - h.transform.position;
            force += diff.normalized / Mathf.Max(diff.magnitude, 0.01f);
            count++;
        }

        if (count > 0)
            force /= count;

        return force * separationForce;
    }

    // ===================================
    // FOV 값 설정을 통한 플레이어 탐지
    // ===================================
    private bool CanSeePlayer()
    {
        if (player == null || eyePoint == null || playerStatus == null || playerStatus.isDead)
            return false;

        // 🔥 시선 보정 (핵심)
        Vector3 lookDir = player.position - eyePoint.position;
        lookDir.y = 0f;
        if (lookDir.sqrMagnitude > 0.001f)
            eyePoint.rotation = Quaternion.LookRotation(lookDir);

        Vector3 dirToPlayer = lookDir.normalized;
        float dist = lookDir.magnitude;

        float maxDetectDistance = Mathf.Max(viewDistance, stats.detectDistance);
        if (dist > maxDetectDistance)
            return false;

        if (Vector3.Angle(eyePoint.forward, dirToPlayer) > viewAngle * 0.5f)
            return false;

        if (Physics.Raycast(eyePoint.position, dirToPlayer, out RaycastHit hit, dist))
        {
            if (!hit.collider.CompareTag("Player"))
                return false;
        }

        return true;
    }

    // 자연스러운 회전 함수
    private void SmoothRotate(Vector3 moveDir)
    {
        if (moveDir.sqrMagnitude < 0.001f) return;

        Quaternion targetRot = Quaternion.LookRotation(moveDir);
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, rotationSpeed * Time.deltaTime);
    }

    // 몬스터 Hit Sound 함수
    public void TryPlayHitSound()
    {
        if (Time.time < nextHitSoundTime) return;

        AudioManager.Instance?.PlayEnemyHit();
        nextHitSoundTime = Time.time + hitSoundCooldown;
    }

    // ===================================
    // Enemy 시각화 함수
    // ===================================
    private void OnDrawGizmos()
    {
        if (eyePoint == null) return;

        // =============== 기본 원 (거리) ===============
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(eyePoint.position, viewDistance);

        // =============== 시야 부채꼴(FOV) ===============
        int segments = 30; // 세밀도 (높을수록 매끄러움)
        float halfAngle = viewAngle * 0.5f;

        Vector3 startDir = Quaternion.Euler(0, -halfAngle, 0) * eyePoint.forward;

        Gizmos.color = new Color(1f, 0f, 0f, 0.4f); // 반투명 빨강

        Vector3 prevPoint = eyePoint.position + startDir * viewDistance;

        for (int i = 1; i <= segments; i++)
        {
            // 현재 세그먼트 방향
            float step = (viewAngle / segments) * i;
            Vector3 nextDir = Quaternion.Euler(0, -halfAngle + step, 0) * eyePoint.forward;

            Vector3 nextPoint = eyePoint.position + nextDir * viewDistance;

            // 삼각형 면적처럼 FOV 내부를 채우는 선 그리기
            Gizmos.DrawLine(eyePoint.position, nextPoint);
            Gizmos.DrawLine(prevPoint, nextPoint);

            prevPoint = nextPoint;
        }

        // =============== 시야 경계선 두 개 (좌/우) ===============
        Gizmos.color = Color.red;

        Vector3 leftBoundary = Quaternion.Euler(0, -halfAngle, 0) * eyePoint.forward;
        Vector3 rightBoundary = Quaternion.Euler(0, halfAngle, 0) * eyePoint.forward;

        Gizmos.DrawLine(eyePoint.position, eyePoint.position + leftBoundary * viewDistance);
        Gizmos.DrawLine(eyePoint.position, eyePoint.position + rightBoundary * viewDistance);
    }

    public bool CanSeePlayer_Public()
    {
        return CanSeePlayer();
    }

    private void TryDropItems()
    {
        var absorb = FindFirstObjectByType<PlayerAbsorbEffect>();
        if (absorb == null) return;

        bool playerHasElement = absorb.HasElement();

        Vector3 dropPos = transform.position + Vector3.up * 0.3f;

        // =========================
        // 1️⃣ 속성 아이템 드랍
        //    - 플레이어가 아직 속성 없을 때만
        // =========================
        if (!playerHasElement)
        {
            float attrChance = 0.20f; // 최초 획득 확률

            if (absorbItemPrefab != null && Random.value <= attrChance)
            {
                Instantiate(absorbItemPrefab, dropPos, Quaternion.identity);
            }

            // 🔒 속성 없을 땐 여기서 종료
            return;
        }

        // =========================
        // 2️⃣ 증강 상자 드랍 (핵심)
        //    - 속성 보유 이후부터
        // =========================
        if (DropManager.Instance != null)
        {
            DropManager.Instance.TryDropAugmentChest(
                transform.position,
                elementType   // 몬스터 속성
            );
        }

        // ❌ A / B / C 드랍 로직 완전 제거
    }

    // Outline OFF 코루틴
    private IEnumerator OutlineHitRoutine()
    {
        outline.enabled = true;
        yield return new WaitForSeconds(outlineHitDuration);
        outline.enabled = false;
    }

    // SkillR_<COLOR>의 넉백 기능 함수(예: SkillR_Red 폭발 시 몬스터 넉백 됨)
    public void ApplyKnockback(Vector3 force, float duration = 0.3f)
    {
        if (isDead) return;

        // ============================
        // 🔥 Defend 중 넉백 면역
        // ============================
        if (isDefending)
            return;

        if (knockbackRoutine != null)
            StopCoroutine(knockbackRoutine);

        knockbackRoutine =
            StartCoroutine(KnockbackRoutine(force, duration));
    }


    private IEnumerator KnockbackRoutine(Vector3 force, float duration)
    {
        isInKnockback = true;

        // ============================
        // 🔒 회전 고정 (묵직함 핵심)
        // ============================
        if (agent != null && agent.enabled)
        {
            prevUpdateRotation = agent.updateRotation;
            agent.updateRotation = false;
        }

        // NavMesh 정지
        if (agent != null && agent.enabled && agent.isOnNavMesh)
            agent.isStopped = true;

        Vector3 velocity = force / duration;
        float t = 0f;

        while (t < duration)
        {
            transform.position += velocity * Time.deltaTime;
            t += Time.deltaTime;
            yield return null;
        }

        // ============================
        // 🔥넉백 종료 후 NavMesh 복귀
        // ============================
        if (!isDead && agent != null && agent.enabled)
        {
            if (!agent.isOnNavMesh)
            {
                NavMeshHit hit;

                // 반경 2~4 정도면 충분 (상황 따라 조절)
                if (NavMesh.SamplePosition(
                    transform.position,
                    out hit,
                    3.0f,
                    NavMesh.AllAreas
                ))
                {
                    agent.Warp(hit.position);
                }
                else
                {
                    // ❗ 극단적 예외: 못 찾으면 그냥 멈춘다
                    agent.enabled = false;
                    agent.enabled = true;
                }
            }

            agent.isStopped = false;
        }

        // 🔁 회전 복구
        agent.updateRotation = prevUpdateRotation;

        // 넉백 상태 초기화
        isInKnockback = false;
        knockbackRoutine = null;
    }

    public void BindPlayer(PlayerStatus ps)
    {
        if (ps == null)
        {
            Debug.LogError("[EnemyAI] BindPlayer failed: PlayerStatus is null");
            return;
        }

        playerStatus = ps;
        player = ps.transform;
    }

    // 소멸 함수
    private void SpawnDeathVFX()
    {
        if (deathVFXPrefab == null) return;

        Vector3 pos = transform.position + Vector3.up * 0.3f;
        Instantiate(deathVFXPrefab, pos, Quaternion.identity);
    }

    public void BeginSkillRSuppression()
    {
        suppressDamageFeedback = true;
    }

    public void EndSkillRSuppression()
    {
        suppressDamageFeedback = false;

    }

    public void SetTimeMultiplier(float m)
    {
        timeMult = Mathf.Max(1f, m);
    }


    private void ApplyTimeScaling(float m)
    {
        // 체력은 그대로 곱 (가장 중요한 성장)
        stats.health *= m;

        // 공격은 m보다 살짝 덜 키우면 "즉사겜" 덜 됨
        float atkMult = Mathf.Lerp(1f, m, 0.85f); // m의 85%만 반영
        stats.physicalATK *= atkMult;
        stats.magicATK *= atkMult;

        // 방어는 더 완만하게 (너 TakeDamage가 '최소 1' 보정이라 DEF 너무 올리면 이득이 과해짐)
        float defMult = Mathf.Lerp(1f, m, 0.55f); // m의 55%만 반영
        stats.physicalDEF *= defMult;
        stats.magicDEF *= defMult;

        // 이동속도는 아주 약하게만 (원하면 끄면 됨)
        float speedMult = Mathf.Lerp(1f, m, 0.10f); // 10%만 반영
        stats.walkSpeed *= speedMult;
        stats.runSpeed *= speedMult;
    }

    private void UpdateStatusEffects()
    {
        float dt = Time.deltaTime;

        // =========================
        // BLEED
        // =========================
        if (isBleeding)
        {
            bleedTimer -= dt;
            bleedTick += dt;

            if (bleedTick >= BLEED_INTERVAL)
            {
                bleedTick = 0f;

                TakeDamage(new DamageInfo
                {
                    physical = 5f,
                    magical = 0f,
                    isCritical = false,
                    damageType = DamageText.DamageType.Physical
                });
            }

            if (bleedTimer <= 0f)
            {
                isBleeding = false;
            }
        }

        // =========================
        // POISON
        // =========================
        if (isPoisoned)
        {
            poisonTimer -= dt;
            poisonTick += dt;

            if (poisonTick >= POISON_INTERVAL)
            {
                poisonTick = 0f;

                TakeDamage(new DamageInfo
                {
                    physical = 0f,
                    magical = 5f,
                    isCritical = false,
                    damageType = DamageText.DamageType.Magical
                });
            }

            if (poisonTimer <= 0f)
            {
                isPoisoned = false;
            }
        }

        // =========================
        // SLOW
        // =========================
        if (isSlowed)
        {
            slowTimer -= dt;

            if (slowTimer <= 0f)
            {
                isSlowed = false;

                stats.runSpeed = originalRunSpeed;
                stats.walkSpeed = originalWalkSpeed;
            }
        }

        // =========================
        // SHOCK
        // =========================
        if (isShocked)
        {
            shockTimer -= dt;

            if (shockTimer <= 0f)
            {
                isShocked = false;

                stats.physicalDEF = originalPDEF;
                stats.magicDEF = originalMDEF;
            }
        }
    }

    public void ApplyBleed(float duration)
    {
        isBleeding = true;
        bleedTimer = duration;
    }

    public void ApplyPoison(float duration)
    {
        isPoisoned = true;
        poisonTimer = duration;
    }

    public void ApplySlow(float duration)
    {
        if (!isSlowed)
        {
            originalRunSpeed = stats.runSpeed;
            originalWalkSpeed = stats.walkSpeed;

            stats.runSpeed *= 0.6f;
            stats.walkSpeed *= 0.6f;
        }

        isSlowed = true;
        slowTimer = duration;
    }

    public void ApplyShock(float duration)
    {
        if (!isShocked)
        {
            originalPDEF = stats.physicalDEF;
            originalMDEF = stats.magicDEF;

            stats.physicalDEF *= 0.6f;
            stats.magicDEF *= 0.6f;
        }

        isShocked = true;
        shockTimer = duration;
    }
}