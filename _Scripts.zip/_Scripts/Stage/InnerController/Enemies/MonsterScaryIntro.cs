using UnityEngine;
using UnityEngine.AI;

public class MonsterScaryIntro : MonoBehaviour
{
    private static readonly int DoScaryHash = Animator.StringToHash("DoScary");

    private Animator anim;
    private NavMeshAgent agent;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        agent = GetComponent<NavMeshAgent>();
    }

    private void OnEnable()
    {
        // NavMesh ����
        if (agent != null)
        {
            agent.isStopped = true;
            agent.velocity = Vector3.zero;
        }

        // �ִϸ��̼� Ʈ����
        if (anim != null)
        {
            anim.ResetTrigger(DoScaryHash);
            anim.SetTrigger(DoScaryHash);
        }
    }
}