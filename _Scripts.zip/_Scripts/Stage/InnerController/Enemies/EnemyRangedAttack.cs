﻿using UnityEngine;
using System.Collections;
using UnityEngine.AI;

public class EnemyRangedAttack : MonoBehaviour
{
    private EnemyAI enemy;
    private Animator animator;
    private NavMeshAgent agent;

    [Header("Projectile Prefabs")]
    public GameObject slimeProjectilePrefab;
    public GameObject turtleShellProjectilePrefab;
    public GameObject cactusProjectilePrefab;
    public GameObject beholderProjectilePrefab;

    [Header("Fire Point")]
    public Transform firePoint;

    [Header("Cactus-Only")]
    public Transform[] cactusFirePoints;

    [Header("Beholder-Only")]
    public Transform[] beholderFirePoints;

    private void Awake()
    {
        enemy = GetComponent<EnemyAI>();
        animator = enemy.GetComponent<Animator>();
        agent = enemy.GetComponent<NavMeshAgent>();
    }

    // 🔥 EnemyAI에서 호출하는 단 하나의 진입점
    public void Fire()
    {
        if (enemy == null || enemy.player == null) return;
        if (!enemy.CanSeePlayer_Public()) return;

        // ✅ 발사 "직전 프레임" 플레이어 위치 스냅샷
        Vector3 targetPos = enemy.player.position;

        switch (enemy.monsterType)
        {
            case EnemyAI.MonsterType.Slime:
                FireSlime(targetPos);
                break;

            case EnemyAI.MonsterType.TurtleShell:
                FireTurtleShell(targetPos);
                break;

            case EnemyAI.MonsterType.Cactus:
                FireCactus(targetPos);
                break;

            case EnemyAI.MonsterType.Beholder:
                FireBeholder(targetPos);
                break;
        }
    }

    // ===============================
    // Slime (포물선 / 비유도)
    // ===============================
    private void FireSlime(Vector3 targetPos)
    {
        GameObject proj = Instantiate(
            slimeProjectilePrefab,
            firePoint.position,
            Quaternion.identity
        );

        SlimeProjectile slime =
            proj.GetComponent<SlimeProjectile>();

        slime.Launch(targetPos);
    }

    // ===============================
    // TurtleShell (부메랑)
    // ===============================
    private void FireTurtleShell(Vector3 targetPos)
    {
        GameObject proj = Instantiate(
            turtleShellProjectilePrefab,
            firePoint.position,
            Quaternion.identity
        );

        TurtleShellProjectile shell =
            proj.GetComponent<TurtleShellProjectile>();

        shell.owner = transform;

        // ⚠️ 거북이는 의도적으로 추적형이므로 Transform 유지
        shell.player = enemy.player;
    }

    // ===============================
    // Cactus (직선 / 비유도)
    // ===============================
    private void FireCactus(Vector3 targetPos)
    {
        int r = Random.Range(0, cactusFirePoints.Length);

        GameObject proj = Instantiate(
            cactusProjectilePrefab,
            cactusFirePoints[r].position,
            Quaternion.identity
        );

        proj.GetComponent<CactusSpikeProjectile>()
            .Launch(targetPos);
    }

    // ===============================
    // Beholder (직선 / 비유도 + 상태이상)
    // ===============================
    private void FireBeholder(Vector3 targetPos)
    {
        int r = Random.Range(0, beholderFirePoints.Length);

        GameObject proj = Instantiate(
            beholderProjectilePrefab,
            beholderFirePoints[r].position,
            Quaternion.identity
        );

        proj.GetComponent<BeholderEyeProjectile>()
            .Launch(targetPos);
    }
}