using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Collider))]
public class TurtleShellProjectile : MonoBehaviour
{
    public Transform owner;
    public Transform player;

    public float speed = 5f;
    public float returnDelay = 1.2f;
    public float lifeTime = 6f;

    public Vector3 fireTargetPos;
    private Vector3 moveDir;

    private bool returning = false;
    private bool hitPlayer = false;

    

    private void Start()
    {
        Destroy(gameObject, lifeTime);
        StartCoroutine(ReturnRoutine());
    }

    private void Update()
    {
        if (owner == null) return;

        if (!returning)
        {
            transform.position += moveDir * speed * Time.deltaTime;
        }
        else
        {
            transform.position = Vector3.MoveTowards(
                transform.position,
                owner.position,
                speed * Time.deltaTime
            );
        }

        transform.Rotate(Vector3.forward * 720f * Time.deltaTime);
    }

    public void Launch(Vector3 targetPos)
    {
        fireTargetPos = targetPos;
        moveDir = (fireTargetPos - transform.position).normalized;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (hitPlayer) return;

        if (other.CompareTag("Player"))
        {
            hitPlayer = true;
            AttachToPlayer(other);
        }
    }

    private void AttachToPlayer(Collider playerCol)
    {
        PlayerStatus playerStatus =
            playerCol.GetComponent<PlayerStatus>();

        if (playerStatus != null)
            playerStatus.TakeContactDamage(1f);

        PlayerTurtleShellDebuffController debuff =
            playerCol.GetComponent<PlayerTurtleShellDebuffController>();

        if (debuff != null)
            debuff.OnShellAttached();

        PlayerHitAttachHelper helper =
            playerCol.GetComponent<PlayerHitAttachHelper>();

        Vector3 hitPoint =
            playerCol.ClosestPoint(transform.position);

        Transform bone =
            helper != null ? helper.GetClosestBone(hitPoint) : playerCol.transform;

        transform.SetParent(bone);
        transform.position = hitPoint;
        transform.rotation =
            Quaternion.LookRotation(transform.position - owner.position);

        Destroy(gameObject, 3f);
    }

    private void OnDestroy()
    {
        if (transform.parent == null)
            return;

        PlayerTurtleShellDebuffController debuff =
            GetComponentInParent<PlayerTurtleShellDebuffController>();

        if (debuff != null)
            debuff.OnShellDetached();
    }


    private IEnumerator ReturnRoutine()
    {
        yield return new WaitForSeconds(returnDelay);
        returning = true;
    }
}