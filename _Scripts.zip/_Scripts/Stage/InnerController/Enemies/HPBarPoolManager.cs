﻿using System.Collections.Generic;
using UnityEngine;

public class HPBarPoolManager : MonoBehaviour
{
    public static HPBarPoolManager Instance;

    [SerializeField] HPBarUI prefab;
    [SerializeField] int poolSize = 120;

    List<HPBarUI> pool = new();
    Dictionary<EnemyAI, HPBarUI> active = new();

    private Camera cachedCamera;
    private Transform cachedCamTransform;

    void Awake()
    {
        Instance = this;

        for (int i = 0; i < poolSize; i++)
        {
            var bar = Instantiate(prefab, transform);
            bar.gameObject.SetActive(false);
            pool.Add(bar);
        }
    }

    public void SetWorldCamera(Camera cam)
    {
        cachedCamera = cam;
        cachedCamTransform = cam != null ? cam.transform : null;
    }

    public void Register(EnemyAI enemy, Transform anchor)
    {
        if (active.ContainsKey(enemy)) return;

        foreach (var bar in pool)
        {
            if (!bar.gameObject.activeSelf)
            {
                bar.Bind(anchor);
                bar.SetCamera(cachedCamera);
                active.Add(enemy, bar);
                return;
            }
        }
    }

    public void UpdateHP(EnemyAI enemy, float current, float max)
    {
        if (!active.TryGetValue(enemy, out var bar)) return;
        bar.SetHP(current / max);
        bar.Show(3f);   // 🔥 3초 표시
    }

    public void Unregister(EnemyAI enemy)
    {
        if (!active.TryGetValue(enemy, out var bar)) return;

        bar.Release();
        active.Remove(enemy);
    }
}