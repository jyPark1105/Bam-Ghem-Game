﻿using UnityEngine;
using UnityEngine.UI;

public class HPBarUI : MonoBehaviour
{
    public Image fill;

    public Transform target;
    public Vector3 offset;

    private RectTransform rect;

    private Camera cam;
    private Transform camTr;

    float current = 1f;
    float targetValue = 1f;

    float visibleTimer = 0f;   // 🔥 추가
    bool isVisible = false;    // 🔥 추가

    void Awake()
    {
        rect = GetComponent<RectTransform>();
        cam = Camera.main;
        gameObject.SetActive(false);  // 🔥 기본 비활성
    }

    public void SetCamera(Camera camera)
    {
        cam = camera;
        camTr = camera != null ? camera.transform : null;
    }

    public void Bind(Transform anchor)
    {
        target = anchor;
        targetValue = 1f;
        current = 1f;
        fill.fillAmount = 1f;
    }

    public void SetHP(float ratio)
    {
        targetValue = Mathf.Clamp01(ratio);
    }

    // 🔥 히트 시 호출
    public void Show(float duration)
    {
        visibleTimer = duration;
        if (!isVisible)
        {
            gameObject.SetActive(true);
            isVisible = true;
        }
    }

    public void Release()
    {
        gameObject.SetActive(false);
        target = null;
        isVisible = false;
    }

    void LateUpdate()
    {
        if (target == null || !isVisible || cam == null)
            return;

        visibleTimer -= Time.deltaTime;
        if (visibleTimer <= 0f)
        {
            gameObject.SetActive(false);
            isVisible = false;
            return;
        }

        Vector3 worldPos = target.position + offset;
        transform.position = worldPos;

        // 🔥 forward 대신 카메라 방향 정확히
        transform.rotation = Quaternion.LookRotation(transform.position - camTr.position);

        current = Mathf.Lerp(current, targetValue, Time.deltaTime * 10f);
        fill.fillAmount = current;
    }
}