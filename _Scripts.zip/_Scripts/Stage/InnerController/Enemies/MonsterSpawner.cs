﻿using UnityEngine;
using UnityEngine.AI;
using System.Collections;

public class MonsterSpawner : MonoBehaviour
{
    [Header("Spawn Points")]
    public Transform[] spawnPoints;

    [Header("Spawn Duration")]
    public float spawnDuration = 1800f; // 30min

    public float normalSpawnDuration = 1200f; // 20min

    // 3분 단위 7단계 (0,3,6,9,12,15,18)
    public float[] timeTierMultipliers = { 1.00f, 1.12f, 1.25f, 1.40f, 1.58f, 1.78f, 2.00f };

    private float elapsed; // 스폰 시작 후 경과시간

    private bool isSpawning = false;
    private int lastSpawnIndex = -1;

    private Coroutine spawnRoutine;

    //private void Start()
    //{
    //    StartSpawning();
    //}

    public void StartSpawning()
    {
        if (isSpawning) return;

        spawnRoutine = StartCoroutine(SpawnRoutine());
    }

    public void StopSpawning()
    {
        if (!isSpawning) return;

        if (spawnRoutine != null)
            StopCoroutine(spawnRoutine);

        isSpawning = false;
    }

    private IEnumerator SpawnRoutine()
    {
        isSpawning = true;
        elapsed = 0f;

        while (elapsed < normalSpawnDuration)
        {
            float delay = 5f;
            yield return new WaitForSeconds(delay);
            elapsed += delay;

            SpawnMonster(elapsed);
        }

        Debug.Log("[MonsterSpawner] Normal Spawn Ended");
    }

    private void SpawnMonster(float elapsedSec)
    {
        if (spawnPoints == null || spawnPoints.Length == 0) return;

        int spawnIndex = GetRandomSpawnIndex();
        lastSpawnIndex = spawnIndex;
        Transform sp = spawnPoints[spawnIndex];

        EnemyAI.MonsterType type;
        int r = Random.Range(0, 100);
        if (r < 40) type = EnemyAI.MonsterType.Slime;
        else if (r < 65) type = EnemyAI.MonsterType.TurtleShell;
        else if (r < 85) type = EnemyAI.MonsterType.Cactus;
        else type = EnemyAI.MonsterType.Beholder;

        // ✅ 시간 배율 계산
        float timeMult = GetTimeMultiplier(elapsedSec);

        // ✅ 풀에서 timeMult 포함해서 가져옴 (ResetAI 내부에서 스탯 완성됨)
        GameObject monster = MonsterPool.Instance.Get(type, timeMult);
        if (monster == null) return;

        if (!NavMesh.SamplePosition(sp.position, out var hit, 1.0f, NavMesh.AllAreas))
            return;

        monster.transform.position = hit.position;
        monster.transform.rotation = sp.rotation;

        StageManager.Instance.OnMonsterSpawned(type);
    }

    private float GetTimeMultiplier(float elapsedSec)
    {
        // 0~20분 범위로 클램프
        float t = Mathf.Clamp(elapsedSec, 0f, normalSpawnDuration);

        int tier = Mathf.FloorToInt(t / 180f); // 3분 단위
        tier = Mathf.Clamp(tier, 0, timeTierMultipliers.Length - 1);

        return timeTierMultipliers[tier];
    }

    private int GetRandomSpawnIndex()
    {
        // 스폰 포인트가 1개면 그대로 사용
        if (spawnPoints.Length <= 1)
            return 0;

        int index;

        do
        {
            index = Random.Range(0, spawnPoints.Length);
        }
        while (index == lastSpawnIndex);

        return index;
    }
}