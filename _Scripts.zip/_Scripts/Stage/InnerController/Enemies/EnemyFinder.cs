using System.Collections.Generic;
using UnityEngine;

public static class EnemyFinder
{
    public static List<EnemyAI> FindNearestEnemies(
        Vector3 center,
        int count,
        float radius
    )
    {
        Collider[] hits = Physics.OverlapSphere(
            center,
            radius,
            LayerMask.GetMask("Enemy")
        );

        List<EnemyAI> enemies = new();

        foreach (var hit in hits)
        {
            EnemyAI e = hit.GetComponent<EnemyAI>();
            if (e != null) enemies.Add(e);
        }

        enemies.Sort((a, b) =>
            Vector3.Distance(center, a.transform.position)
            .CompareTo(Vector3.Distance(center, b.transform.position))
        );

        return enemies.GetRange(0, Mathf.Min(count, enemies.Count));
    }
}
