﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(Collider))]
public class SlimeProjectile : MonoBehaviour
{
    [Header("Move")]
    public float arcHeight = 1.2f;
    public float lifeTime = 6f;

    private Rigidbody rb;
    private bool hit = false;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.useGravity = true;
        rb.isKinematic = false;

        Destroy(gameObject, lifeTime);
    }

    // ===============================
    // Launch (최신 위치 기준)
    // ===============================
    public void Launch(Vector3 targetPos)
    {
        rb.linearVelocity = CalculateParabolaVelocity(
            transform.position,
            targetPos,
            arcHeight
        );
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (hit) return;
        hit = true;

        if (collision.collider.CompareTag("Player"))
        {
            var paint =
                collision.collider.GetComponent<PlayerSlimePaintController>();

            if (paint != null)
                paint.ApplySlime();

            Destroy(gameObject);
            return;
        }

        rb.linearVelocity = Vector3.zero;
        rb.isKinematic = true;
        Destroy(gameObject, 1.5f);
    }

    private Vector3 CalculateParabolaVelocity(
        Vector3 start,
        Vector3 end,
        float height
    )
    {
        float gravity = Physics.gravity.y;

        Vector3 displacement = end - start;
        Vector3 displacementXZ =
            new Vector3(displacement.x, 0, displacement.z);

        float time =
            Mathf.Sqrt(-2 * height / gravity) +
            Mathf.Sqrt(2 * (displacement.y - height) / gravity);

        Vector3 velocityY =
            Vector3.up * Mathf.Sqrt(-2 * gravity * height);

        Vector3 velocityXZ =
            displacementXZ / time;

        return velocityXZ + velocityY;
    }
}