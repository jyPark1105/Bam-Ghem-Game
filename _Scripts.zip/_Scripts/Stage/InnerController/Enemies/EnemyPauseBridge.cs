﻿using UnityEngine;
using UnityEngine.AI;

public class EnemyPauseBridge : MonoBehaviour
{
    private EnemyAI enemy;
    private NavMeshAgent agent;
    private Animator animator;

    private void Awake()
    {
        enemy = GetComponent<EnemyAI>();
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
    }

    private void OnEnable()
    {
        PauseManager.RegisterEnemy(this);
    }

    private void OnDisable()
    {
        PauseManager.UnregisterEnemy(this);
    }

    public void SetPaused(bool paused)
    {
        if (enemy != null && enemy.IsDead())
            return;

        if (agent != null && agent.enabled)
            agent.isStopped = paused;

        if (animator != null)
            animator.speed = paused ? 0f : 1f;
    }
}