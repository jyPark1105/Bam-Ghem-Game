﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Collider))]
public class BeholderEyeProjectile : MonoBehaviour
{
    [Header("Move")]
    public float speed = 4f;
    public float lifeTime = 6f;

    [Header("Direct Damage")]
    public float hitMagicDamage = 2f;

    [Header("Poison (DoT)")]
    public float poisonDuration = 3f;
    public float poisonTickInterval = 1f;
    public float poisonDamagePerTick = 1f;

    private Vector3 direction;
    private bool hasHit = false;

    private void Start()
    {
        Destroy(gameObject, lifeTime);
    }

    // ===============================
    // Launch (스냅샷)
    // ===============================
    public void Launch(Vector3 targetPos)
    {
        direction = (targetPos - transform.position).normalized;
        transform.rotation = Quaternion.LookRotation(direction);
    }

    private void Update()
    {
        transform.position += direction * speed * Time.deltaTime;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (hasHit) return;
        if (!other.CompareTag("Player")) return;

        hasHit = true;

        PlayerStatus player = other.GetComponent<PlayerStatus>();
        if (player != null)
        {
            player.TakeDamage(0f, hitMagicDamage, false);
            StartCoroutine(PoisonRoutine(player));
        }

        Destroy(gameObject);
    }

    private IEnumerator PoisonRoutine(PlayerStatus player)
    {
        float elapsed = 0f;

        while (elapsed < poisonDuration)
        {
            if (player == null || player.isDead)
                yield break;

            player.TakeDamage(0f, poisonDamagePerTick, false);

            yield return new WaitForSeconds(poisonTickInterval);
            elapsed += poisonTickInterval;
        }
    }
}