﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.AI;

public class MonsterPool : MonoBehaviour
{
    public static MonsterPool Instance;

    [Header("Prefabs")]
    public GameObject slimePrefab;
    public GameObject turtlePrefab;
    public GameObject cactusPrefab;
    public GameObject beholderPrefab;

    [Header("Pool Sizes")]
    public int slimePoolSize = 20;
    public int turtlePoolSize = 20;
    public int cactusPoolSize = 20;
    public int beholderPoolSize = 20;

    [Header("Root Parent")]
    public Transform monstersRoot;

    private Queue<GameObject> slimePool = new Queue<GameObject>();
    private Queue<GameObject> turtlePool = new Queue<GameObject>();
    private Queue<GameObject> cactusPool = new Queue<GameObject>();
    private Queue<GameObject> beholderPool = new Queue<GameObject>();

    private void Awake()
    {
        Instance = this;

        InitPool(slimePool, slimePrefab, slimePoolSize);
        InitPool(turtlePool, turtlePrefab, turtlePoolSize);
        InitPool(cactusPool, cactusPrefab, cactusPoolSize);
        InitPool(beholderPool, beholderPrefab, beholderPoolSize);
    }

    private void InitPool(Queue<GameObject> pool, GameObject prefab, int size)
    {
        if (prefab == null)
        {
            Debug.LogError($"[MonsterPool] Prefab is NULL → pool init skipped");
            return;
        }

        for (int i = 0; i < size; i++)
        {
            GameObject obj = Instantiate(prefab, monstersRoot);
            obj.SetActive(false);
            pool.Enqueue(obj);
        }
    }

    public GameObject Get(EnemyAI.MonsterType type, float timeMult)
    {
        Queue<GameObject> pool = type switch
        {
            EnemyAI.MonsterType.Slime => slimePool,
            EnemyAI.MonsterType.TurtleShell => turtlePool,
            EnemyAI.MonsterType.Cactus => cactusPool,
            EnemyAI.MonsterType.Beholder => beholderPool,
            _ => null
        };

        if (pool == null || pool.Count == 0) return null;

        GameObject obj = pool.Dequeue();
        obj.SetActive(true);

        EnemyAI enemy = obj.GetComponent<EnemyAI>();

        if (PlayerStatus.Instance == null)
        {
            Debug.LogError("[MonsterPool] PlayerStatus.Instance is NULL");
        }
        else
        {
            enemy.BindPlayer(PlayerStatus.Instance);
        }

        enemy.SetTimeMultiplier(timeMult);
        enemy.ResetAI();

        return obj;
    }

    public void Return(GameObject obj, EnemyAI.MonsterType type)
    {
        obj.SetActive(false);
        obj.transform.SetParent(monstersRoot);

        switch (type)
        {
            case EnemyAI.MonsterType.Slime:
                slimePool.Enqueue(obj);
                break;

            case EnemyAI.MonsterType.TurtleShell:
                turtlePool.Enqueue(obj);
                break;

            case EnemyAI.MonsterType.Cactus:
                cactusPool.Enqueue(obj);
                break;

            case EnemyAI.MonsterType.Beholder:
                beholderPool.Enqueue(obj);
                break;
        }
    }
}
