using UnityEngine;

public class EnemySkillHitbox : MonoBehaviour
{
    private EnemyAI enemy;

    private void Awake()
    {
        enemy = GetComponentInParent<EnemyAI>();
    }

    private void OnTriggerEnter(Collider other)
    {
        SkillA_Controller_Base skill =
            other.GetComponentInParent<SkillA_Controller_Base>();

        if (skill != null)
        {
            skill.OnEnemyEnter(enemy);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        SkillA_Controller_Base skill =
            other.GetComponentInParent<SkillA_Controller_Base>();

        if (skill != null)
        {
            skill.OnEnemyExit(enemy);
        }
    }
}