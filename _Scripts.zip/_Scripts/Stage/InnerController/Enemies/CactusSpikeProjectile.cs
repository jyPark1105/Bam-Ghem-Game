﻿using UnityEngine;

[RequireComponent(typeof(Collider))]
public class CactusSpikeProjectile : MonoBehaviour
{
    public float speed = 10f;
    public float lifeTime = 4f;

    private Vector3 direction;

    private void Start()
    {
        Destroy(gameObject, lifeTime);
    }

    // ===============================
    // Launch (스냅샷 조준)
    // ===============================
    public void Launch(Vector3 targetPos)
    {
        direction = (targetPos - transform.position).normalized;
        transform.rotation = Quaternion.LookRotation(direction);
    }

    private void Update()
    {
        transform.position += direction * speed * Time.deltaTime;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        PlayerStatus player =
            other.GetComponent<PlayerStatus>();

        if (player != null)
            player.TakeContactDamage(1f);

        Destroy(gameObject);
    }
}