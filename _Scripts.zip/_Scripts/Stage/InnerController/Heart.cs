﻿using UnityEngine;

public class Heart : MonoBehaviour
{
    public float rotateDuration = 3f;   // 3초에 1바퀴
    public float floatAmplitude = 0.1f; // 위아래 이동 폭
    public float floatSpeed = 2f;       // 뜨는 속도
    public int healAmount = 20;

    private Vector3 startPos;

    private void Start()
    {
        startPos = transform.position;
    }

    void Update()
    {
        // ✔ 회전
        float rotationPerSecond = 360f / rotateDuration;
        transform.Rotate(Vector3.up * rotationPerSecond * Time.deltaTime);

        // ✔ 둥둥 떠다니기
        float newY = startPos.y + Mathf.Sin(Time.time * floatSpeed) * floatAmplitude;
        transform.position = new Vector3(startPos.x, newY, startPos.z);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            /*PlayerHealth hp = other.GetComponent<PlayerHealth>();
            if (hp != null) hp.Heal(healAmount);

            ParticleController.Instance?.PlayFX("LevelUpFX", transform.position);
            Destroy(gameObject);*/
        }
    }
}
