﻿using UnityEngine;
using System.Collections;
using UnityEngine.VFX;
using Cinemachine;

public class DissolvingController : MonoBehaviour
{
    [Header("References")]
    public Animator animator;

    [Header("Mesh")]
    public SkinnedMeshRenderer surface;
    public SkinnedMeshRenderer joints;

    [Header("VFX")]
    public VisualEffect dissolveVFX;

    [Header("Dissolve Settings")]
    public float dieDelay = 0.2f;
    public float dissolveRate = 0.0125f;
    public float refreshRate = 0.025f;

    private Material surfaceMat;
    private Material jointsMat;

    private bool isRunning = false;

    private void Awake()
    {
        surfaceMat = surface.material;
        jointsMat = joints.material;

        surfaceMat.SetFloat("_DissolveAmount", 0f);
        jointsMat.SetFloat("_DissolveAmount", 0f);
    }

    // =====================================================
    // 외부 호출 (PlayerStatus.Die에서 호출)
    // =====================================================
    public void BeginDie()
    {
        if (isRunning) return;
        StartCoroutine(DieSequence());
    }

    // =====================================================
    // Die Main Sequence
    // =====================================================
    private IEnumerator DieSequence()
    {
        isRunning = true;

        // ③ Die 애니메이션
        PlayRandomDieAnimation();

        // ④ 애니메이션 약간 대기
        yield return new WaitForSeconds(dieDelay);

        // ⑤ VFX 시작
        if (dissolveVFX != null)
            dissolveVFX.Play();

        // ⑥ Dissolve
        yield return StartCoroutine(DissolveMesh());
    }

    // =====================================================
    // Animation
    // =====================================================
    private void PlayRandomDieAnimation()
    {
        if (animator == null) return;

        int r = Random.Range(0, 2);
        if (r == 0)
            animator.SetTrigger("DieWithDissolvingA");
        else
            animator.SetTrigger("DieWithDissolvingB");
    }

    // =====================================================
    // Dissolve
    // =====================================================
    private IEnumerator DissolveMesh()
    {
        float amount = 0f;

        while (amount < 1f)
        {
            amount += dissolveRate;

            surfaceMat.SetFloat("_DissolveAmount", amount);
            jointsMat.SetFloat("_DissolveAmount", amount);

            yield return new WaitForSeconds(refreshRate);
        }

        surfaceMat.SetFloat("_DissolveAmount", 1f);
        jointsMat.SetFloat("_DissolveAmount", 1f);
    }
}