﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UI_BgmPlayer : MonoBehaviour
{
    public static UI_BgmPlayer Instance;

    [Header("UI Components")]
    public TMP_Text moodText;
    public Slider progressSlider;
    public Button playPauseButton;
    public Button nextButton;
    public Button prevButton;
    public Button loopButton;

    [Header("Play/Pause Icons")]
    public Sprite playIcon;
    public Sprite pauseIcon;
    public Image playPauseImage;

    [Header("Loop Icons")]
    public Sprite loopOffIcon;   // 순차재생
    public Sprite loopAllIcon;   // 전체 반복
    public Sprite loopSelfIcon;  // 1곡 반복
    public Image loopImage;

    [Header("Volume")]
    public Slider volumeSlider;

    private bool isDragging = false;

    private BackgroundMusicManager bgm => BackgroundMusicManager.Instance;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        // 슬라이더 이벤트 바인딩
        progressSlider.onValueChanged.AddListener(OnSliderValueChanged);
        volumeSlider.onValueChanged.AddListener(OnVolumeChanged);

        // 초기 볼륨 UI 동기화
        volumeSlider.value = bgm.bgmVolume;

        UpdateUI();
    }

    void Update()
    {
        if (bgm == null || bgm.bgmSource.clip == null) return;

        // 드래그 중이면 자동 UI Sync 금지
        if (!isDragging)
        {
            progressSlider.maxValue = bgm.GetCurrentLength();
            progressSlider.value = bgm.GetCurrentTime();
        }
    }

    // =======================
    //  🔥 전체 UI 업데이트
    // =======================
    public void UpdateUI()
    {
        if (bgm == null) return;

        moodText.text = bgm.GetCurrentTag();

        // Play / Pause
        playPauseImage.sprite = bgm.isPaused ? playIcon : pauseIcon;

        // Loop Mode
        UpdateLoopIcon();

        // Slider
        if (bgm.bgmSource.clip != null)
        {
            progressSlider.maxValue = bgm.GetCurrentLength();
            progressSlider.value = bgm.GetCurrentTime();
        }
    }

    // =======================
    //  🔥 LoopMode에 따른 아이콘 변경
    // =======================
    public void UpdateLoopIcon()
    {
        switch (bgm.loopMode)
        {
            case LoopMode.Off:
                loopImage.sprite = loopOffIcon;
                break;

            case LoopMode.All:
                loopImage.sprite = loopAllIcon;
                break;

            case LoopMode.Self:
                loopImage.sprite = loopSelfIcon;
                break;
        }
    }

    // =======================
    // 🔥 슬라이더 드래그
    // =======================
    public void OnSliderPointerDown()
    {
        isDragging = true;
    }

    public void OnSliderPointerUp()
    {
        isDragging = false;
        bgm.Seek(progressSlider.value);
    }

    private void OnSliderValueChanged(float value)
    {
        // 드래그 중일 때만 Seek
        if (isDragging)
            bgm.Seek(value);
    }
        
    // =======================
    // UI Buttons
    // =======================
    public void OnClickPlayPause() => bgm.TogglePause();
    public void OnClickNext() => bgm.PlayNext();
    public void OnClickPrev() => bgm.PlayPrev();
    public void OnClickLoop()
    {
        bgm.ToggleLoop();
        UpdateLoopIcon();
    }

    // =======================
    // Volume
    // =======================
    private void OnVolumeChanged(float value)
    {
        bgm.SetVolume(value);
    }
}