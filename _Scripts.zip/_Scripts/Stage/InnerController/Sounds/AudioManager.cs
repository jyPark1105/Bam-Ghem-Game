﻿using UnityEngine;
using System.Collections;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance;

    [Header("Audio Sources")]
    public AudioSource sfxSource;        // 일반 효과음
    public AudioSource voiceSource;      // 캐릭터 보이스
    public AudioSource loopSource;       // 🔥 루프 전용 (ChatTyping, AttributeChange)

    [Header("UI Chat Clip")]
    public AudioClip chatTypingClip;

    [Header("UI Clips")]
    public AudioClip skillUnavailableClip;
    public AudioClip[] uiClickClips;
    public AudioClip uiMenuSelectClip;

    [Header("Clips")]
    public AudioClip[] climbClips;
    public AudioClip[] jumpClips;
    public AudioClip[] landClips;
    public AudioClip[] grassClips;
    public AudioClip[] getItemClips;
    public AudioClip[] getItemEffectClips;

    [Header("Attribute Change")]
    public AudioClip attributeChangeClip;

    [Header("Weapon Change Clips")]
    public AudioClip[] weaponChangeClips; // [Blue, Red, Green, Purple]

    [Header("Player Skill A Clips")]
    public AudioClip[] skillA_BlueClips;
    public AudioClip[] skillA_PurpleClips;
    public AudioClip[] skillA_GreenClips;   // 2개 랜덤
    public AudioClip[] skillA_RedClips;     // [0] Start, [1] End

    [Header("Player Skill B Clips")]
    public AudioClip[] skillB_BlueClips;    // 🔵 반드시 3개
    public AudioClip[] skillB_RedClips;
    public AudioClip[] skillB_GreenClips;
    public AudioClip[] skillB_PurpleClips;

    // 얘네 할당하고 초기화하는 함수도 생성할 것
    [Header("Player Skill R Clips")]
    public AudioClip[] skillR_BlueClips;
    public AudioClip[] skillR_RedClips;
    public AudioClip[] skillR_GreenClips;
    public AudioClip[] skillR_PurpleClips;

    [Header("Player Attack Clips")]
    public AudioClip[] attackClips;         // 플레이어 타격음
    public AudioClip attackJumpClip;        // 공격 & 점프 타격음

    [Header("Enemy Clips")]
    public AudioClip[] enemyAttackClips;    // 적 공격음
    public AudioClip[] enemyHitClips;       // 적 피격음
    public AudioClip enemyDieClip;          // 적 소멸음    

    // SkillB_Blue는 총 3번 재생
    private int skillBBlueIndex = 0;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    private AudioClip GetRandom(AudioClip[] arr)
    {
        if (arr == null || arr.Length == 0) return null;
        return arr[Random.Range(0, arr.Length)];
    }

    // ======================
    //      PUBLIC API
    // ======================
    public void PlayChatTyping()
    {
        if (chatTypingClip == null) return;

        if (loopSource.isPlaying) return;

        loopSource.clip = chatTypingClip;
        loopSource.loop = true;
        loopSource.volume = 0.4f;
        loopSource.Play();
    }

    public void StopChatTyping()
    {
        if (!loopSource.isPlaying) return;

        if (loopSource.clip == chatTypingClip)
        {
            loopSource.Stop();
            loopSource.clip = null;
            loopSource.loop = false;
        }
    }

    public void PlayJump()
    {
        AudioClip clip = GetRandom(jumpClips);
        if (clip != null) voiceSource.PlayOneShot(clip, 0.6f);
    }

    public void PlayClimb()
    {
        AudioClip clip = climbClips[0];
        if (clip != null) voiceSource.PlayOneShot(clip, 0.7f);
    }

    public void PlayLand()
    {
        AudioClip clip = GetRandom(landClips);
        if (clip != null) sfxSource.PlayOneShot(clip, 0.7f);
    }

    public void PlayGrass(float volume = 0.65f)
    {
        AudioClip clip = GetRandom(grassClips);
        if (clip != null) sfxSource.PlayOneShot(clip, volume);
    }

    public void PlayItemScan()
    {
        if (getItemClips == null || getItemClips.Length == 0) return;
        sfxSource.PlayOneShot(getItemClips[0], 0.6f);
    }

    public void PlayGetItem()
    {
        AudioClip clip = GetRandom(getItemEffectClips);
        if (clip != null) sfxSource.PlayOneShot(clip, 0.7f);
    }

    // 🔥 신규 함수: 플레이어 공격음
    public void PlayAttack()
    {
        AudioClip clip = GetRandom(attackClips);
        if (clip != null) sfxSource.PlayOneShot(clip, 0.6f);
    }

    // 공격 & 점프 동시에
    public void PlayAttackJump()
    {
        if (attackJumpClip != null)
            sfxSource.PlayOneShot(attackJumpClip, 0.6f);
    }

    // Enemy 피격음
    public void PlayEnemyHit()
    {
        AudioClip clip = GetRandom(enemyHitClips);
        if (clip != null) sfxSource.PlayOneShot(clip, 0.2f);
    }

    // Enemy 공격음(몬스터 多 → 소리 작게)
    public void PlayEnemyAttack()
    {
        AudioClip clip = GetRandom(enemyAttackClips);
        if (clip != null) sfxSource.PlayOneShot(clip, 0.2f);
    }

    // Enemy 소멸음
    public void PlayEnemyDie()
    {
        if (enemyDieClip != null)
            sfxSource.PlayOneShot(enemyDieClip, 0.3f);
    }

    // ======================
    // SkillR Sound Length API
    // ======================
    public float GetEnemyHitLength()
    {
        if (enemyHitClips == null || enemyHitClips.Length == 0)
            return 0.3f; // fallback

        // 랜덤 재생이라 평균 대신 첫 번째 기준
        return enemyHitClips[0].length;
    }

    public float GetEnemyDieLength()
    {
        if (enemyDieClip == null)
            return 0.5f; // fallback

        return enemyDieClip.length;
    }



    // ===============================
    // Skill A 사운드 재생(Volume: 0.25f)
    // ===============================
    public void PlaySkillA_Blue()
    {
        if (skillA_BlueClips.Length > 0)
            sfxSource.PlayOneShot(skillA_BlueClips[0], 0.25f);
    }

    public void PlaySkillA_Purple()
    {
        if (skillA_PurpleClips.Length > 0)
            sfxSource.PlayOneShot(skillA_PurpleClips[0], 0.25f);
    }

    public void PlaySkillA_Green()
    {
        AudioClip clip = GetRandom(skillA_GreenClips);
        if (clip != null) sfxSource.PlayOneShot(clip, 0.25f);
    }

    public void PlaySkillA_Red()
    {
        StartCoroutine(PlayRedRoutine());
    }

    private IEnumerator PlayRedRoutine()
    {
        AudioClip start = skillA_RedClips.Length > 0 ? skillA_RedClips[0] : null;
        AudioClip end = skillA_RedClips.Length > 1 ? skillA_RedClips[1] : null;

        if (start != null)
        {
            voiceSource.PlayOneShot(start, 0.25f);
            yield return new WaitForSeconds(start.length);
        }

        if (end != null)
            voiceSource.PlayOneShot(end, 0.25f);
    }


    // ===============================
    // Skill B 사운드 재생(Volume: 0.25f)
    // ===============================
    public void PlaySkillB_Blue()
    {
        if (skillB_BlueClips == null || skillB_BlueClips.Length == 0)
            return;

        int idx = Mathf.Clamp(skillBBlueIndex, 0, skillB_BlueClips.Length - 1);
        AudioClip clip = skillB_BlueClips[idx];

        if (clip != null)
            sfxSource.PlayOneShot(clip, 0.25f);

        skillBBlueIndex++;

        // 3회 끝나면 리셋
        if (skillBBlueIndex >= skillB_BlueClips.Length)
            skillBBlueIndex = 0;
    }

    public void PlaySkillB_Red()
    {
        if (skillB_RedClips != null && skillB_RedClips.Length > 0)
            sfxSource.PlayOneShot(skillB_RedClips[0], 0.25f);
    }

    public void PlaySkillB_Green()
    {
        if (skillB_GreenClips != null && skillB_GreenClips.Length > 0)
            sfxSource.PlayOneShot(skillB_GreenClips[0], 0.25f);
    }

    public void PlaySkillB_Purple()
    {
        if (skillB_PurpleClips != null && skillB_PurpleClips.Length > 0)
            sfxSource.PlayOneShot(skillB_PurpleClips[0], 0.25f);
    }

    // ===============================
    // Skill R 사운드 재생(Volume: 0.25f)
    // ===============================
    public void PlaySkillR_Red()
    {
        if (skillR_RedClips.Length > 0)
            sfxSource.PlayOneShot(skillR_RedClips[0], 0.25f);
    }

    public void PlaySkillR_Green()
    {
        if (skillR_GreenClips.Length > 0)
            sfxSource.PlayOneShot(skillR_GreenClips[0], 0.25f);
    }
    public void PlaySkillR_Blue()
    {
        if (skillR_BlueClips.Length > 0)
            sfxSource.PlayOneShot(skillR_BlueClips[0], 0.25f);
    }

    public void PlaySkillR_Purple()
    {
        if (skillR_PurpleClips.Length > 0)
            sfxSource.PlayOneShot(skillR_PurpleClips[0], 0.25f);
    }


    // 마나 없어서 스킬 못 씀
    public void PlaySkillUnavailable()
    {
        if (skillUnavailableClip != null)
            sfxSource.PlayOneShot(skillUnavailableClip, 0.5f);
    }

    // ======================
    // UI 클릭 사운드
    // ======================
    public void OnPlayUISelect()
    {
        AudioClip clip = GetRandom(uiClickClips);
        if (clip != null)
            sfxSource.PlayOneShot(clip, 1f);
    }
    
    // UI Menu 변경 사운드
    public void OnPlayUIMenuSelect()
    {
        if (uiMenuSelectClip != null)
            sfxSource.PlayOneShot(uiMenuSelectClip, 0.9f);
    }

    public void PlayWeaponChange(PlayerAbsorbEffect.ColorType type)
    {
        int idx = (int)type;

        if (weaponChangeClips == null) return;
        if (idx < 0 || idx >= weaponChangeClips.Length) return;

        var clip = weaponChangeClips[idx];
        if (clip != null)
            sfxSource.PlayOneShot(clip, 0.7f);
    }

    public void PlayAttributeChange()
    {
        if (attributeChangeClip == null) return;

        sfxSource.clip = attributeChangeClip;
        sfxSource.loop = true;
        sfxSource.volume = 0.7f;
        sfxSource.Play();
    }

    // 재생 / 정지 함수 추가
    public void StopAttributeChange()
    {
        if (sfxSource.clip == attributeChangeClip)
        {
            sfxSource.Stop();
            sfxSource.loop = false;
            sfxSource.clip = null;
        }
    }
}