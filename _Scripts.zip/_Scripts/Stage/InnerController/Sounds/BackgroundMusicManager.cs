﻿using UnityEngine;
using System.Collections;

public enum LoopMode
{
    Off,        // 순차 재생
    All,        // 전체 반복
    Self        // 현재 곡 반복
}


[System.Serializable]
public class BgmData
{
    public string tag;
    public string resourcePath; // Resources/BGM/xxx
}

/// <summary>
/// 배경음이 지금처럼 여러 개인 경우, 재생되지 않는 곡이어도 메모리에 load 된 상태 -> 이는 불필요한 메모리 용량을 차지함
/// 1. 메모리 상주 => 1곡
/// 2. Garbage Collector 안정
/// </summary>
public class BackgroundMusicManager : MonoBehaviour
{
    public static BackgroundMusicManager Instance;

    public AudioSource bgmSource;

    [Header("Chat BGM")]
    public string chatBgmPath; // Resources/BGM/ChatMusic
    private AudioClip chatBgmClip;
    private bool isChatBgmPlaying = false;

    [Header("BGM List")]
    public BgmData[] bgmList;
    public int currentIndex = 0;

    [Range(0f, 1f)]
    public float bgmVolume = 0.3f;

    public bool isPaused = false;
    public LoopMode loopMode = LoopMode.Off;

    private AudioClip currentClip;
    private Coroutine loadRoutine;

    private bool isLoading = false;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        bgmSource.loop = false;
        bgmSource.volume = bgmVolume;
    }

    void Update()
    {
        if (isLoading || bgmSource.clip == null) return;

        // ChatBGM 전용 루프
        if (isChatBgmPlaying)
        {
            if (!bgmSource.isPlaying)
                bgmSource.Play();

            return;
        }

        // ===== 기존 BGM 로직 =====
        if (!bgmSource.isPlaying && !isPaused)
        {
            switch (loopMode)
            {
                case LoopMode.Self:
                    bgmSource.Play();
                    break;

                case LoopMode.All:
                    PlayNext();
                    break;

                case LoopMode.Off:
                    if (currentIndex < bgmList.Length - 1)
                        PlayNext();
                    break;
            }
        }
    }

    public void PlayChatBgm()
    {
        if (isLoading) return;

        // 이미 로드돼 있으면 재생만
        if (chatBgmClip != null)
        {
            bgmSource.clip = chatBgmClip;
            bgmSource.loop = true;
            bgmSource.Play();
            isChatBgmPlaying = true;
            return;
        }

        StartCoroutine(LoadChatBgmCoroutine());
    }

    IEnumerator LoadChatBgmCoroutine()
    {
        isLoading = true;

        var request = Resources.LoadAsync<AudioClip>(chatBgmPath);
        yield return request;

        chatBgmClip = request.asset as AudioClip;

        if (chatBgmClip == null)
        {
            Debug.LogError($"[ChatBGM] Failed to load: {chatBgmPath}");
            isLoading = false;
            yield break;
        }

        bgmSource.clip = chatBgmClip;
        bgmSource.loop = true;
        bgmSource.Play();

        isChatBgmPlaying = true;
        isLoading = false;
    }

    void LoadAndPlayCurrent()
    {
        if (isLoading) return;

        if (loadRoutine != null)
            StopCoroutine(loadRoutine);

        loadRoutine = StartCoroutine(LoadBgmCoroutine());
    }


    IEnumerator LoadBgmCoroutine()
    {
        isLoading = true;

        // 1️⃣ 이전 BGM 정리
        if (currentClip != null)
        {
            bgmSource.Stop();
            bgmSource.clip = null;

            currentClip.UnloadAudioData();
            currentClip = null;

            // 매 전환마다 UnloadUnusedAssets()는 살짝 과함
            // yield return Resources.UnloadUnusedAssets();
        }

        isPaused = false;

        // 2️⃣ 새 BGM 로드
        var path = bgmList[currentIndex].resourcePath;
        var request = Resources.LoadAsync<AudioClip>(path);

        yield return request;

        currentClip = request.asset as AudioClip;

        if (currentClip == null)
        {
            Debug.LogError($"[BGM] Failed to load: {path}");
            isLoading = false;
            yield break;
        }

        // 3️⃣ 재생
        bgmSource.clip = currentClip;
        bgmSource.Play();

        UI_BgmPlayer.Instance?.UpdateUI();

        isLoading = false;
    }

    public void EndChatBgmAndPlayNormalBgm(int index = 0)
    {
        isChatBgmPlaying = false;

        bgmSource.Stop();
        bgmSource.clip = null;

        // 🔥 ChatMusic 메모리 해제
        if (chatBgmClip != null)
        {
            chatBgmClip.UnloadAudioData();
            chatBgmClip = null;
        }

        currentIndex = index;
        LoadAndPlayCurrent();
    }

    public void PlayNext()
    {
        if (isLoading) return;

        currentIndex = (currentIndex + 1) % bgmList.Length;
        LoadAndPlayCurrent();
    }

    public void PlayPrev()
    {
        if (isLoading) return;

        currentIndex--;
        if (currentIndex < 0)
            currentIndex = bgmList.Length - 1;

        LoadAndPlayCurrent();
    }

    public void StopBgm()
    {
        if (bgmSource != null)
            bgmSource.Stop();

        isPaused = true;
    }

    public void TogglePause()
    {
        if (isPaused) bgmSource.Play();
        else bgmSource.Pause();

        isPaused = !isPaused;

        UI_BgmPlayer.Instance.UpdateUI();
    }

    // 🔥 3단계 루프 모드 (Off → All → Self → Off)
    public void ToggleLoop()
    {
        if (loopMode == LoopMode.Off)
            loopMode = LoopMode.All;
        else if (loopMode == LoopMode.All)
            loopMode = LoopMode.Self;
        else
            loopMode = LoopMode.Off;

        UI_BgmPlayer.Instance.UpdateLoopIcon();
    }

    // =======================
    // 🔥 Seek (재생 위치 변경)
    // =======================
    public void Seek(float time)
    {
        if (bgmSource.clip == null) return;
        bgmSource.time = Mathf.Clamp(time, 0, bgmSource.clip.length);
    }

    // =======================
    // 🔥 Loop 처리
    // =======================
    public void SetVolume(float value)
    {
        bgmVolume = value;
        bgmSource.volume = value;
    }

    public float GetCurrentTime() => bgmSource.time;
    public float GetCurrentLength() => bgmSource.clip.length;

    // =======================
    // 🔥 UI용 현재 BGM 태그 반환
    // =======================
    public string GetCurrentTag()
    {
        if (bgmList == null || bgmList.Length == 0)
            return "None";

        if (currentIndex < 0 || currentIndex >= bgmList.Length)
            return "Unknown";

        return bgmList[currentIndex].tag;
    }

}