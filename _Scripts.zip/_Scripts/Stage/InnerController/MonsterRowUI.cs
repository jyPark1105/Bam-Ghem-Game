using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MonsterRowUI : MonoBehaviour
{
    public Image monsterImage;
    public TMP_Text totalText;
    public TMP_Text killedText;
    public TMP_Text attackCountText;
    public TMP_Text extinctionText;

    public void Setup(
        Sprite icon, 
        int total, 
        int killed, 
        int criticalKilled,
        int attackCount, 
        int extinction
        )
    {
        monsterImage.sprite = icon;
        totalText.text = total.ToString();
        killedText.text = $"{killed} ({criticalKilled})";
        attackCountText.text = attackCount.ToString();
        extinctionText.text = extinction.ToString();
    }
}
