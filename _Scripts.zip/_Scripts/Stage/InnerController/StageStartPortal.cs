﻿using UnityEngine;
using System.Collections;
using TMPro;

public class StageStartPortal : MonoBehaviour
{
    [Header("Stage Controller")]
    [SerializeField] private StageSceneController stageController;

    [Header("Countdown UI")]
    [SerializeField] private TMP_Text countdownText;
    [SerializeField] private CanvasGroup canvasGroup;

    private bool triggered = false;
    private Vector3 baseScale;

    private void Awake()
    {
        if (countdownText != null)
        {
            baseScale = countdownText.rectTransform.localScale;
        }

        if (canvasGroup != null)
        {
            canvasGroup.alpha = 0f;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (triggered) return;

        if (!other.CompareTag("Player"))
            return;

        if (stageController == null)
        {
            Debug.LogError("[StageStartPortal] StageSceneController not assigned!");
            return;
        }

        triggered = true;

        StartCoroutine(StartStageRoutine(other.gameObject));
    }

    private IEnumerator StartStageRoutine(GameObject player)
    {
        Debug.Log("Portal Triggered");

        yield return StartCoroutine(CountdownRoutine());

        stageController.TeleportPlayerToBattle(player);
    }

    private IEnumerator CountdownRoutine()
    {
        if (countdownText == null || canvasGroup == null)
            yield break;

        canvasGroup.alpha = 1f;

        yield return StartCoroutine(ShowNumber("3"));
        yield return StartCoroutine(ShowNumber("2"));
        yield return StartCoroutine(ShowNumber("1"));
        yield return StartCoroutine(ShowNumber("0"));

        // 마지막 메시지
        yield return StartCoroutine(ShowFinalMessage());

        // 🔥 GO 사운드
        AudioManager.Instance.PlayClimb();

        // 서서히 사라짐
        yield return StartCoroutine(FadeOut());
    }

    private IEnumerator ShowNumber(string text)
    {
        countdownText.text = text;

        RectTransform rt = countdownText.rectTransform;

        float upTime = 0.2f;
        float downTime = 0.2f;

        Vector3 start = baseScale * 0.6f;
        Vector3 peak = baseScale * 1.5f;

        float t = 0f;

        // Scale Up
        while (t < upTime)
        {
            t += Time.deltaTime;
            float n = t / upTime;

            rt.localScale = Vector3.Lerp(start, peak, n);
            yield return null;
        }

        t = 0f;

        // Scale Down
        while (t < downTime)
        {
            t += Time.deltaTime;
            float n = t / downTime;

            rt.localScale = Vector3.Lerp(peak, baseScale, n);
            yield return null;
        }

        rt.localScale = baseScale;

        yield return new WaitForSeconds(0.6f);
    }

    private IEnumerator ShowFinalMessage()
    {
        countdownText.color = new Color32(255, 220, 90, 255);
        countdownText.text = "행운을 빕니다!";

        // 🔥 크기 조정
        RectTransform rect = countdownText.rectTransform;
        rect.sizeDelta = new Vector2(700f, rect.sizeDelta.y);
        countdownText.fontSize = 80;

        float upTime = 0.25f;
        float downTime = 0.25f;

        Vector3 start = baseScale * 0.7f;
        Vector3 peak = baseScale * 1.3f;

        float t = 0f;

        // Scale Up
        while (t < upTime)
        {
            t += Time.deltaTime;
            float n = t / upTime;
            rect.localScale = Vector3.Lerp(start, peak, n);
            yield return null;
        }

        t = 0f;

        // Scale Down
        while (t < downTime)
        {
            t += Time.deltaTime;
            float n = t / downTime;
            rect.localScale = Vector3.Lerp(peak, baseScale, n);
            yield return null;
        }

        rect.localScale = baseScale;

        // 2초 유지
        yield return new WaitForSeconds(2f);
    }

    private IEnumerator FadeOut()
    {
        float duration = 0.6f;
        float t = 0f;

        float start = canvasGroup.alpha;

        while (t < duration)
        {
            t += Time.deltaTime;
            float n = t / duration;

            canvasGroup.alpha = Mathf.Lerp(start, 0f, n);

            yield return null;
        }

        canvasGroup.alpha = 0f;
    }
}