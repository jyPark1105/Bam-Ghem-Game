﻿using UnityEngine;
using UnityEngine.UI;

public class SettingsPanelController : MonoBehaviour
{
    public static SettingsPanelController Instance;

    [Header("Main Panel")]
    public GameObject settingsPanel;

    [Header("Tabs")]
    public Button etcTabButton;
    public Button sensitivityTabButton;

    [Header("Panels")]
    public GameObject etcPanel;
    public GameObject sensitivityPanel;

    [Header("Tab Sprites")]
    public Sprite selectedSprite;
    public Sprite normalSprite;

    private bool isOpen = false;

    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    void Start()
    {
        OpenEtcTab();
        settingsPanel.SetActive(false);
        isOpen = false;
    }

    // =======================
    // Toggle Settings Panel
    // =======================
    public void ToggleSettings()
    {
        if (!isOpen)
            OpenSettings();
        else
            CloseSettings();
    }

    private void OpenSettings()
    {
        if (isOpen) return;

        isOpen = true;

        settingsPanel.SetActive(true);

        // 🔥 UI 모드 전환
        CursorManager.SetUI();
        PauseManager.RequestPause();

        OpenEtcTab();
    }

    private void CloseSettings()
    {
        if (!isOpen) return;

        isOpen = false;

        settingsPanel.SetActive(false);

        // 🔥 Pause 해제
        PauseManager.ReleasePause();

        // 커서는 Stage 진행 여부에 따라 자동 복구됨
        // (StartStage에서 SetGameplay 호출됨)
    }

    // =======================
    // Tab Switching
    // =======================
    public void OpenEtcTab()
    {
        etcPanel.SetActive(true);
        sensitivityPanel.SetActive(false);

        etcTabButton.image.sprite = selectedSprite;
        sensitivityTabButton.image.sprite = normalSprite;
    }

    public void OpenSensitivityTab()
    {
        etcPanel.SetActive(false);
        sensitivityPanel.SetActive(true);

        etcTabButton.image.sprite = normalSprite;
        sensitivityTabButton.image.sprite = selectedSprite;
    }
}