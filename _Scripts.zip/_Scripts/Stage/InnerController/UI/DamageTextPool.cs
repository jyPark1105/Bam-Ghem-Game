﻿using UnityEngine;
using System.Collections.Generic;

public class DamageTextPool : MonoBehaviour
{
    public static DamageTextPool Instance;

    public DamageText prefab;
    public int preload = 50;

    private readonly Queue<DamageText> pool = new();

    private void Awake()
    {
        Instance = this;

        for (int i = 0; i < preload; i++)
        {
            var dt = Instantiate(prefab, transform);
            dt.gameObject.SetActive(false);
            dt.InitPool(this);
            pool.Enqueue(dt);
        }
    }

    public DamageText Spawn()
    {
        DamageText dt =
            pool.Count > 0 ? pool.Dequeue() : Instantiate(prefab, transform);

        dt.ResetState();   // 🔥 반드시
        dt.gameObject.SetActive(true);
        return dt;
    }

    public void Return(DamageText dt)
    {
        if (!dt.gameObject.activeSelf)
            return;

        dt.gameObject.SetActive(false);
        pool.Enqueue(dt);
    }
}