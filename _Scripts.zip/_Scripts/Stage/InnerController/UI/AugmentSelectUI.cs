﻿using StarterAssets;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using Unity.VisualScripting;

public class AugmentSelectUI : MonoBehaviour
{
    public static AugmentSelectUI Instance { get; private set; }

    [Header("Slots")]
    public UI_AugmentSlot[] slots;

    [Header("Root Panel")]
    public GameObject augmentPanel;

    [Header("Frame UI")]
    public Image[] imageFrames;
    public Button[] selectButtons;
    public RectTransform[] panels;
    public TMP_Text[] augmentRarityText;
    public Image[] augmentRarityFrames;

    [Header("Frame Sprites")]
    public Sprite frameSilver;
    public Sprite frameGold;
    public Sprite frameDiamond;

    [Header("Timer UI")]
    public TMP_Text timerText;
    public float selectTimeLimit = 30f;

    // 🔥 현재 증강을 연 Chest (UI가 수명 책임)
    private AugmentChest currentChest;

    // =========================
    // Runtime
    // =========================
    private PlayerStatus player;
    private PlayerAugmentManager augment;
    private ThirdPersonController controller;

    private float timer;
    private bool selected;
    private bool isOpen;

    private List<AugmentData> currentAugments;
    private AugmentData pendingAugment;

    private Coroutine timerRoutine;

    private HashSet<string> usedIds = new();

    // UI 안정 대기시간 캐싱
    private static readonly WaitForSecondsRealtime UI_STABLE_WAIT =
        new WaitForSecondsRealtime(0.01f);
    // OpenAfterDelay 캐싱
    private static readonly Dictionary<float, WaitForSecondsRealtime> waitCache
    = new();

    private void Awake()
    {
        Instance = this;
        SetCanvasVisible(augmentPanel, false);
    }

#if UNITY_EDITOR
    private void Update()
    {
        // 에디터에서만 동작
        if (!Application.isEditor) return;

        // UI 열려 있고, 아직 선택 안 했을 때만
        if (!isOpen || selected) return;

        // X 키 누르면 첫 번째 증강 강제 선택
        if (Input.GetKeyDown(KeyCode.X))
        {
            if (currentAugments == null || currentAugments.Count == 0)
            {
                StageLogPanel.Log(
                    "[AUGMENT][EDITOR] X pressed but no augments",
                    LogType.Warning
                );
                return;
            }

            StageLogPanel.Log(
                $"[AUGMENT][EDITOR] X pressed → FORCE SELECT slot 0 ({currentAugments[0].id})"
            );

            // 🔥 강제 선택
            selected = true;
            pendingAugment = currentAugments[0];

            CoroutineRunner.Instance.StartCoroutine(CloseThenApply_SafeDebug());
        }
    }
#endif

    // =========================
    // Open
    // =========================
    public void Open(PlayerStatus ps, PlayerAugmentManager am, ThirdPersonController ctrl)
    {
        StageLogPanel.Log("[AUGMENT][OPEN] called");

        if (isOpen)
        {
            StageLogPanel.Log("[AUGMENT][OPEN] already open → return");
            return;
        }

        isOpen = true;

        player = ps;
        augment = am;
        controller = ctrl;

        StageLogPanel.Log($"[AUGMENT][OPEN] refs | player:{player != null}, augment:{augment != null}, ctrl:{controller != null}");

        selected = false;
        timer = selectTimeLimit;

        SetCanvasVisible(augmentPanel, true);
        StageLogPanel.Log("[AUGMENT][OPEN] panel active");

        Time.timeScale = 0f;
        controller?.SetBusy(true);

        currentAugments = AugmentRoller.Roll(slots.Length);
        StageLogPanel.Log($"[AUGMENT][ROLL] count = {currentAugments.Count}");

        usedIds.Clear();
        foreach (var aug in currentAugments)
            usedIds.Add(aug.id);

        for (int i = 0; i < slots.Length; i++)
        {
            int index = i;

            slots[i].slotIndex = index;
            slots[i].onRarityChanged = UpdateFrame;

            slots[i].Set(
                currentAugments[index],
                OnSelected,
                (excludeIds) =>
                {
                    StageLogPanel.Log($"[AUGMENT][REROLL] slot {index}");

                    // 🔥 HashSet 재사용
                    var newAug = AugmentRoller.Reroll(usedIds);

                    StageLogPanel.Log($"[AUGMENT][REROLL] new id = {newAug.id}");

                    usedIds.Remove(currentAugments[index].id);
                    usedIds.Add(newAug.id);

                    currentAugments[index] = newAug;
                    return newAug;
                },
                usedIds
            );

        }

        if (timerRoutine != null)
            StopCoroutine(timerRoutine);

        timerRoutine = StartCoroutine(TimerRoutine());
        StageLogPanel.Log("[AUGMENT][TIMER] start");
    }

    // =========================
    // Timer
    // =========================
    private IEnumerator TimerRoutine()
    {
        while (timer > 0f && !selected)
        {
            timer -= Time.unscaledDeltaTime;

            if (timerText != null)
                timerText.text = Mathf.CeilToInt(timer).ToString();

            yield return null;
        }

        if (!selected)
        {
            StageLogPanel.Log("[AUGMENT][AUTOSELECT]");
            AutoSelect();
        }
    }

    // =========================
    // Selection
    // =========================
    private void OnSelected(AugmentData data)
    {
        StageLogPanel.Log($"[AUGMENT][SELECT] clicked id={data.id}");

        if (selected)
        {
            StageLogPanel.Log("[AUGMENT][SELECT] already selected → return");
            return;
        }

        selected = true;
        pendingAugment = data;

        StageLogPanel.Log("[AUGMENT][SELECT] start CloseThenApply");
        CoroutineRunner.Instance.StartCoroutine(CloseThenApply_SafeDebug());
    }

    private void AutoSelect()
    {
        pendingAugment = currentAugments[Random.Range(0, currentAugments.Count)];
        StageLogPanel.Log($"[AUGMENT][AUTOSELECT] id={pendingAugment.id}");
        CoroutineRunner.Instance.StartCoroutine(CloseThenApply_SafeDebug());
    }

    // =========================
    // 🔥 핵심 디버깅 구간
    // =========================
    private IEnumerator CloseThenApply_SafeDebug()
    {
        StageLogPanel.Log(
            $"[AUGMENT][FLOW] Coroutine START | active={isActiveAndEnabled}"
        );

        // =========================
        // 1️⃣ UI 닫기
        // =========================
        CloseUI();

        // =========================
        // 2️⃣ 안정화 대기 (UI 트리)
        // =========================
        yield return UI_STABLE_WAIT;
        StageLogPanel.Log(
            $"[AUGMENT][FLOW] +1 tick (after CloseUI) | active={isActiveAndEnabled}"
        );

        // =========================
        // 3️⃣ 안정화 대기 (Canvas / TMP)
        // =========================
        yield return UI_STABLE_WAIT;
        StageLogPanel.Log(
            $"[AUGMENT][FLOW] +2 tick (Canvas stabilized) | active={isActiveAndEnabled}"
        );

        // =========================
        // 4️⃣ 참조 검증
        // =========================
        if (augment == null || player == null || controller == null)
        {
            StageLogPanel.Log(
                "[AUGMENT][FLOW][FATAL] NULL REF BEFORE APPLY",
                LogType.Error
            );
            yield break;
        }

        StageLogPanel.Log(
            $"[AUGMENT][FLOW] refs OK | " +
            $"player:{player != null}, augment:{augment != null}, ctrl:{controller != null}"
        );

        // =========================
        // 5️⃣ 증강 데이터 적용
        // =========================
        StageLogPanel.Log(
            $"[AUGMENT][APPLY] AddAugment START | id={pendingAugment.id}"
        );
        // 🔥 등록만 수행 (재귀 없음)
        augment.AddAugment(pendingAugment);
        StageLogPanel.Log("[AUGMENT][APPLY] AddAugment DONE");

        // =========================
        // 6️⃣ 상태 반영 대기
        // =========================
        yield return UI_STABLE_WAIT;
        StageLogPanel.Log(
            $"[AUGMENT][FLOW] after AddAugment | active={isActiveAndEnabled}"
        );

        // =========================
        // 7️⃣ 플레이어 스탯 적용
        // =========================
        StageLogPanel.Log("[AUGMENT][APPLY] ApplyToPlayer START");
        augment.ApplyToPlayer(player, controller);
        StageLogPanel.Log("[AUGMENT][APPLY] ApplyToPlayer DONE");

        // =========================
        // 8️⃣ 적용 안정화
        // =========================
        yield return UI_STABLE_WAIT;
        StageLogPanel.Log(
            $"[AUGMENT][FLOW] after ApplyToPlayer | active={isActiveAndEnabled}"
        );

        // =========================
        // 9️⃣ HUD 갱신 (마지막)
        // =========================
        if (UI_PlayerStatus.Instance != null)
        {
            StageLogPanel.Log("[AUGMENT][HUD] Bind START");
            UI_PlayerStatus.Instance.Bind(player, controller, augment);
            StageLogPanel.Log("[AUGMENT][HUD] Bind DONE");
        }
        else
        {
            StageLogPanel.Log(
                "[AUGMENT][HUD][WARN] UI_PlayerStatus.Instance NULL",
                LogType.Warning
            );
        }

        StageLogPanel.Log("[AUGMENT][FLOW] SAFE FLOW COMPLETE");
        StageLogPanel.Log("========================================");

        // =========================
        // 🔥 증강 완료 처리 (Chest 수명은 UI가 책임)
        // =========================
        StageLogPanel.Log("[AUGMENT][COMPLETE] handled by UI");

        if (currentChest != null)
        {
            StageLogPanel.Log("[AUGMENT][COMPLETE] Return chest to pool");
            currentChest.ReturnToPool();
            currentChest = null;
        }
    }

    // =========================
    // Close UI
    // =========================
    private void CloseUI()
    {
        StageLogPanel.Log("[AUGMENT][CLOSE] begin");

        if (timerRoutine != null)
        {
            StopCoroutine(timerRoutine);
            timerRoutine = null;
            StageLogPanel.Log("[AUGMENT][CLOSE] timer stopped");
        }

        Time.timeScale = 1f;
        StageLogPanel.Log("[AUGMENT][CLOSE] timescale restored");

        controller?.SetBusy(false);

        SetCanvasVisible(augmentPanel, false);
        StageLogPanel.Log("[AUGMENT][CLOSE] panel inactive");

        // ❌ 여기서 HUD Bind 제거됨

        isOpen = false;
        StageLogPanel.Log("[AUGMENT][CLOSE] done");
    }

    // =========================
    // Frame Update (보조)
    // =========================
    private void UpdateFrame(int index, AugmentRarity rarity)
    {
        if (index < 0 ||
            index >= imageFrames.Length ||
            imageFrames[index] == null)
        {
            StageLogPanel.Log($"[AUGMENT][FRAME][ERROR] invalid index {index}", LogType.Error);
            return;
        }

        StageLogPanel.Log($"[AUGMENT][FRAME] slot {index} rarity {rarity}");
    }

    // =========================
    // Open From Chest (필수)
    // =========================
    public void OpenFromChest(
        EnemyAI.ElementType chestElement,
        bool isCurseChest,
        GameObject playerObj,
        AugmentChest chest
    )
    {
        StageLogPanel.Log("[AUGMENT][FROM CHEST] called");

        currentChest = chest;

        if (playerObj == null)
        {
            StageLogPanel.Log("[AUGMENT][FROM CHEST][ERROR] playerObj NULL", LogType.Error);
            return;
        }

        PlayerStatus ps =
            playerObj.GetComponentInParent<PlayerStatus>();

        PlayerAugmentManager am =
            playerObj.GetComponentInParent<PlayerAugmentManager>();

        ThirdPersonController ctrl =
            playerObj.GetComponentInParent<ThirdPersonController>();

        StageLogPanel.Log(
            $"[AUGMENT][FROM CHEST] refs | " +
            $"ps:{ps != null}, am:{am != null}, ctrl:{ctrl != null}"
        );

        if (ps == null || am == null || ctrl == null)
        {
            StageLogPanel.Log(
                "[AUGMENT][FROM CHEST][ERROR] Required component missing",
                LogType.Error
            );
            return;
        }

        // 🔥 컨텍스트 설정 (속성 / 저주 여부)
        AugmentRoller.SetContext(chestElement, isCurseChest);

        if (isCurseChest)
        {
            StageLogPanel.Log("[AUGMENT][FROM CHEST] Curse chest → delayed open");

            DebugStateAnimator_InStage.Instance?.AnimateAll(
                "동속성의 몬스터 처치로 인해 능력치가 낮아집니다.\n" +
                "디버프 증강을 선택하세요."
            );

            StartCoroutine(OpenAfterDelay(ps, am, ctrl, 2f));
        }
        else
        {
            StageLogPanel.Log("[AUGMENT][FROM CHEST] Normal chest → open now");
            Open(ps, am, ctrl);
        }
    }

    private IEnumerator OpenAfterDelay(
        PlayerStatus ps,
        PlayerAugmentManager am,
        ThirdPersonController ctrl,
        float delay
    )
    {
        StageLogPanel.Log($"[AUGMENT][DELAY OPEN] wait {delay}s");

        yield return GetWait(delay);

        StageLogPanel.Log("[AUGMENT][DELAY OPEN] now opening");
        Open(ps, am, ctrl);
    }

    // WaitForSecondsRealtime 캐싱
    private static WaitForSecondsRealtime GetWait(float t)
    {
        if (!waitCache.TryGetValue(t, out var w))
        {
            w = new WaitForSecondsRealtime(t);
            waitCache[t] = w;
        }
        return w;
    }

    private void SetCanvasVisible(GameObject panel, bool visible)
    {
        var cg = panel.GetComponent<CanvasGroup>();
        if (cg == null)
        {
            cg = panel.AddComponent<CanvasGroup>();
        }

        cg.alpha = visible ? 1f : 0f;
        cg.interactable = visible;
        cg.blocksRaycasts = visible;
    }

    private void OnDisable()
    {
        StageLogPanel.Log("[AUGMENT][LIFECYCLE] AugmentSelectUI DISABLED", LogType.Error);
    }

    private void OnDestroy()
    {
        StageLogPanel.Log("[AUGMENT][LIFECYCLE] AugmentSelectUI DESTROYED", LogType.Error);
    }

    private void OnEnable()
    {
        StageLogPanel.Log("[AUGMENT][LIFECYCLE] ENABLED");
    }

}