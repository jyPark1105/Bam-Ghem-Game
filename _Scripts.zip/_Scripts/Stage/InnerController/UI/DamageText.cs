﻿using UnityEngine;
using TMPro;

[System.Serializable] 
public struct DamageInfo 
{ 
    public float physical; 
    public float magical; 
    public bool isCritical; 
    public DamageText.DamageType damageType; 
}

public class DamageText : MonoBehaviour
{
    public enum DamageType
    {
        Physical,
        Magical,
        Hybrid
    }

    [Header("Text")]
    public TMP_Text text;

    [Header("Settings")]
    public float lifeTime = 1.2f;
    public float floatSpeed = 0.25f;

    private float timer;
    private bool isCritical;
    private bool isDamageTaken;
    private DamageType damageType;

    private DamageTextPool ownerPool;
    private Transform target;
    private bool isActive;

    // ================================
    // 🔥 Camera 캐싱 (프레임 드랍 핵심 해결)
    // ================================
    // ❌ Camera.main → 매 프레임 태그 검색 (매우 비쌈)
    // ✅ Awake에서 한 번만 캐싱해서 Transform 직접 사용
    private static Transform cachedCameraTransform;

    private void Awake()
    {
        // 이미 캐싱되어 있다면 다시 찾지 않음
        if (cachedCameraTransform == null)
        {
            Camera cam = Camera.main;
            if (cam != null)
                cachedCameraTransform = cam.transform;
        }
    }

    // 풀에서 주입
    public void InitPool(DamageTextPool pool)
    {
        ownerPool = pool;
    }

    // ================================
    // Init
    // ================================
    public void Init(
        Vector3 worldPos,
        int damage,
        bool critical,
        DamageType type,
        bool isDamageTaken,
        Transform target
    )
    {
        this.target = target;
        this.isDamageTaken = isDamageTaken;
        isCritical = critical;
        damageType = type;

        timer = 0f;
        isActive = true;

        Vector3 side = isDamageTaken ? target.right : -target.right;

        float randomSide = Random.Range(
            isCritical ? 0.25f : 0.15f,
            isCritical ? 0.45f : 0.35f
        );

        float randomDepth = Random.Range(-0.1f, 0.1f);

        Vector3 randomOffset =
            side * randomSide + target.forward * randomDepth;

        Vector3 heightOffset =
            Vector3.up * (isCritical ? 0.5f : 0.3f);

        transform.position = worldPos + heightOffset + randomOffset;

        ApplyText(damage);

        // 🔥 Spawn 시 한 번만 카메라 방향 맞춤
        // LateUpdate에서 매 프레임 돌릴 필요 없음
        if (cachedCameraTransform != null)
            transform.forward = cachedCameraTransform.forward;
    }

    private void ApplyText(int damage)
    {
        text.text = isDamageTaken ? "-" + damage : damage.ToString();

        // ================================
        // 🔥 색상 정책
        // ================================

        // ✅ 플레이어 피격: 무조건 빨강
        if (isDamageTaken)
        {
            text.color = Color.red;
        }
        else
        {
            // 몬스터 피격 (기존 정책 유지)
            switch (damageType)
            {
                case DamageType.Physical:
                    text.color = new Color(0.55f, 0.35f, 0.15f); // 갈색
                    break;

                case DamageType.Magical:
                    text.color = new Color(0.7f, 0.4f, 1f); // 보라
                    break;

                case DamageType.Hybrid:
                    text.color = new Color(1f, 0.8f, 0.3f); // 금빛
                    break;
            }
        }

        text.fontSize = isCritical ? 2f : 1f;
    }


    private void Update()
    {
        if (!isActive || ownerPool == null)
            return;

        transform.position += Vector3.up * floatSpeed * Time.deltaTime;

        timer += Time.deltaTime;
        if (timer >= lifeTime)
        {
            ownerPool.Return(this);
        }
    }

    public void ResetState()
    {
        timer = 0f;
        isCritical = false;
        isDamageTaken = false;
        damageType = DamageType.Physical;

        target = null;
        isActive = false;
    }
}