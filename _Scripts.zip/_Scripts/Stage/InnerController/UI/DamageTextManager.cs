﻿using UnityEngine;

public class DamageTextManager : MonoBehaviour
{
    public static DamageTextManager Instance;

    private Camera mainCam;   // 🔥 Camera.main 캐싱

    private void Awake()
    {
        Instance = this;
        mainCam = Camera.main;
    }

    // ==============================
    // 일반 데미지
    // ==============================
    public void ShowDamage(
        Transform target,
        int damage,
        DamageText.DamageType type,
        bool isDamageTaken
    )
    {
        var text = DamageTextPool.Instance.Spawn();

        text.Init(
            target.position,
            damage,
            false,
            type,
            isDamageTaken,
            target
        );
    }

    // ==============================
    // 🔥 궁극기 집계 데미지 (1회)
    // ==============================
    public void ShowUltimateDamage(
        Vector3 center,
        int totalDamage
    )
    {
        var text = DamageTextPool.Instance.Spawn();

        text.Init(
            center,
            totalDamage,
            true,
            DamageText.DamageType.Hybrid,
            false,
            mainCam.transform
        );
    }
}