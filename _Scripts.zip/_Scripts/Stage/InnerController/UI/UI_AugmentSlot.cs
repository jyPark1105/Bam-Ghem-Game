﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
using System.Collections.Generic;

public class UI_AugmentSlot : MonoBehaviour
{
    [Header("UI")]
    public TMP_Text titleText;
    public TMP_Text descText;
    public Image iconImage;
    public Image panelImage; // 슬롯 배경

    [Header("Buttons")]
    public Button selectButton;
    public Button rerollButton;
    public TMP_Text rerollCountText;

    [Header("Reroll")]
    public int maxRerollCount = 1;
    private int currentReroll;

    public Action<int, AugmentRarity> onRarityChanged;
    public int slotIndex;

    private AugmentData currentAugment;

    // 🔥 핵심 변경
    private Action<AugmentData> onSelect;
    private Func<HashSet<string>, AugmentData> onReroll;
    private HashSet<string> usedIds;

    private Animator animator;

    // 🔥 패널 스프라이트 캐시
    private static Sprite panelSilver;
    private static Sprite panelGold;
    private static Sprite panelDiamond;


    private void Awake()
    {
        animator = GetComponent<Animator>();
        currentReroll = maxRerollCount;

        selectButton.onClick.AddListener(Select);
        rerollButton.onClick.AddListener(Reroll);

        UpdateRerollUI();
    }

    // =========================
    // ✅ Set (수정본)
    // =========================
    public void Set(
        AugmentData data,
        Action<AugmentData> onSelectCallback,
        Func<HashSet<string>, AugmentData> onRerollCallback,
        HashSet<string> usedIdSet
    )
    {
        LoadPanelSprites(); // 🔥 추가

        currentAugment = data;
        onSelect = onSelectCallback;
        onReroll = onRerollCallback;
        usedIds = usedIdSet;

        titleText.text = data.title;
        descText.text = data.description;
        iconImage.sprite = data.icon;

        // 🔥 등급별 패널 적용
        switch (data.rarity)
        {
            case AugmentRarity.Silver:
                panelImage.sprite = panelSilver;
                break;

            case AugmentRarity.Gold:
                panelImage.sprite = panelGold;
                break;

            case AugmentRarity.Diamond:
                panelImage.sprite = panelDiamond;
                break;
        }

        onRarityChanged?.Invoke(slotIndex, data.rarity);

        Debug.Log($"[AugmentSlot] {data.title} icon = {(data.icon == null ? "NULL" : data.icon.name)}");
    }

    // =========================
    // 선택
    // =========================
    private void Select()
    {
        StageLogPanel.Log($"[AUGMENT CLICK] Select: {currentAugment.title}");
        onSelect?.Invoke(currentAugment);
    }

    // =========================
    // 리롤
    // =========================
    private void Reroll()
    {
        StageLogPanel.Log("[AUGMENT CLICK] Reroll pressed");

        if (currentReroll <= 0 || onReroll == null)
            return;

        currentReroll--;
        UpdateRerollUI();

        // 🎬 리롤 애니메이션
        if (animator != null)
            animator.SetTrigger("Reroll");

        // 🔥 새 증강 요청
        AugmentData newData = onReroll.Invoke(usedIds);

        // 🔄 UI 갱신
        currentAugment = newData;
        titleText.text = newData.title;
        descText.text = newData.description;
        iconImage.sprite = newData.icon;

        onRarityChanged?.Invoke(slotIndex, newData.rarity);
    }

    private void UpdateRerollUI()
    {
        rerollCountText.text = currentReroll.ToString();
        rerollButton.interactable = currentReroll > 0;
    }

    private void LoadPanelSprites()
    {
        if (panelSilver != null) return;

        panelSilver = Resources.Load<Sprite>("Augments/UI/Panel_Silver");
        panelGold = Resources.Load<Sprite>("Augments/UI/Panel_Gold");
        panelDiamond = Resources.Load<Sprite>("Augments/UI/Panel_Diamond");

        if (panelSilver == null || panelGold == null || panelDiamond == null)
        {
            StageLogPanel.Log("[AugmentSlot] 패널 스프라이트 로드 실패! Resources/AugmentUI 확인", LogType.Error);
        }
    }

    public bool CanReroll => currentReroll > 0;
}