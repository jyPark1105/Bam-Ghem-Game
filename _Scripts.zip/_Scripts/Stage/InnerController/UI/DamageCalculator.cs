﻿using UnityEngine;

public static class DamageCalculator
{
    public static float ApplyDefense(
        float rawDamage,
        float physicalPortion,
        float magicPortion,
        EnemyAI enemy
    )
    {
        float physicalDamage = physicalPortion - enemy.stats.physicalDEF;
        float magicDamage = magicPortion - enemy.stats.magicDEF;

        physicalDamage = Mathf.Max(physicalDamage, 1f);
        magicDamage = Mathf.Max(magicDamage, 1f);

        return physicalDamage + magicDamage;
    }
}