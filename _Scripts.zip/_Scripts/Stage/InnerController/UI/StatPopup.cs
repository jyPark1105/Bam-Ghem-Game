using UnityEngine;
using TMPro;
using System.Collections;

[System.Serializable]
public class StatWatch
{
    public string statKey;          // "PhysicalATK", "MoveSpeed" ��
    public TMP_Text targetText;     // ������ �˾� ��� ���� UI
    public System.Func<float> getter; // ���� �� �������� �Լ�
    public string format;           // "0", "0.0", "0%" ��
}

public class StatPopup : MonoBehaviour
{
    public TMP_Text text;

    public float lifeTime = 2.5f;
    public float moveUpDistance = 40f;

    private CanvasGroup canvasGroup;
    private Vector3 startPos;

    private void Awake()
    {
        canvasGroup = gameObject.AddComponent<CanvasGroup>();
        startPos = transform.localPosition;
    }

    public void Init(string msg, Color color)
    {
        text.text = msg;
        text.color = color;

        StartCoroutine(Play());
    }

    private IEnumerator Play()
    {
        float t = 0f;

        while (t < lifeTime)
        {
            float p = t / lifeTime;

            // ���� ��¦ �̵�
            transform.localPosition = startPos + Vector3.up * moveUpDistance * p;

            // ������ �����
            canvasGroup.alpha = 1f - p;

            t += Time.deltaTime;
            yield return null;
        }

        Destroy(gameObject);
    }
}