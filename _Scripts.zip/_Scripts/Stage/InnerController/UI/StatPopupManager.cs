﻿using UnityEngine;
using TMPro;

public class StatPopupManager : MonoBehaviour
{
    public static StatPopupManager Instance;

    [Header("References")]
    public RectTransform popupRoot;        // StatPopupRoot
    public StatPopup popupPrefab;
    public Vector2 offset = new Vector2(40f, 0f);

    private Canvas canvas;
    private Camera uiCamera;

    private void Awake()
    {
        Instance = this;
        canvas = popupRoot.GetComponentInParent<Canvas>();
        uiCamera = canvas.worldCamera; // 🔥 Screen Space - Camera 핵심
    }

    /// <summary>
    /// 특정 스탯 텍스트 오른쪽에 팝업 표시
    /// </summary>
    public void ShowDelta(
        TMP_Text targetText,
        string msg,
        Color color
    )
    {
        if (targetText == null || popupPrefab == null) return;

        StatPopup popup = Instantiate(popupPrefab, popupRoot);
        popup.transform.SetAsLastSibling();

        RectTransform targetRT = targetText.rectTransform;
        RectTransform popupRT = popup.GetComponent<RectTransform>();

        // 1️⃣ 타겟 텍스트의 월드 좌표 → 스크린 좌표
        Vector2 screenPos = RectTransformUtility.WorldToScreenPoint(
            uiCamera,
            targetRT.position
        );

        // 2️⃣ 스크린 → StatPopupRoot 로컬 좌표
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            popupRoot,
            screenPos,
            uiCamera,
            out Vector2 localPos
        );

        // 3️⃣ 오른쪽으로 offset
        popupRT.anchoredPosition = localPos + offset;

        popup.Init(msg, color);
    }
}