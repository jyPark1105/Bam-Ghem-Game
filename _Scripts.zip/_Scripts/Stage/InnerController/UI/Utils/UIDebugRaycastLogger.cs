﻿using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class UIDebugRaycastLogger : MonoBehaviour
{
    private CursorLockMode prevLockMode;
    private bool prevCursorVisible;

    void OnEnable()
    {
        // 🔥 기존 커서 상태 백업
        prevLockMode = Cursor.lockState;
        prevCursorVisible = Cursor.visible;

        // 🔥 디버그용 커서 활성화
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        StageLogPanel.Log("[UIDebug] Cursor ENABLED", LogType.Info);
    }

    void OnDisable()
    {
        // 🔁 원래 상태 복구
        Cursor.lockState = prevLockMode;
        Cursor.visible = prevCursorVisible;

        StageLogPanel.Log("[UIDebug] Cursor RESTORED", LogType.Info);
    }

    void Update()
    {
#if UNITY_ANDROID || UNITY_IOS
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            LogUIRaycast(Input.GetTouch(0).position);
        }
#else
        if (Input.GetMouseButtonDown(0))
        {
            LogUIRaycast(Input.mousePosition);
        }
#endif
    }

    void LogUIRaycast(Vector2 screenPos)
    {
        if (EventSystem.current == null)
        {
            StageLogPanel.Log("[Raycast] ❌ EventSystem 없음", LogType.Error);
            return;
        }

        PointerEventData eventData = new PointerEventData(EventSystem.current);
        eventData.position = screenPos;

        List<RaycastResult> results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData, results);

        if (results.Count == 0)
        {
            StageLogPanel.Log("[Raycast] UI 히트 없음", LogType.Info);
            return;
        }

        StageLogPanel.Log($"[Raycast] HIT COUNT = {results.Count}", LogType.Warning);

        for (int i = 0; i < results.Count; i++)
        {
            var r = results[i];

            string canvasName =
                r.gameObject.GetComponentInParent<Canvas>()?.name ?? "NoCanvas";

            string cgInfo = "";
            var cg = r.gameObject.GetComponentInParent<CanvasGroup>();
            if (cg != null)
            {
                cgInfo =
                    $" (CanvasGroup alpha={cg.alpha}, blocksRaycasts={cg.blocksRaycasts})";
            }

            StageLogPanel.Log(
                $"[{i}] {r.gameObject.name} | Canvas={canvasName} | depth={r.depth}{cgInfo}",
                LogType.Warning
            );
        }
    }
}