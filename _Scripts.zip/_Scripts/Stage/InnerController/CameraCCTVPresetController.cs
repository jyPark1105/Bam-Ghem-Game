﻿using UnityEngine;
using Cinemachine;

public class CameraCCTVPresetController : MonoBehaviour
{
    [Header("Cameras")]
    [SerializeField] private CinemachineVirtualCamera playerCam;
    [SerializeField] private CinemachineVirtualCamera cctvCam;

    private const int PLAYER_PRIORITY = 10;
    private const int CCTV_PRIORITY = 15;

    private bool isCCTV = false;
    private bool isEnabled = false;   // 🔥 BattleSpawn 도달 전에는 false

#if UNITY_EDITOR
    private void Update()
    {
        if (!isEnabled) return;   // 🔥 활성화 전에는 작동 금지

        if (Input.GetKeyDown(KeyCode.F1))
            ToggleCCTV();
    }
#endif

    // 🔥 외부에서 활성화
    public void EnableCCTV()
    {
        isEnabled = true;
    }

    // 🔥 외부에서 비활성화
    public void DisableCCTV()
    {
        isEnabled = false;

        if (isCCTV)
            ExitCCTV();
    }

    public void ToggleCCTV()
    {
        if (!isEnabled) return;

        if (isCCTV)
            ExitCCTV();
        else
            EnterCCTV();
    }

    public void EnterCCTV()
    {
        isCCTV = true;

        playerCam.Priority = PLAYER_PRIORITY;
        cctvCam.Priority = CCTV_PRIORITY;
    }

    public void ExitCCTV()
    {
        isCCTV = false;

        playerCam.Priority = CCTV_PRIORITY;
        cctvCam.Priority = PLAYER_PRIORITY;
    }
}