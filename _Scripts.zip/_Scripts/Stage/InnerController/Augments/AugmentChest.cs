﻿using UnityEngine;

[RequireComponent(typeof(Collider))]
public class AugmentChest : MonoBehaviour
{
    [Header("Context")]
    public EnemyAI.ElementType chestElement;
    public bool isCurseChest;

    [Header("Auto Recycle")]
    public float autoRecycleAfter = 30f; // N초 (원하면 인스펙터 조절)

    [Header("Render")]
    [SerializeField] private Renderer chestRenderer;

    private MaterialPropertyBlock mpb;

    private float spawnTime;
    private bool opened = false;

    private void Awake()
    {
        if (chestRenderer == null)
            chestRenderer = GetComponentInChildren<Renderer>();

        mpb = new MaterialPropertyBlock();
    }

    // =========================
    // Init (DropManager에서 호출)
    // =========================
    public void Init(EnemyAI.ElementType element, bool curse)
    {
        chestElement = element;
        isCurseChest = curse;

        ApplyEmissionColor(element);

        StageLogPanel.Log(
            $"[CHEST][INIT] element={chestElement}, curse={isCurseChest}"
        );
    }

    public void OnSpawned()
    {
        opened = false;
        spawnTime = Time.time;

        Collider col = GetComponent<Collider>();
        if (col != null)
            col.enabled = true;

        StageLogPanel.Log(
            $"[CHEST][SPAWN] element={chestElement}"
        );
    }

    private void ApplyEmissionColor(EnemyAI.ElementType element)
    {
        if (chestRenderer == null) return;

        Color emission;
        float intensity;

        switch (element)
        {
            case EnemyAI.ElementType.Red:
                emission = Color.HSVToRGB(0f / 360f, 1f, 0.75f);
                intensity = 3.5f;
                break;

            case EnemyAI.ElementType.Green:
                emission = Color.HSVToRGB(121f / 360f, 1f, 0.75f);
                intensity = 2.5f;
                break;

            case EnemyAI.ElementType.Blue:
                emission = Color.HSVToRGB(230f / 360f, 1f, 0.75f);
                intensity = 3.5f;
                break;

            case EnemyAI.ElementType.Purple:
                emission = Color.HSVToRGB(306f / 360f, 1f, 0.75f);
                intensity = 3.5f;
                break;

            default:
                emission = Color.black;
                intensity = 0f;
                break;
        }

        emission *= intensity;

        chestRenderer.GetPropertyBlock(mpb);
        mpb.SetColor("_EmissionColor", emission);
        chestRenderer.SetPropertyBlock(mpb);
    }

    // 상태 노출 함수
    public bool IsOpened()
    {
        return opened;
    }

    // 시간 초과 여부 함수
    public bool IsExpired()
    {
        if (opened) return false; // UI 사용 중이면 절대 회수 ❌
        return Time.time - spawnTime >= autoRecycleAfter;
    }

    // =========================
    // Trigger
    // =========================
    private void OnTriggerEnter(Collider other)
    {
        StageLogPanel.Log("[CHEST][TRIGGER] enter");

        if (opened)
        {
            StageLogPanel.Log("[CHEST][TRIGGER] already opened → ignore");
            return;
        }

        if (!other.CompareTag("Player"))
        {
            StageLogPanel.Log("[CHEST][TRIGGER] not player → ignore");
            return;
        }

        // 🔥🔥🔥 활동 갱신 (접근 = 방치 타이머 리셋)
        spawnTime = Time.time;
        StageLogPanel.Log("[CHEST][ACTIVE] activity refresh");

        StageLogPanel.Log("[CHEST][TRIGGER] valid player detected");

        OpenAugmentUI(other.gameObject);
    }

    // =========================
    // UI Open (🔥 이벤트 없음)
    // =========================
    private void OpenAugmentUI(GameObject playerObj)
    {
        StageLogPanel.Log("[CHEST][OPEN] START");

        if (playerObj == null)
        {
            StageLogPanel.Log("[CHEST][OPEN][ERROR] playerObj NULL", LogType.Error);
            return;
        }

        AugmentSelectUI ui = AugmentSelectUI.Instance;
        if (ui == null)
        {
            StageLogPanel.Log("[CHEST][OPEN][ERROR] AugmentSelectUI NOT FOUND", LogType.Error);
            return;
        }

        StageLogPanel.Log("[CHEST][OPEN] AugmentSelectUI FOUND");

        // 🔒 중복 방지
        opened = true;
        StageLogPanel.Log("[CHEST][STATE] opened = true");

        // 🔥🔥🔥 Pool에서 Active 관리 제외 (UI 사용 중)
        AugmentChestPool.Instance.MarkInUse(this);

        // 🔒 트리거 차단
        Collider col = GetComponent<Collider>();
        if (col != null)
        {
            col.enabled = false;
            StageLogPanel.Log("[CHEST][STATE] collider disabled");
        }

        // -------------------------
        // 🔥 UI에게 "이 Chest에서 열렸다"만 전달
        // -------------------------
        StageLogPanel.Log(
            $"[CHEST][CONTEXT] element={chestElement}, curse={isCurseChest}"
        );

        StageLogPanel.Log("[CHEST][OPEN] OpenFromChest CALL");
        ui.OpenFromChest(
            chestElement,
            isCurseChest,
            playerObj,
            this            // ⭐ 핵심: 자기 자신 전달
        );
        StageLogPanel.Log("[CHEST][OPEN] OpenFromChest RETURN");
    }

    public void ReturnToPool()
    {
        StageLogPanel.Log("[CHEST][POOL] return");
        AugmentChestPool.Instance.Return(this);
    }
}