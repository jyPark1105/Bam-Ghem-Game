﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public enum AugmentRarity
{
    Silver,
    Gold,
    Diamond
}

public enum AugmentType
{
    Buff,
    Debuff
}

public enum AugmentStatType
{
    PhysicalATK,
    MagicATK,
    PhysicalDEF,
    MagicDEF,

    PhysicalCritChance,
    MagicCritChance,

    MaxHP,
    MaxMP,
    Cooldown,
    MoveSpeed,
    ATKSpeed,
    SkillDMG
}


[CreateAssetMenu(
    fileName = "AugmentData",
    menuName = "Augment/Augment Data"
)]
public abstract class AugmentData : ScriptableObject
{
    [Header("Base Info")]
    public string id;
    public string title;
    [TextArea] public string description;
    public Sprite icon;

    public AugmentType type;     // Buff / Debuff
    public AugmentRarity rarity; // Silver / Gold / Diamond

    // 🔥 핵심
    public List<AugmentStatType> affectedStats = new();

    public abstract void Apply(
        PlayerStatus player,
        PlayerAugmentManager augment
    );
}
