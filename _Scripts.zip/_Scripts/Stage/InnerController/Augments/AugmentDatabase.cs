using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(
    fileName = "AugmentDatabase",
    menuName = "Augment/Augment Database"
)]
public class AugmentDatabase : ScriptableObject
{
    public List<AugmentData> allAugments = new();
}
