﻿using System.Collections.Generic;
using UnityEngine;

public static class AugmentRoller
{
    private static AugmentDatabase _db;

    // =========================
    // 🔥 Context (확장용)
    // =========================
    private static EnemyAI.ElementType chestElement;
    private static bool forceCurseOnly;

    // =========================
    // 📦 Cached Pools
    // =========================
    private static Dictionary<AugmentRarity, List<AugmentData>> rarityPools;
    private static List<AugmentData> allPool;

    // =========================
    // 🔒 Cache Guard (핵심)
    // =========================
    private static bool isCacheReady = false;

    private static void EnsureCache()
    {
        if (isCacheReady) return;

        _db = Resources.Load<AugmentDatabase>("Augments/AugmentDatabase");
        if (_db == null)
        {
            Debug.LogError("❌ Resources/Augments/AugmentDatabase.asset not found");
            return;
        }

        BuildCache();
        isCacheReady = true;
    }

    private static void BuildCache()
    {
        rarityPools = new Dictionary<AugmentRarity, List<AugmentData>>();
        allPool = new List<AugmentData>(_db.allAugments.Count);

        foreach (var aug in _db.allAugments)
        {
            if (aug == null) continue;

            allPool.Add(aug);

            if (!rarityPools.TryGetValue(aug.rarity, out var list))
            {
                list = new List<AugmentData>();
                rarityPools.Add(aug.rarity, list);
            }

            list.Add(aug);
        }
    }

    // =========================
    // Context 설정
    // =========================
    public static void SetContext(
        EnemyAI.ElementType element,
        bool isCurseChest
    )
    {
        chestElement = element;
        forceCurseOnly = isCurseChest;
    }

    // =========================
    // 🎯 Rarity Roll
    // =========================
    private static AugmentRarity RollRarity()
    {
        float r = Random.value;

        if (r < 0.75f) return AugmentRarity.Silver;
        if (r < 0.95f) return AugmentRarity.Gold;
        return AugmentRarity.Diamond;
    }

    // =========================
    // 🎲 Single Roll (GC 최소화)
    // =========================
    private static AugmentData RollOne(HashSet<string> excludeIds)
    {
        EnsureCache();

        if (!isCacheReady || allPool.Count == 0)
            return null;

        AugmentData candidate = null;
        int safety = 0;

        var rarity = RollRarity();

        // 1️⃣ Rarity Pool 우선
        if (rarityPools.TryGetValue(rarity, out var pool) && pool.Count > 0)
        {
            while (candidate == null && safety < 20)
            {
                var aug = pool[Random.Range(0, pool.Count)];
                if (excludeIds == null || !excludeIds.Contains(aug.id))
                    candidate = aug;

                safety++;
            }
        }

        // 2️⃣ 전체 Pool fallback
        safety = 0;
        while (candidate == null && safety < 50)
        {
            var aug = allPool[Random.Range(0, allPool.Count)];
            if (excludeIds == null || !excludeIds.Contains(aug.id))
                candidate = aug;

            safety++;
        }

        return candidate;
    }

    // =========================
    // 🎲 최초 Roll
    // =========================
    public static List<AugmentData> Roll(int count)
    {
        EnsureCache();

        var result = new List<AugmentData>(count);
        var usedIds = new HashSet<string>();

        int safety = 0;

        while (result.Count < count && safety < 100)
        {
            var aug = RollOne(usedIds);
            if (aug != null && usedIds.Add(aug.id))
                result.Add(aug);

            safety++;
        }

        return result;
    }

    // =========================
    // 🔁 Reroll
    // =========================
    public static AugmentData Reroll(HashSet<string> excludeIds)
    {
        return RollOne(excludeIds);
    }
}