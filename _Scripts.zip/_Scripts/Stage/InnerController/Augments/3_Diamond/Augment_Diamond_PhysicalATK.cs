using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Physical ATK")]
public class Augment_Diamond_PhysicalATK : AugmentData
{
    public float addPhysicalATK = 20f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalATK };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalATK += addPhysicalATK;
        
    }
}