using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Max HP")]
public class Augment_Diamond_MaxHP : AugmentData
{
    public float addMaxHP = 40f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MaxHP };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxHP += addMaxHP;
    }
}
