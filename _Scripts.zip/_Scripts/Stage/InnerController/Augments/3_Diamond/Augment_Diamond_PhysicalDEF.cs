using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Physical DEF")]
public class Augment_Diamond_PhysicalDEF : AugmentData
{
    public float addPhysicalDEF = 10f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalDEF };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalDEF += addPhysicalDEF;
        
    }
}