using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Physical + Critical Chance")]
public class Augment_Diamond_PhysicalCritChance : AugmentData
{
    [Range(0f, 1f)]
    public float addPhysicalCritChance = 0.35f; // +35%

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalCritChance };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalCritChance += addPhysicalCritChance;
    }
}