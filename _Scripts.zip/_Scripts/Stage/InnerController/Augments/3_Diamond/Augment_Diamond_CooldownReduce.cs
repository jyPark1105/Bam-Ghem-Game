using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Cooldown Reduce")]
public class Augment_Diamond_CooldownReduce : AugmentData
{
    public float reduceRate = 0.4f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.Cooldown };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.cooldownMultiplier *= reduceRate;
        
    }
}