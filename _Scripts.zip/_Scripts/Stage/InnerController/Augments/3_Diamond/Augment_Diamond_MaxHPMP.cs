using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Max HP + MP")]
public class Augment_Diamond_MaxHPMP : AugmentData
{
    public float addMaxHP = 30f;
    public float addMaxMP = 40f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.MaxHP,
            AugmentStatType.MaxMP
        };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxHP += addMaxHP;
        augment.bonusMaxMP += addMaxMP;
    }
}