using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Heal HP")]
public class Augment_Diamond_HealHP
    : AugmentData, IImmediateEffect
{
    public float healAmountHP = 30f;

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        // ���ȿ� ���� ����
    }

    public void ExecuteImmediate(PlayerStatus player)
    {
        player.HealHP(healAmountHP);
    }
}