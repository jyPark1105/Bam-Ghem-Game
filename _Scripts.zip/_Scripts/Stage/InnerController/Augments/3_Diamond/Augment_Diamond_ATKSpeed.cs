using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/ATKSpeed Up")]
public class Augment_Diamond_ATKSpeed : AugmentData
{
    public float addATKSpeed = 0.2f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.ATKSpeed };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusATKSpeed += addATKSpeed;
    }
}