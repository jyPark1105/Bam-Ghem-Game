using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Magical + Physical ATK")]
public class Augment_Diamond_MagicPhysicalATK : AugmentData
{
    public float addPhysicalATK = 15f;
    public float addMagicATK = 15f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.PhysicalATK,
            AugmentStatType.MagicATK
        };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalATK += addPhysicalATK;
        augment.bonusMagicATK += addMagicATK;
        
    }
}