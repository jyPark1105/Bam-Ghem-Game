using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Magic + Physical DEF")]
public class Augment_Diamond_MagicPhysicalDEF : AugmentData
{
    public float addPhysicalDEF = 8f;
    public float addMagicDEF = 8f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.PhysicalDEF,
            AugmentStatType.MagicDEF
        };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalDEF += addPhysicalDEF;
        augment.bonusMagicDEF += addMagicDEF;
        
    }
}
