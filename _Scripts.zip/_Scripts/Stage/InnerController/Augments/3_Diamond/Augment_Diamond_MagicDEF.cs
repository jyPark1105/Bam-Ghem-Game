using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Magic DEF")]
public class Augment_Diamond_MagicDEF : AugmentData
{
    public float addMagicDEF = 10f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicDEF };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicDEF += addMagicDEF;
        
    }
}
