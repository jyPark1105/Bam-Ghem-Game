using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/MoveSpeed Up")]
public class Augment_Diamond_MoveSpeed : AugmentData
{
    public float addMoveSpeed = 1.2f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MoveSpeed };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMoveSpeed += addMoveSpeed;
    }
}