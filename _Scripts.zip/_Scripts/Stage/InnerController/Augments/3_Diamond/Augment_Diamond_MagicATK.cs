using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Magic ATK")]
public class Augment_Diamond_MagicATK : AugmentData
{
    public float addMagicATK = 20f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicATK };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicATK += addMagicATK;
        
    }
}