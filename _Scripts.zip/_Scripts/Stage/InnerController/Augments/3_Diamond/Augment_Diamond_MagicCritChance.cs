using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Magic + Critical Chance")]
public class Augment_Diamond_MagicCritChance : AugmentData
{
    [Range(0f, 1f)]
    public float addMagicCritChance = 0.35f; // +35%

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicCritChance };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicCritChance += addMagicCritChance;
    }
}