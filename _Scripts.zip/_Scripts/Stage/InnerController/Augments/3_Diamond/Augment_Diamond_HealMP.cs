using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Heal MP")]
public class Augment_Diamond_HealMP
    : AugmentData, IImmediateEffect
{
    public float healAmountMP = 30f;

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        // ���ȿ� ���� ����
    }

    public void ExecuteImmediate(PlayerStatus player)
    {
        player.HealMP(healAmountMP);
    }
}