using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Diamond/Max MP")]
public class Augment_Diamond_MaxMP : AugmentData
{
    public float addMaxMP = 50f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MaxMP };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxMP += addMaxMP;
    }
}
