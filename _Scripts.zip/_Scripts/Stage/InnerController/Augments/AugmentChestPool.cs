﻿using UnityEngine;
using System.Collections.Generic;

public class AugmentChestPool : MonoBehaviour
{
    public static AugmentChestPool Instance;

    [Header("Prefabs")]
    public AugmentChest redPrefab;
    public AugmentChest bluePrefab;
    public AugmentChest greenPrefab;
    public AugmentChest purplePrefab;

    [Header("Pool Size Per Color")]
    public int poolSizePerColor = 5;

    [Header("Root")]
    public Transform poolRoot;

    private Dictionary<EnemyAI.ElementType, Queue<AugmentChest>> pools =
        new();

    private Dictionary<EnemyAI.ElementType, LinkedList<AugmentChest>> actives =
        new();

    private void Awake()
    {
        Instance = this;

        CreatePool(EnemyAI.ElementType.Red, redPrefab);
        CreatePool(EnemyAI.ElementType.Blue, bluePrefab);
        CreatePool(EnemyAI.ElementType.Green, greenPrefab);
        CreatePool(EnemyAI.ElementType.Purple, purplePrefab);
    }

    private void Update()
    {
        foreach (var kv in actives)
        {
            var list = kv.Value;
            if (list.Count == 0) continue;

            var node = list.First;
            while (node != null)
            {
                var next = node.Next;

                if (node.Value.IsExpired())
                {
                    StageLogPanel.Log(
                        $"[CHEST POOL] Auto recycle expired {kv.Key} chest"
                    );

                    node.Value.ReturnToPool();
                }

                node = next;
            }
        }
    }

    private void CreatePool(
        EnemyAI.ElementType type,
        AugmentChest prefab
    )
    {
        Queue<AugmentChest> pool = new();
        LinkedList<AugmentChest> activeList = new();

        for (int i = 0; i < poolSizePerColor; i++)
        {
            AugmentChest chest =
                Instantiate(prefab, poolRoot);

            chest.gameObject.SetActive(false);
            pool.Enqueue(chest);
        }

        pools[type] = pool;
        actives[type] = activeList;
    }

    // =========================
    // Get (🔥 부족하면 가장 오래된 Chest 회수)
    // =========================
    public AugmentChest Get(EnemyAI.ElementType type, Vector3 position)
    {
        if (!pools.ContainsKey(type)) return null;

        if (pools[type].Count == 0) ForceRecycleOldest(type);
        if (pools[type].Count == 0) return null;

        AugmentChest chest = pools[type].Dequeue();

        // ✅ 겹침 방지 위치 보정
        position = FindNonOverlappingPosition(position, 0.35f, 8, 0.6f);

        chest.transform.position = position;
        chest.transform.rotation = Quaternion.identity;
        chest.gameObject.SetActive(true);
        chest.OnSpawned();

        actives[type].AddLast(chest);
        return chest;
    }

    private Vector3 FindNonOverlappingPosition(
        Vector3 origin,
        float radius,
        int tries,
        float step
    )
    {
        int augmentLayer = LayerMask.NameToLayer("Augment");
        int mask = 1 << augmentLayer;

        for (int i = 0; i < tries; i++)
        {
            Vector3 candidate = origin + (Random.insideUnitSphere * step);
            candidate.y = origin.y; // 바닥 평면 유지

            // ✅ Augment 레이어(Chest)랑 겹치면 다른 위치 시도
            Collider[] hits = Physics.OverlapSphere(candidate, radius, mask);
            if (hits == null || hits.Length == 0)
                return candidate;
        }

        // 못 찾으면 원위치라도 반환
        return origin;
    }

    // 로그 안정성 확보
    public void MarkInUse(AugmentChest chest)
    {
        EnemyAI.ElementType type = chest.chestElement;

        if (!actives.ContainsKey(type)) return;

        actives[type].Remove(chest); // 없으면 그냥 무시됨
    }

    // =========================
    // Return
    // =========================
    public void Return(AugmentChest chest)
    {
        EnemyAI.ElementType type = chest.chestElement;

        if (pools[type].Contains(chest))
            return;

        chest.gameObject.SetActive(false);
        chest.transform.SetParent(poolRoot);

        actives[type].Remove(chest);
        pools[type].Enqueue(chest);
    }


    // =========================
    // 🔥 가장 오래된 Chest 강제 회수
    // =========================
    private void ForceRecycleOldest(EnemyAI.ElementType type)
    {
        var list = actives[type];
        if (list.Count == 0)
            return;

        var node = list.First;

        while (node != null)
        {
            AugmentChest chest = node.Value;

            if (!chest.IsOpened())
            {
                StageLogPanel.Log(
                    $"[CHEST POOL] Force recycle oldest {type} chest"
                );

                chest.ReturnToPool();
                return;
            }

            node = node.Next;
        }

        StageLogPanel.Log(
            $"[CHEST POOL] No recyclable {type} chest found",
            LogType.Warning
        );
    }
}