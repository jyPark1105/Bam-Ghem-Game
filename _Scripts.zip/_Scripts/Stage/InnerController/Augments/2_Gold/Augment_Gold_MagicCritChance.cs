using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Magic + Critical Chance")]
public class Augment_Gold_MagicCritChance : AugmentData
{
    [Range(0f, 1f)]
    public float addMagicCritChance = 0.2f; // +20%

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicCritChance };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicCritChance += addMagicCritChance;
    }
}