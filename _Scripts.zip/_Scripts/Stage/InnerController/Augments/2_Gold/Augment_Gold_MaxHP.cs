using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Max HP")]
public class Augment_Gold_MaxHP : AugmentData
{
    public float addMaxHP = 25f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MaxHP };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxHP += addMaxHP;
    }
}
