using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Physical + Critical Chance")]
public class Augment_Gold_PhysicalCritChance : AugmentData
{
    [Range(0f, 1f)]
    public float addPhysicalCritChance = 0.2f; // +20%

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalCritChance };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalCritChance += addPhysicalCritChance;
    }
}