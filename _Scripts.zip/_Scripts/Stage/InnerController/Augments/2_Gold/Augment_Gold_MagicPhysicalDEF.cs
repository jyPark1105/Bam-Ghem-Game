using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Magic + Physical DEF")]
public class Augment_Gold_MagicPhysicalDEF : AugmentData
{
    public float addPhysicalDEF = 4f;
    public float addMagicDEF = 4f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.PhysicalDEF,
            AugmentStatType.MagicDEF
        };
    }
    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalDEF += addPhysicalDEF;
        augment.bonusMagicDEF += addMagicDEF;
        
    }
}
