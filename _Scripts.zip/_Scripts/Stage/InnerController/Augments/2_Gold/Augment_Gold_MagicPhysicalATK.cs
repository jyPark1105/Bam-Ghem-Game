using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Magic + Physical ATK")]
public class Augment_Gold_MagicPhysicalATK : AugmentData
{
    public float addPhysicalATK = 7f;
    public float addMagicATK = 7f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.PhysicalATK,
            AugmentStatType.MagicATK
        };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalATK += addPhysicalATK;
        augment.bonusMagicATK += addMagicATK;
        
    }
}