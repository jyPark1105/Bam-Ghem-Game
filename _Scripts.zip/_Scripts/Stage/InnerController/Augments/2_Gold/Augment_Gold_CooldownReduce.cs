using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Cooldown Reduce")]
public class Augment_Gold_CooldownReduce: AugmentData
{
    public float reduceRate = 0.2f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.Cooldown };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.cooldownMultiplier *= reduceRate;
        
    }
}