using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Magic ATK")]
public class Augment_Gold_MagicATK : AugmentData
{
    public float addMagicATK = 10f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicATK };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicATK += addMagicATK;
        
    }
}