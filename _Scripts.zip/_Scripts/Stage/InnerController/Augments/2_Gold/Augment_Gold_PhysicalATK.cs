using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Physical ATK")]
public class Augment_Gold_PhysicalATK : AugmentData
{
    public float addPhysicalATK = 10f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalATK };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalATK += addPhysicalATK;
        
    }
}