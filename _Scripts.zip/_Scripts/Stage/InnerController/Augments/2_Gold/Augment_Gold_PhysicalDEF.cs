using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Physical DEF")]
public class Augment_Gold_PhysicalDEF : AugmentData
{
    public float addPhysicalDEF = 5f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalDEF };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalDEF += addPhysicalDEF;
        
    }
}