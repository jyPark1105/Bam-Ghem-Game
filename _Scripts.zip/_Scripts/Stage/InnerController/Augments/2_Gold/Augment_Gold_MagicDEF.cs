using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Magic DEF")]
public class Augment_Gold_MagicDEF : AugmentData
{
    public float addMagicDEF = 5f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicDEF };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicDEF += addMagicDEF;
        
    }
}
