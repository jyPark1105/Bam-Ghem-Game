using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Max MP")]
public class Augment_Gold_MaxMP : AugmentData
{
    public float addMaxMP = 35f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MaxMP };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxMP += addMaxMP;
    }
}
