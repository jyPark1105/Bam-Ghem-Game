using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/ATKSpeed Up")]
public class Augment_Gold_ATKSpeed : AugmentData
{
    public float addATKSpeed = 0.1f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.ATKSpeed };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusATKSpeed += addATKSpeed;
    }
}