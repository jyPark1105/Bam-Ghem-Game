using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/MoveSpeed Up")]
public class Augment_Gold_MoveSpeed : AugmentData
{
    public float addMoveSpeed = 1.1f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MoveSpeed };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMoveSpeed += addMoveSpeed;
    }
}