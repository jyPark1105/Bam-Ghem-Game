using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Gold/Max HP + MP")]
public class Augment_Gold_MaxHPMP : AugmentData
{
    public float addMaxHP = 20f;
    public float addMaxMP = 30f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.MaxHP,
            AugmentStatType.MaxMP
        };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxHP += addMaxHP;
        augment.bonusMaxMP += addMaxMP;
    }
}