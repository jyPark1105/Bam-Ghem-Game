using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Max HP + MP")]
public class Augment_Silver_MaxHPMP : AugmentData
{
    public float addMaxHP = 10f;
    public float addMaxMP = 20f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.MaxHP,
            AugmentStatType.MaxMP
        };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxHP += addMaxHP;
        augment.bonusMaxMP += addMaxMP;
    }
}