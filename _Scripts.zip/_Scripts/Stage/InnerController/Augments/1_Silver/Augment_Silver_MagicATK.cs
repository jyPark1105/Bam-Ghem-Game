using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Magic ATK")]
public class Augment_Silver_MagicATK : AugmentData
{
    public float addMagicATK = 5f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicATK };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicATK += addMagicATK;
    }
}