using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Physical + Critical Chance")]
public class Augment_Silver_PhysicalCritChance : AugmentData
{
    [Range(0f, 1f)]
    public float addPhysicalCritChance = 0.1f; // +10%

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalCritChance };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalCritChance += addPhysicalCritChance;
    }
}