using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Physical ATK")]
public class Augment_Silver_PhysicalATK : AugmentData
{
    public float addPhysicalATK = 5f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalATK };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalATK += addPhysicalATK;
        
    }
}