using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/ATKSpeed Up")]
public class Augment_Silver_ATKSpeed : AugmentData
{
    public float addATKSpeed = 0.05f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.ATKSpeed };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusATKSpeed += addATKSpeed;
    }
}