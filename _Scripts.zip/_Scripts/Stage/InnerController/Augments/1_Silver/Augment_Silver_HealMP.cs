using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Heal MP")]
public class Augment_Silver_HealMP
    : AugmentData, IImmediateEffect
{
    public float healAmountMP = 20f;

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        // ���ȿ� ���� ����
    }

    public void ExecuteImmediate(PlayerStatus player)
    {
        player.HealMP(healAmountMP);
    }
}