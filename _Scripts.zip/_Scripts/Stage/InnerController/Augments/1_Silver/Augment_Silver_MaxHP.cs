using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Max HP")]
public class Augment_Silver_MaxHP : AugmentData
{
    public float addMaxHP = 15f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MaxHP };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxHP += addMaxHP;
    }
}
