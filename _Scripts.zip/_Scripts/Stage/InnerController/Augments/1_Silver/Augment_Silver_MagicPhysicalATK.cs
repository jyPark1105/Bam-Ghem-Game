using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Magic + Physical ATK")]
public class Augment_Silver_MagicPhysicalATK : AugmentData
{
    public float addPhysicalATK = 3f;
    public float addMagicATK = 3f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.PhysicalATK,
            AugmentStatType.MagicATK
        };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalATK += addPhysicalATK;
        augment.bonusMagicATK += addMagicATK;
    }
}