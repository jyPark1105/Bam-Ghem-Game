using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Magic + Physical DEF")]
public class Augment_Silver_MagicPhysicalDEF : AugmentData
{
    public float addPhysicalDEF = 2f;
    public float addMagicDEF = 2f;

    private void OnEnable()
    {
        affectedStats = new()
        {
            AugmentStatType.PhysicalDEF,
            AugmentStatType.MagicDEF
        };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalDEF += addPhysicalDEF;
        augment.bonusMagicDEF += addMagicDEF;
    }
}
