using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Max MP")]
public class Augment_Silver_MaxMP : AugmentData
{
    public float addMaxMP = 25f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MaxMP };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMaxMP += addMaxMP;
    }
}
