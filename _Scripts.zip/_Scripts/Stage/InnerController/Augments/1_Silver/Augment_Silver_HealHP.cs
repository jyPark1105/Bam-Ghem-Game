using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Heal HP")]
public class Augment_Silver_HealHP
    : AugmentData, IImmediateEffect
{
    public float healAmountHP = 20f;

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        // ���ȿ� ���� ����
    }

    public void ExecuteImmediate(PlayerStatus player)
    {
        player.HealHP(healAmountHP);
    }
}
