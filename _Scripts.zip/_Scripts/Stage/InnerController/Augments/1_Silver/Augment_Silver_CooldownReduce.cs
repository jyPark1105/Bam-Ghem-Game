using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Cooldown Reduce")]
public class Augment_Silver_CooldownReduce : AugmentData
{
    public float reduceRate = 0.1f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.Cooldown };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.cooldownMultiplier *= 1f - reduceRate;
    }
}