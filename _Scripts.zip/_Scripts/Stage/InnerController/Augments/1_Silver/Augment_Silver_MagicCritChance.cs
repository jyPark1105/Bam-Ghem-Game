using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Magic + Critical Chance")]
public class Augment_Silver_MagicCritChance : AugmentData
{
    [Range(0f, 1f)]
    public float addMagicCritChance = 0.1f; // +10%

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicCritChance };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicCritChance += addMagicCritChance;
    }
}