using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Physical DEF")]
public class Augment_Silver_PhysicalDEF : AugmentData
{
    public float addPhysicalDEF = 3f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.PhysicalDEF };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusPhysicalDEF += addPhysicalDEF;
        
    }
}