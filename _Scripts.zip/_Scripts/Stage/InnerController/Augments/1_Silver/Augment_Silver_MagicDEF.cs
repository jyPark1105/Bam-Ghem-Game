using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/Magic DEF")]
public class Augment_Silver_MagicDEF : AugmentData
{
    public float addMagicDEF = 3f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MagicDEF };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMagicDEF += addMagicDEF;
    }
}
