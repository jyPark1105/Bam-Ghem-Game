using UnityEngine;

[CreateAssetMenu(menuName = "Augment/Buff/Silver/MoveSpeed Up")]
public class Augment_Silver_MoveSpeed : AugmentData
{
    public float addMoveSpeed = 1.05f;

    private void OnEnable()
    {
        affectedStats = new() { AugmentStatType.MoveSpeed };
    }

    public override void Apply(PlayerStatus player, PlayerAugmentManager augment)
    {
        augment.bonusMoveSpeed += addMoveSpeed;
    }
}