﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using System.Collections.Generic;

public class DebugStateAnimator_InStage : MonoBehaviour
{
    public static DebugStateAnimator_InStage Instance { get; private set; }

    [Header("Root")]
    public GameObject statusFrameRoot;

    [Header("Target UI Elements")]
    public RectTransform condFrame;
    public Image statusFrame;
    public TMP_Text statusText;   // ✅ 직접 텍스트 참조

    [Header("Animation Settings")]
    public float duration = 1.0f;
    public float messageHoldTime = 2.0f;

    [Header("Behavior Settings")]
    public bool autoStart = true;

    [Header("UI Sound")]
    public AudioSource audioSource;
    public AudioClip notifyClip;
    public bool playSound = true;

    private Coroutine messageRoutine;
    private readonly Queue<string> messageQueue = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        // 🔒 초기 비활성
        if (statusFrameRoot != null)
            statusFrameRoot.SetActive(false);

        if (condFrame != null)
            condFrame.gameObject.SetActive(false);

        if (statusFrame != null)
            statusFrame.gameObject.SetActive(false);

        if (statusText != null)
            statusText.text = "";
    }

    // =========================
    // 외부 호출 API
    // =========================
    public void AnimateAll(string message)
    {
        if (!autoStart) return;
        if (string.IsNullOrEmpty(message)) return;
        if (statusText == null) return;

        // 🔥 Root 보장
        if (statusFrameRoot != null && !statusFrameRoot.activeSelf)
            statusFrameRoot.SetActive(true);

        messageQueue.Enqueue(message);

        if (messageRoutine == null)
            messageRoutine = StartCoroutine(MessageLoop());
    }

    private IEnumerator MessageLoop()
    {
        while (messageQueue.Count > 0)
        {
            string msg = messageQueue.Dequeue();
            yield return StartCoroutine(ShowMessageRoutine(msg));
        }
        messageRoutine = null;
    }

    private IEnumerator ShowMessageRoutine(string message)
    {
        // 🔔 Sound
        if (playSound && audioSource != null && notifyClip != null)
            audioSource.PlayOneShot(notifyClip);

        // 📝 텍스트 설정
        statusText.text = message;

        if (condFrame != null && !condFrame.gameObject.activeSelf)
            condFrame.gameObject.SetActive(true);

        if (statusFrame != null && !statusFrame.gameObject.activeSelf)
            statusFrame.gameObject.SetActive(true);

        yield return MoveAndFade(100f, -5f, 0f, 1f, duration);
        yield return new WaitForSeconds(messageHoldTime);
        yield return MoveAndFade(-5f, 100f, 1f, 0f, duration);

        // 🔻 정리
        if (condFrame != null)
            condFrame.gameObject.SetActive(false);

        if (statusFrame != null)
            statusFrame.gameObject.SetActive(false);

        statusText.text = "";

        if (statusFrameRoot != null)
            statusFrameRoot.SetActive(false);
    }

    private IEnumerator MoveAndFade(
        float startY, float endY,
        float startAlpha, float endAlpha,
        float time)
    {
        float elapsed = 0f;

        while (elapsed < time)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / time);

            float newY = Mathf.Lerp(startY, endY, t);

            if (condFrame != null)
            {
                Vector3 pos = condFrame.anchoredPosition;
                pos.y = newY;
                condFrame.anchoredPosition = pos;
            }

            float newAlpha = Mathf.Lerp(startAlpha, endAlpha, t);

            if (statusText != null)
            {
                Color c = statusText.color;
                c.a = newAlpha;
                statusText.color = c;
            }

            if (statusFrame != null)
            {
                Color c = statusFrame.color;
                c.a = newAlpha;
                statusFrame.color = c;
            }

            yield return null;
        }
    }
}