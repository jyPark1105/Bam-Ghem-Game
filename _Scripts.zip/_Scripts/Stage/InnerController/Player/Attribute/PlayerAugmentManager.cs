﻿using StarterAssets;
using UnityEngine;
using System.Collections.Generic;

public interface IImmediateEffect
{
    void ExecuteImmediate(PlayerStatus player);
}

public class PlayerAugmentManager : MonoBehaviour
{
    // =========================
    // Apply to Player (Bonus)
    // =========================
    [Header("Attack")]
    public float bonusPhysicalATK;
    public float bonusMagicATK;
    public float critChanceBonus;

    [Header("Critical")]
    public float bonusPhysicalCritChance;
    public float bonusMagicCritChance;

    [Header("Defense")]
    public float bonusPhysicalDEF;
    public float bonusMagicDEF;

    [Header("Utility")]
    public float skillDamageMultiplier = 1f;
    public float cooldownMultiplier = 1f;
    public float bonusATKSpeed;
    public float bonusMoveSpeed;
    public float sizeMultiplier = 1f;

    [Header("Resource")]
    public float bonusMaxHP;
    public float bonusMaxMP;

    [Header("Visual")]
    [SerializeField] private Transform visualRoot;

    // =========================
    // Internal Cache
    // =========================
    private Vector3 baseVisualScale;
    private bool visualInitialized = false;

    // =========================
    // 🔥 Applied Augments Cache
    // =========================
    private readonly List<AugmentData> appliedAugments = new();

    // =========================
    // Add Augment (REGISTER ONLY)
    // =========================
    public void AddAugment(AugmentData augment)
    {
        if (augment == null)
        {
            StageLogPanel.Log("[AUGMENT][ERROR] augment NULL", LogType.Error);
            return;
        }

        /* // 증강 중복 X
        if (appliedAugments.Contains(augment))
        {
            StageLogPanel.Log($"[AUGMENT][SKIP] already applied: {augment.title}");
            return;
        }*/

        // 일반: 증강 중복 허용
        appliedAugments.Add(augment);

        // 즉시 효과 처리: Heal 계열
        if (augment is IImmediateEffect immediate)
        {
            immediate.ExecuteImmediate(PlayerStatus.Instance);
        }

        StageLogPanel.Log($"[AUGMENT][REGISTER] {augment.title}");
    }

    // =========================
    // Apply To Player (SAFE)
    // =========================
    public void ApplyToPlayer(PlayerStatus ps, ThirdPersonController controller)
    {
        if (ps == null || controller == null)
        {
            StageLogPanel.Log("[APPLY][ERROR] ps or controller NULL", LogType.Error);
            return;
        }

        // 🔥 보너스 초기화
        ResetBonuses();

        // =========================
        // 증강 효과 적용
        // =========================
        foreach (var aug in appliedAugments)
        {
            aug.Apply(ps, this); // ✅ MaxHP 증강은 여기서 player.AddMaxHP()로 처리됨
        }

        // =========================
        // 이동
        // =========================
        controller.MoveSpeed =
            Mathf.Max(0.1f, controller.BaseMoveSpeed + bonusMoveSpeed);

        controller.SprintSpeed =
            Mathf.Max(0.1f, controller.BaseSprintSpeed + bonusMoveSpeed);

        // =========================
        // UI 갱신
        // =========================
        ps.NotifyStatChanged();
    }

    // =========================
    // Reset Bonuses (CRITICAL)
    // =========================
    private void ResetBonuses()
    {
        bonusPhysicalATK = 0f;
        bonusMagicATK = 0f;
        bonusPhysicalCritChance = 0f;
        bonusMagicCritChance = 0f;

        bonusPhysicalDEF = 0f;
        bonusMagicDEF = 0f;

        skillDamageMultiplier = 1f;
        cooldownMultiplier = 1f;
        bonusATKSpeed = 0f;
        bonusMoveSpeed = 0f;
        sizeMultiplier = 1f;

        bonusMaxHP = 0f;
        bonusMaxMP = 0f;
    }

    /* 오류로 인한 사용 금지(Code는 냅두기)
    // =========================
    // Visual Scale
    // =========================
    private void ApplyVisualScale()
    {
        if (visualRoot == null || !visualRoot.gameObject.activeInHierarchy)
            return;

        if (!visualInitialized)
        {
            baseVisualScale = visualRoot.localScale;
            visualInitialized = true;
        }

        float clamped = Mathf.Clamp(sizeMultiplier, 0.8f, 1.5f);
        visualRoot.localScale = baseVisualScale * clamped;
    }
    */

    // 개수 집계용 API
    public int GetAugmentCountByStatAndRarity(
        AugmentStatType stat,
        AugmentRarity rarity
    )
    {
        int count = 0;

        foreach (var aug in appliedAugments)
        {
            if (aug.rarity != rarity) continue;
            if (!aug.affectedStats.Contains(stat)) continue;

            count++;
        }

        return count;
    }
}