using System.Collections.Generic;

public static class AbsorbCritBonusTable
{
    private static readonly Dictionary<PlayerAbsorbEffect.ColorType, float> bonus =
        new Dictionary<PlayerAbsorbEffect.ColorType, float>
    {
        { PlayerAbsorbEffect.ColorType.Blue,   0.00f }, // ������
        { PlayerAbsorbEffect.ColorType.Red,    0.10f }, // ������ +10%
        { PlayerAbsorbEffect.ColorType.Green,  0.00f }, // ����Ʈ��
        { PlayerAbsorbEffect.ColorType.Purple, 0.05f }, // ������ +5%
    };

    public static float GetBonus(PlayerAbsorbEffect.ColorType absorbType)
    {
        return bonus.TryGetValue(absorbType, out var v) ? v : 0f;
    }
}