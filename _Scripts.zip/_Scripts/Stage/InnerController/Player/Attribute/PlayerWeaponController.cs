﻿using UnityEngine;
using System.Collections.Generic;

public class PlayerWeaponController : MonoBehaviour
{
    [Header("Base Weapons (None)")]
    public GameObject swordBase_L;
    public GameObject swordBase_R;

    [Header("Left Weapons")]
    public GameObject swordBlue_L;
    public GameObject swordRed_L;
    public GameObject swordGreen_L;
    public GameObject swordPurple_L;

    [Header("Right Weapons")]
    public GameObject swordBlue_R;
    public GameObject swordRed_R;
    public GameObject swordGreen_R;
    public GameObject swordPurple_R;

    private Dictionary<PlayerAbsorbEffect.ColorType, GameObject> left;
    private Dictionary<PlayerAbsorbEffect.ColorType, GameObject> right;

    private GameObject[] currentWeapons; // [0] = L, [1] = R
    private PlayerAbsorbEffect.ColorType currentColor;

    private void Awake()
    {
        left = new()
        {
            { PlayerAbsorbEffect.ColorType.None, swordBase_L },
            { PlayerAbsorbEffect.ColorType.Blue, swordBlue_L },
            { PlayerAbsorbEffect.ColorType.Red, swordRed_L },
            { PlayerAbsorbEffect.ColorType.Green, swordGreen_L },
            { PlayerAbsorbEffect.ColorType.Purple, swordPurple_L }
        };

        right = new()
        {
            { PlayerAbsorbEffect.ColorType.None, swordBase_R },
            { PlayerAbsorbEffect.ColorType.Blue, swordBlue_R },
            { PlayerAbsorbEffect.ColorType.Red, swordRed_R },
            { PlayerAbsorbEffect.ColorType.Green, swordGreen_R },
            { PlayerAbsorbEffect.ColorType.Purple, swordPurple_R }
        };

        DisableAll();

        // 🔥 시작 시 무속성 무기 장착
        ApplyWeaponInternal(PlayerAbsorbEffect.ColorType.None);
    }

    /* ===============================
     * Swap / 초기 상태 (연출 ❌)
     * ===============================*/
    public void ApplyWeaponInternal(PlayerAbsorbEffect.ColorType type)
    {
        DisableAll();

        left.TryGetValue(type, out var l);
        right.TryGetValue(type, out var r);

        if (l) l.SetActive(true);
        if (r) r.SetActive(true);

        currentWeapons = new[] { l, r };
        currentColor = type;
    }

    /* ===============================
     * Absorb 전용 (Hide → Reveal)
     * ===============================*/
    public void HideCurrentWeapons(System.Action onComplete)
    {
        if (currentWeapons == null)
        {
            onComplete?.Invoke();
            return;
        }

        WeaponRevealController reveal = GetComponent<WeaponRevealController>();
        if (!reveal)
        {
            onComplete?.Invoke();
            return;
        }

        Renderer[] renderers = GetRenderers(currentWeapons);

        reveal.PlayHide(renderers, currentColor, () =>
        {
            // 🔥 Hide 끝 → 루트 OFF (Mesh + VFX 같이 OFF)
            foreach (var w in currentWeapons)
                if (w) w.SetActive(false);

            onComplete?.Invoke();
        });
    }

    public void RevealWeapons(PlayerAbsorbEffect.ColorType newColor)
    {
        WeaponRevealController reveal = GetComponent<WeaponRevealController>();

        left.TryGetValue(newColor, out var l);
        right.TryGetValue(newColor, out var r);

        currentWeapons = new[] { l, r };
        currentColor = newColor;

        foreach (var w in currentWeapons)
            if (w) w.SetActive(true); // 🔥 Mesh + VFX 같이 ON

        if (reveal)
            reveal.PlayReveal(GetRenderers(currentWeapons), newColor);
    }

    public GameObject[] GetWeaponsByType(PlayerAbsorbEffect.ColorType type)
    {
        left.TryGetValue(type, out var l);
        right.TryGetValue(type, out var r);
        return new[] { l, r };
    }

    // 🔥 _Progress 있는 Renderer만 수집
    private Renderer[] GetRenderers(GameObject[] weapons)
    {
        List<Renderer> list = new();

        foreach (var w in weapons)
        {
            if (!w) continue;

            foreach (var r in w.GetComponentsInChildren<Renderer>(true))
            {
                if (r.sharedMaterial &&
                    r.sharedMaterial.HasProperty("_Progress"))
                {
                    list.Add(r);
                }
            }
        }

        return list.ToArray();
    }

    private void DisableAll()
    {
        foreach (var g in left.Values) if (g) g.SetActive(false);
        foreach (var g in right.Values) if (g) g.SetActive(false);
    }
}