﻿using UnityEngine;
using System.Collections;
using StarterAssets;
using Cinemachine;
using System.Collections.Generic;
using UnityEngine.VFX;

public class PlayerAbsorbEffect : MonoBehaviour, IAttributeApplier
{ 
    [Header("References")]
    public ThirdPersonController player;
    [Header("Weapon Controller")]
    public PlayerWeaponController weaponController;

    public static PlayerAbsorbEffect Instance { get; private set; }

    [Header("UI")]
    [SerializeField] private AbsorbCircleFill absorbCircleUI;
    public AbsorbCircleFill CircleUI => absorbCircleUI;

    public Animator animator;
    public Transform rightHand;
    public SkinnedMeshRenderer surface;
    public SkinnedMeshRenderer joints;

    [Header("Player VFX (Color Change Target)")]
    public ParticleSystem playerVFX;   // ★ 추가됨

    [Header("Player VFXGraph")]
    public VisualEffect playerVFXGraph;

    public enum ColorType
    {
        None,   // ★ 추가
        Red,
        Green,
        Blue,
        Purple
    }

    [Header("Attribute Materials")]
    public ColorType colorType { get; private set; } = ColorType.None;

    public event System.Action OnAbsorbReady;

    public bool IsInitialized { get; private set; }

    public Material[] bodyMats;
    public Material[] jointMats;

    
    [Header("Spawn Effect")]
    public GameObject spawnEffectPrefab;   // ★ 프리팹
    public Transform spawnEffectAnchor;     // 보통 플레이어 중심 or 발밑

    // ===============================
    // SpawnEffect Color Preset
    // ===============================
    private struct SpawnVFXColorPreset
    {
        public Color cylinder;
        public Color ring;
        public Color particle;
    }

    private Dictionary<ColorType, SpawnVFXColorPreset> spawnVFXPresets;

    [Header("Cinemachine")]
    public CinemachineVirtualCamera playerFollowCamera;
    public CinemachineVirtualCamera frontCamera;

    [Header("Weapon Objects")]
    public GameObject leftSword;
    public GameObject rightSword;

    public GameObject leftStaff;
    public GameObject rightShield;

    private float theBestPosY = 1.1f;
    private float theBestPosXZ = 1.3f;
    private float theBestLookAtOffset = 0.65f;

    private GameObject absorbObj;
    private ColorType absorbColor;

    private bool absorbRunning = false;
    public bool IsAbsorbing => absorbRunning;
    private bool absorbAnimationFinished = false;

    private float clipLength;

    public bool hasAbsorbedOnce = false;

    // 레이어 캐싱 변수 추가
    [Header("Invincible Layer")]
    [SerializeField] private string invincibleLayerName = "PlayerInvincible";

    private int defaultLayer;
    private int invincibleLayer;

    private void Awake()
    {
        Instance = this;

        defaultLayer = gameObject.layer;
        invincibleLayer = LayerMask.NameToLayer(invincibleLayerName);

        if (invincibleLayer < 0)
        {
            Debug.LogError($"[Absorb] Layer '{invincibleLayerName}' not found!");
        }

        spawnVFXPresets = new Dictionary<ColorType, SpawnVFXColorPreset>();

        spawnVFXPresets[ColorType.Red] = new SpawnVFXColorPreset
        {
            cylinder = Color.HSVToRGB(0f / 360f, 0.94f, 0.75f) * 7.31f,
            ring = Color.HSVToRGB(6f / 360f, 0.84f, 0.75f) * 3.62f,
            particle = Color.HSVToRGB(6f / 360f, 0.55f, 0.93f)
        };

        spawnVFXPresets[ColorType.Green] = new SpawnVFXColorPreset
        {
            cylinder = Color.HSVToRGB(115f / 360f, 0.90f, 0.75f) * 7.31f,
            ring = Color.HSVToRGB(105f / 360f, 0.84f, 0.75f) * 3.62f,
            particle = Color.HSVToRGB(117f / 360f, 0.79f, 0.88f)
        };

        spawnVFXPresets[ColorType.Blue] = new SpawnVFXColorPreset
        {
            cylinder = Color.HSVToRGB(227f / 360f, 0.90f, 0.75f) * 7.31f,
            ring = Color.HSVToRGB(221f / 360f, 0.84f, 0.75f) * 3.62f,
            particle = Color.HSVToRGB(173f / 360f, 0.55f, 0.93f)
        };

        spawnVFXPresets[ColorType.Purple] = new SpawnVFXColorPreset
        {
            cylinder = Color.HSVToRGB(254f / 360f, 0.94f, 0.75f) * 7.31f,
            ring = Color.HSVToRGB(265f / 360f, 0.84f, 0.75f) * 3.62f,
            particle = Color.HSVToRGB(281f / 360f, 0.82f, 0.80f)
        };
    }

    private void Start()
    {
        AnimationClip[] clips = animator.runtimeAnimatorController.animationClips;
        foreach (var clip in clips)
        {
            if (clip.name == "AttributeChange")
            {
                clipLength = clip.length;
                break;
            }
        }

        surface.material.EnableKeyword("_EMISSION");
        joints.material.EnableKeyword("_EMISSION");
    }

    private void OnDisable()
    {
        SetInvincibleLayer(false);
    }

    public void Init(ColorType color)
    {
        colorType = color;

        if (IsInitialized)   // 이미 초기화된 상태면 이벤트 재발화 방지
            return;

        IsInitialized = true;
        OnAbsorbReady?.Invoke();
    }

    public bool HasElement()
    {
        return colorType != ColorType.None;
    }

    private void SetInvincibleLayer(bool enable)
    {
        int target = enable ? invincibleLayer : defaultLayer;

        if (gameObject.layer == target)
            return; // 🔒 멱등성 보장

        gameObject.layer = target;
    }

    // =========================================================
    // 외부 호출
    // =========================================================
    public void StartAbsorb(GameObject itemObj)
    {
        Debug.Log($"[Absorb] Start Absorb: {absorbColor}");

        if (absorbRunning) return;

        AbsorbItem absorbItem = itemObj.GetComponent<AbsorbItem>();
        if (!absorbItem)
        {
            Debug.LogError($"[Absorb] AbsorbItem missing on {itemObj.name}");
            return;
        }

        absorbColor = absorbItem.colorType;
        absorbObj = itemObj;

        StartCoroutine(AbsorbSequence());
    }

    // =========================================================
    // ABSORB MAIN SEQUENCE
    // =========================================================
    private IEnumerator AbsorbSequence()
    {
        absorbRunning = true;

        // 🔒 Circle UI 차단
        if (absorbCircleUI != null)
            absorbCircleUI.ForceHide();

        // 무적 레이어로 변경
        SetInvincibleLayer(true);

        player.DisableAllInputs();
        animator.CrossFade("Idle", 0.05f);
        animator.Update(0);

        yield return StartCoroutine(SmoothCameraTransition());

        // ===============================
        // 1️⃣ 흡수 연출 (아이템이 주인공)
        // ===============================
        yield return StartCoroutine(AbsorbObjectFloat(absorbObj));
        yield return StartCoroutine(MoveToFinger(absorbObj, rightHand));

        // ===============================
        // 2️⃣ 아이템 소멸 (먼저!)
        // ===============================
        Destroy(absorbObj);

        // 👀 흡수 완료 인식 텀
        yield return new WaitForSeconds(0.25f);

        // ===============================
        // 3⃣ 속성 변화 (애니메이션 시작)
        // ===============================
        player.Animator.SetBool("IsAbsorbing", true);

        // 🔥 0.5초 뒤 SpawnEffect 실행
        yield return new WaitForSeconds(0.5f);
        PlaySpawnEffect(absorbColor);

        // 🔥 Player VFXGraph Burst
        PlayPlayerVFXBurst();

        // 🔊 AttributeChange 사운드 시작
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayAttributeChange();

        // ===============================
        // 4⃣ 이전 무기 Hide
        // ===============================
        bool weaponHidden = false;
        weaponController.HideCurrentWeapons(() => weaponHidden = true);
        yield return new WaitUntil(() => weaponHidden);

        yield return new WaitForSeconds(0.25f);

        // ===============================
        // 4️⃣ 플레이어 색상 변경
        // ===============================
        yield return StartCoroutine(ChangePlayerColor(absorbColor));

        // ✅ 첫 흡수 → 시스템 Ready 처리
        if (!IsInitialized)
        {
            Init(absorbColor);   // IsInitialized=true, OnAbsorbReady 발화
        }

        yield return new WaitForSeconds(0.35f);

        // 🔥 첫 흡수 처리
        if (!hasAbsorbedOnce)
        {
            hasAbsorbedOnce = true;
            ClearAllAbsorbItems();
        }

        // ===============================
        // 5️⃣ 새 무기 Reveal
        // ===============================
        Debug.Log($"[Absorb] Reveal Weapon Color: {colorType}");
        weaponController.RevealWeapons(colorType);

        // ===============================
        // 마무리
        // ===============================
        yield return new WaitForSeconds(clipLength);

        // 🔊 AttributeChange 사운드 종료
        if (AudioManager.Instance != null)
            AudioManager.Instance.StopAttributeChange();

        frontCamera.Priority = 0;
        playerFollowCamera.Priority = 10;

        yield return new WaitForSeconds(0.5f);

        player.Animator.SetBool("IsAbsorbing", false);
        absorbRunning = false;

        // 흡수 종료 시 원복
        SetInvincibleLayer(false);

        player.EnableAllInputs();
        player.SetBusy(false);
    }

    private void PlaySpawnEffect(ColorType type)
    {
        if (spawnEffectPrefab == null) return;
        if (!spawnVFXPresets.ContainsKey(type)) return;

        SpawnVFXColorPreset preset = spawnVFXPresets[type];

        GameObject fxRoot =
            Instantiate(
                spawnEffectPrefab,
                spawnEffectAnchor != null ? spawnEffectAnchor.position : transform.position,
                Quaternion.identity
            );

        // ===============================
        // Visual Effect
        // ===============================
        VisualEffect vfx = fxRoot.GetComponentInChildren<VisualEffect>();
        if (vfx != null)
        {
            vfx.SetVector4("CylinderColor", preset.cylinder);
            vfx.SetVector4("RingColor", preset.ring);
            vfx.Play();
        }

        // ===============================
        // Particle System (1.5초 뒤)
        // ===============================
        ParticleSystem ps = fxRoot.GetComponentInChildren<ParticleSystem>();
        if (ps != null)
        {
            var main = ps.main;
            main.startColor = preset.particle;

            StartCoroutine(PlayParticleDelayed(ps, 1.5f));
        }

        // 전체 정리
        Destroy(fxRoot, 3f);
    }

    private IEnumerator PlayParticleDelayed(ParticleSystem ps, float delay)
    {
        yield return new WaitForSeconds(delay);
        ps.Play();
    }

    private void ClearAllAbsorbItems()
    {
        GameObject[] absorbs = GameObject.FindGameObjectsWithTag("AbsorbItem");
        foreach (var obj in absorbs)
        {
            Destroy(obj);
        }
    }

    // =========================================================
    // Camera Transition
    // =========================================================
    private IEnumerator SmoothCameraTransition()
    {
        playerFollowCamera.Priority = 0;
        frontCamera.Priority = 20;

        frontCamera.Follow = player.transform;

        Vector3 adjusted = player.transform.position +
                           Vector3.up * theBestPosY +
                           player.transform.forward * theBestPosXZ;

        frontCamera.transform.position = adjusted;
        frontCamera.transform.LookAt(player.transform.position + Vector3.up * theBestLookAtOffset);

        yield return new WaitForSeconds(0.6f);
    }

    public void OnAbsorbEnd() => absorbAnimationFinished = true;

    // "에너지에 끌려가며 불안정하게 흔들리는 흡수 형태"
    private IEnumerator AbsorbObjectFloat(GameObject obj)
    {
        float duration = 5f;
        float timer = 0f;

        Vector3 baseForwardPos =
            player.transform.position +
            player.transform.forward * theBestPosXZ * 0.5f +
            Vector3.up * 0.85f;

        // ===============================
        // 🎲 3개의 랜덤 시작 오프셋
        // ===============================
        Vector3[] startOffsets =
        {
        player.transform.right * -0.6f,   // 왼쪽
        player.transform.right *  0.6f,   // 오른쪽
        Vector3.up * 0.5f                 // 위
    };

        Vector3 randomStartOffset =
            startOffsets[Random.Range(0, startOffsets.Length)];

        Vector3 startPos = baseForwardPos + randomStartOffset;
        obj.transform.position = startPos;

        // ===============================
        // 🎲 흔들림 위상 랜덤화
        // ===============================
        float sidePhase = Random.Range(0f, Mathf.PI * 2f);
        float forwardPhase = Random.Range(0f, Mathf.PI * 2f);

        while (timer < duration)
        {
            float t = timer / duration;

            // ===============================
            // 🌊 흔들림 강화
            // ===============================
            float sideways =
                Mathf.Sin(Time.time * 3.2f + sidePhase) * 0.45f;

            float forwardWave =
                Mathf.Cos(Time.time * 2.6f + forwardPhase) * 0.25f;

            float verticalWave =
                Mathf.Sin(Time.time * 2.1f + sidePhase) * 0.15f;

            Vector3 wobbleOffset =
                player.transform.right * sideways +
                player.transform.forward * forwardWave +
                Vector3.up * verticalWave;

            Vector3 targetPos = baseForwardPos + wobbleOffset;

            obj.transform.position = Vector3.Lerp(
                obj.transform.position,
                targetPos,
                Time.deltaTime * 3.5f);

            timer += Time.deltaTime;
            yield return null;
        }
    }

    private IEnumerator MoveToFinger(GameObject obj, Transform finger)
    {
        float duration = 1.5f;
        float timer = 0f;

        Vector3 start = obj.transform.position;

        while (timer < duration)
        {
            float t = timer / duration;
            t = 1f - Mathf.Pow(1f - t, 3f);

            obj.transform.position = Vector3.Lerp(start, finger.position, t);

            timer += Time.deltaTime;
            yield return null;
        }

        obj.transform.position = finger.position;

            // 🔊 손가락 도달 사운드
        if (AudioManager.Instance != null)
        {
            AudioManager.Instance.PlayGetItem();
        }
    }

    // =========================================================
    // 색상 변화 + Player_VFX 색상 연동 (★ 이 부분이 핵심)
    // =========================================================
    private IEnumerator ChangePlayerColor(ColorType type)
    {
        Material targetBody;
        Material targetJoint;
        Color vfxColor;

        colorType = type;

        switch (type)
        {
            case ColorType.Red:
                targetBody = bodyMats[(int)ColorType.Red];
                targetJoint = jointMats[(int)ColorType.Red];
                vfxColor = new Color32(255, 45, 72, 255);
                break;

            case ColorType.Green:
                targetBody = bodyMats[(int)ColorType.Green];
                targetJoint = jointMats[(int)ColorType.Green];
                vfxColor = new Color32(109, 219, 91, 255);
                break;

            case ColorType.Blue:
                targetBody = bodyMats[(int)ColorType.Blue];
                targetJoint = jointMats[(int)ColorType.Blue];
                vfxColor = new Color32(0, 121, 255, 255);
                break;

            case ColorType.Purple:
                targetBody = bodyMats[(int)ColorType.Purple];
                targetJoint = jointMats[(int)ColorType.Purple];
                vfxColor = new Color32(208, 47, 217, 255);
                break;

            default:
                targetBody = bodyMats[(int)ColorType.None];
                targetJoint = jointMats[(int)ColorType.None];
                vfxColor = Color.gray;
                break;
        }

        surface.material = targetBody;
        joints.material = targetJoint;

        ApplyPlayerVFXColor(type);

        yield return null;
    }

    // 속성 변환 전용 함수
    public void ApplyAttribute(ColorType type)
    {
        colorType = type;

        surface.material = bodyMats[(int)type];
        joints.material = jointMats[(int)type];

        //ApplyWeaponByColor(type); // ❌ 이제 필요 없음 (아래 설명)

        ApplyPlayerVFXColor(type);
    }

    public Color GetVFXColor(ColorType type)
    {
        switch (type)
        {
            case ColorType.Blue:
                return new Color32(0, 121, 255, 255);

            case ColorType.Red:
                return new Color32(255, 45, 72, 255);

            case ColorType.Green:
                return new Color32(109, 219, 91, 255);

            case ColorType.Purple:
                return new Color32(208, 47, 217, 255);

            default:
                return Color.white;
        }
    }

    private void ApplyPlayerVFXColor(ColorType type)
    {
        Color color = GetVFXColor(type);

        // =========================
        // Particle System
        // =========================
        if (playerVFX != null)
        {
            var main = playerVFX.main;
            main.startColor = color;
        }

        // =========================
        // VFX Graph
        // =========================
        if (playerVFXGraph != null)
        {
            playerVFXGraph.SetVector4("Color", color);
        }
    }

    public Color GetCurrentAbsorbUIColor()
    {
        return GetVFXColor(colorType);
    }

    private void PlayPlayerVFXBurst()
    {
        if (playerVFXGraph == null)
            return;

        playerVFXGraph.SetVector4("Color", GetVFXColor(colorType));

        playerVFXGraph.Reinit();
        playerVFXGraph.SendEvent("OnPlay");
    }
}