﻿using StarterAssets;
using UnityEngine;
using System.Collections;
using static DamageText;

public class PlayerStatus : MonoBehaviour
{
    public static PlayerStatus Instance { get; private set; }

    public DissolvingController dissolveController;

    // 현재값
    public float currentHP;
    public float currentMP;

    // ===== DEFAULT CONSTANTS =====
    private const float DEFAULT_MAX_HP = 120f;
    private const float DEFAULT_MAX_MP = 100f;

    private const float DEFAULT_PHYSICAL_ATK = 20f;
    private const float DEFAULT_MAGIC_ATK = 12f;

    private const float DEFAULT_PHYSICAL_DEF = 4f;
    private const float DEFAULT_MAGIC_DEF = 3f;

    private const float DEFAULT_PHYSICAL_CRIT = 0.05f;
    private const float DEFAULT_MAGIC_CRIT = 0.05f;

    private const float DEFAULT_SKILL_DMG = 1f;

    // =========================
    // BASE STATS (절대 기준)
    // =========================
    [Header("Base Stats")]
    public float baseMaxHP;
    public float baseMaxMP;

    public float basePhysicalATK;
    public float baseMagicATK;

    public float basePhysicalDEF;
    public float baseMagicDEF;

    public float basePhysicalCritChance;
    public float baseMagicCritChance;

    public float baseSkillDMG;

    // =========================
    // BONUS STATS (증강용)
    // =========================
    [HideInInspector] public float bonusMaxHP;
    [HideInInspector] public float bonusMaxMP;

    [HideInInspector] public float bonusPhysicalATK;
    [HideInInspector] public float bonusMagicATK;

    [HideInInspector] public float bonusPhysicalDEF;
    [HideInInspector] public float bonusMagicDEF;

    [HideInInspector] public float bonusPhysicalCritChance;
    [HideInInspector] public float bonusMagicCritChance;

    [HideInInspector] public float bonusSkillDMG;
    [HideInInspector] public float skillDMGMultiplier = 1f;

    // =========================
    // FINAL VALUES (항상 여기서 계산)
    // =========================
    public float MaxHP => baseMaxHP + bonusMaxHP;
    public float MaxMP => baseMaxMP + bonusMaxMP;

    public float PhysicalATK => basePhysicalATK + bonusPhysicalATK;
    public float MagicATK => baseMagicATK + bonusMagicATK;

    public float PhysicalDEF => basePhysicalDEF + bonusPhysicalDEF;
    public float MagicDEF => baseMagicDEF + bonusMagicDEF;

    public float PhysicalCritChance => basePhysicalCritChance + bonusPhysicalCritChance;
    public float MagicCritChance => baseMagicCritChance + bonusMagicCritChance;

    public float SkillDMG => (baseSkillDMG + bonusSkillDMG) * skillDMGMultiplier;

    [Header("Regen (per second)")]
    public float hpRegenPerSecond = 1f;   // 🔥 HP 초당 1
    public float mpRegenPerSecond = 2f;   // 🔥 MP 초당 2
    private Coroutine mpHoldUIRoutine;

    public bool isDead = false;

    public float contactInvincibleTime = 0.5f;
    private bool isInvincible = false;

    // =========================
    // Poison (독) 상태
    // =========================
    private Coroutine poisonRoutine;
    private bool isPoisoned = false;

    private void Start()
    {
        PushHPMPToUI();

        ThirdPersonController controller = GetComponent<ThirdPersonController>();
        PlayerAugmentManager augment = GetComponent<PlayerAugmentManager>();

        if (UI_PlayerStatus.Instance != null)
        {
            UI_PlayerStatus.Instance.Bind(this, controller, augment);
        }
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        // ===== BASE 초기화 =====
        baseMaxHP = DEFAULT_MAX_HP;
        baseMaxMP = DEFAULT_MAX_MP;

        basePhysicalATK = DEFAULT_PHYSICAL_ATK;
        baseMagicATK = DEFAULT_MAGIC_ATK;

        basePhysicalDEF = DEFAULT_PHYSICAL_DEF;
        baseMagicDEF = DEFAULT_MAGIC_DEF;

        basePhysicalCritChance = DEFAULT_PHYSICAL_CRIT;
        baseMagicCritChance = DEFAULT_MAGIC_CRIT;

        baseSkillDMG = DEFAULT_SKILL_DMG;

        // ===== CURRENT 초기화 =====
        currentHP = MaxHP;
        currentMP = MaxMP;
    }

    private void Update()
    {
        Regenerate();
    }

    private void Regenerate()
    {
        if (currentHP < MaxHP)
        {
            currentHP += hpRegenPerSecond * Time.deltaTime;
            if (currentHP > MaxHP) currentHP = MaxHP;
        }

        if (currentMP < MaxMP)
        {
            currentMP += mpRegenPerSecond * Time.deltaTime;
            if (currentMP > MaxMP) currentMP = MaxMP;
        }

        // 🔥 UI는 캐시만 갱신
        PushHPMPToUI();
    }

    // =========================
    // HP
    // =========================
    public void HealHP(float amount)
    {
        if (amount <= 0f) return;

        currentHP = Mathf.Min(currentHP + amount, MaxHP);
        PushHPMPToUI();
    }

    // =========================
    // MP
    // =========================
    public void HealMP(float amount)
    {
        if (amount <= 0f) return;

        currentMP = Mathf.Min(currentMP + amount, MaxMP);
        PushHPMPToUI();
    }

    public void TakeDamage(float physicalDamage, float magicDamage, bool isCritical = false)
    {
        if (isDead || isInvincible) return;
        if (currentHP <= 0) return;

        float finalPhysical = Mathf.Max(physicalDamage - PhysicalDEF, 1f);
        float finalMagic = Mathf.Max(magicDamage - MagicDEF, 1f);

        float finalDamage = finalPhysical + finalMagic;
        currentHP -= finalDamage;

        // ✅ 캐시 갱신
        PushHPMPToUI();

        // 🔥 HP 즉시 UI 갱신 (피격 체감)
        if (UI_PlayerStatus.Instance != null)
            UI_PlayerStatus.Instance.ForceRefreshHP();

        // 데미지 텍스트
        DamageTextManager.Instance.ShowDamage(
            transform,
            Mathf.RoundToInt(finalDamage),
            DamageText.DamageType.Physical,
            true   // 🔥 isDamageTaken = true
        );

        if (currentHP <= 0)
            Die();
    }

    public void TakeContactDamage(float damage)
    {
        if (isDead || isInvincible) return;

        TakeDamage(damage, 0f, false); // 기존 함수 재사용
        StartCoroutine(ContactInvincibleRoutine());
    }

    private IEnumerator ContactInvincibleRoutine()
    {
        isInvincible = true;
        gameObject.tag = "PlayerDamaged";

        yield return new WaitForSeconds(contactInvincibleTime);

        gameObject.tag = "Player";
        isInvincible = false;
    }

    private void Die()
    {
        if (isDead) return;
        isDead = true;

        StageLogPanel.Log("<color=red>플레이어 사망!</color>");

        // 입력 차단
        ThirdPersonController controller = GetComponent<ThirdPersonController>();
        if (controller != null)
        {
            controller.DisableAllInputs();
            controller.SetBusy(true);
        }

        // 🔥 사망 연출 시작
        if (dissolveController != null)
        {
            dissolveController.BeginDie();
        }

        StartCoroutine(DieSequence());
    }

    private IEnumerator DieSequence()
    {
        // ⏱ 디졸브 연출 시간 + 3초만큼 대기
        yield return new WaitForSeconds(8f);

        StageManager.Instance.FinishStage(false);
    }

    // =========================
    // MP
    // =========================
    public bool HasEnoughMana(float cost)
    {
        return currentMP >= cost;
    }

    public bool ConsumeMana(float cost)
    {
        if (cost <= 0f) return true;
        if (!HasEnoughMana(cost)) return false;

        currentMP -= cost;
        PushHPMPToUI();
        return true;
    }

    public void RestoreMana(float amount)
    {
        if (amount <= 0f) return;

        currentMP = Mathf.Min(currentMP + amount, MaxMP);
        PushHPMPToUI();
    }

    // =========================
    // UI
    // =========================
    private void PushHPMPToUI()
    {
        if (UI_PlayerStatus.Instance == null) return;

        UI_PlayerStatus.Instance.SetHP(currentHP, MaxHP);
        UI_PlayerStatus.Instance.SetMP(currentMP, MaxMP);
    }

    public void StartMPHoldUIRefresh()
    {
        if (mpHoldUIRoutine != null)
            StopCoroutine(mpHoldUIRoutine);

        mpHoldUIRoutine = StartCoroutine(MPHoldUIRoutine());
    }

    public void StopMPHoldUIRefresh()
    {
        if (mpHoldUIRoutine != null)
        {
            StopCoroutine(mpHoldUIRoutine);
            mpHoldUIRoutine = null;
        }
    }

    private IEnumerator MPHoldUIRoutine()
    {
        WaitForSeconds wait = new WaitForSeconds(0.25f);

        while (true)
        {
            if (UI_PlayerStatus.Instance != null)
                UI_PlayerStatus.Instance.ForceRefreshMP();

            yield return wait;
        }
    }

    // 스탯이 확정적으로 바뀔 때 호출하는 함수
    public void NotifyStatChanged()
    {
        if (UI_PlayerStatus.Instance == null)
        {
            StageLogPanel.Log("[STAT] UI_PlayerStatus.Instance NULL", LogType.Warning);
            return;
        }
            
        UI_PlayerStatus.Instance.ForceRefreshAndSnapshot();

        StageLogPanel.Log("[STAT] NotifyStatChanged → UI Bind refresh");
    }

    public void SetInvincible(float duration)
    {
        StartCoroutine(InvincibleRoutine(duration));
    }

    private IEnumerator InvincibleRoutine(float duration)
    {
        isInvincible = true;
        yield return new WaitForSeconds(duration);
        isInvincible = false;
    }
}
