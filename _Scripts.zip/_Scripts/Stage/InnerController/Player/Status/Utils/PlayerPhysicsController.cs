using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerPhysicsController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 4f;
    public float rotationSpeed = 10f;
    public float gravity = -9.81f;
    public float jumpHeight = 1.5f;
    public Transform cameraTransform;

    private CharacterController controller;
    private Vector3 velocity;
    private bool isGrounded;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
    }

    public void Move(Vector3 inputDir)
    {
        // ���� ����
        isGrounded = controller.isGrounded;
        if (isGrounded && velocity.y < 0)
            velocity.y = -2f; // ���� �����

        // ī�޶� ���� �̵� ���� ���
        Vector3 camForward = cameraTransform.forward;
        Vector3 camRight = cameraTransform.right;
        camForward.y = 0;
        camRight.y = 0;

        Vector3 moveDir = camForward * inputDir.z + camRight * inputDir.x;
        if (moveDir.magnitude > 1f)
            moveDir.Normalize();

        // ���� �̵�
        controller.Move(moveDir * moveSpeed * Time.deltaTime);

        // ĳ���� ȸ��
        if (moveDir.sqrMagnitude > 0.01f)
        {
            Quaternion targetRot = Quaternion.LookRotation(moveDir);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, rotationSpeed * Time.deltaTime);
        }

        // �߷� ����
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }

    public void TryJump()
    {
        if (!isGrounded) return;

        // ���� �ӵ� ��� (v = sqrt(2gh))
        velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        isGrounded = false;
    }
}