﻿/* DON'T USED
using UnityEngine;

namespace StarterAssets
{
    public class PlayerOutlineController : MonoBehaviour
    {
        [Header("References")]
        public ThirdPersonController controller;
        public PlayerAbsorbEffect absorbEffect;   // ★ Absorb 색상 정보를 가져오기 위해 필요함

        [Header("Mesh Renderers (2개)")]
        public SkinnedMeshRenderer jointsRenderer;
        public SkinnedMeshRenderer surfaceRenderer;

        [Header("Outline Materials (Emission 포함)")]
        public Material jointsOutlineMat;
        public Material surfaceOutlineMat;

        [Header("Outline Settings")]
        public float pulseSpeed = 4f;

        private bool isOutlined = false;
        private float outlineEndDelay = 0.15f;
        private float outlineTimer = 0f;

        private void Start()
        {
            jointsOutlineMat.EnableKeyword("_EMISSION");
            surfaceOutlineMat.EnableKeyword("_EMISSION");
        }

        private void Update()
        {
            if (controller == null) return;

            bool need = IsActionState(controller);

            if (need)
            {
                EnableOutline();
                outlineTimer = 0f;

                // Emission Pulse
                float pulse = Mathf.PingPong(Time.time * pulseSpeed, 1f);

                Color baseGlow = new Color(1f, 0.95f, 0.85f) * 0.6f;
                Color strongGlow = new Color(1f, 1f, 1f) * 0.6f; // 기존 2.2f 너무 강함
                Color glowColor = Color.Lerp(baseGlow, strongGlow, pulse);

                jointsRenderer.material.SetColor("_EmissionColor", glowColor);
                surfaceRenderer.material.SetColor("_EmissionColor", glowColor);
            }
            else
            {
                outlineTimer += Time.deltaTime;
                if (outlineTimer >= outlineEndDelay)
                    DisableOutline();
            }
        }

        private bool IsActionState(ThirdPersonController ctrl)
        {
            var animStateInfo = ctrl.Animator.GetCurrentAnimatorStateInfo(0);

            bool attacking = animStateInfo.IsName("AttackL") || animStateInfo.IsName("AttackR");
            bool gettingItem = animStateInfo.IsName("GetItem");
            bool climbing = animStateInfo.IsName("Climb");
            bool dodging = animStateInfo.IsName("Left Dodge") || animStateInfo.IsName("Right Dodge");
            bool absorbing = ctrl.Animator.GetBool("IsAbsorbing");

            return attacking || gettingItem || climbing || dodging || absorbing;
        }

        private void EnableOutline()
        {
            if (isOutlined) return;

            // ★ 현재 Absorb 색상을 가져와 outline material에 반영
            if (absorbEffect != null)
            {
                jointsOutlineMat.color = absorbEffect.GetSavedJointsColor();
                surfaceOutlineMat.color = absorbEffect.GetSavedSurfaceColor();
            }

            jointsRenderer.material = jointsOutlineMat;
            surfaceRenderer.material = surfaceOutlineMat;

            isOutlined = true;
        }

        private void DisableOutline()
        {
            if (!isOutlined) return;

            // ★ Normal일 때도 Absorb된 최종 색상을 유지해야 함
            if (absorbEffect != null)
            {
                jointsRenderer.material.color = absorbEffect.GetSavedJointsColor();
                surfaceRenderer.material.color = absorbEffect.GetSavedSurfaceColor();
            }

            isOutlined = false;
        }
    }
}
*/