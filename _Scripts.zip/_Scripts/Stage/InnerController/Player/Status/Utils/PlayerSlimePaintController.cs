using UnityEngine;
using System.Collections;

public class PlayerSlimePaintController : MonoBehaviour
{
    [Header("Paint Objects")]
    public GameObject leftFootPaint;
    public GameObject rightFootPaint;

    [Header("Bleed")]
    public float bleedDamagePerSecond = 1f;
    public float bleedDuration = 5f;

    private PlayerStatus player;
    private Coroutine bleedRoutine;

    private void Awake()
    {
        player = GetComponent<PlayerStatus>();
    }

    // =========================
    // Slime Hit Entry
    // =========================
    public void ApplySlime()
    {
        if (!leftFootPaint.activeSelf)
        {
            leftFootPaint.SetActive(true);
        }
        else if (!rightFootPaint.activeSelf)
        {
            rightFootPaint.SetActive(true);
        }

        CheckBleed();
        StartCoroutine(ClearSlimeAfterTime());
    }

    // =========================
    private void CheckBleed()
    {
        if (leftFootPaint.activeSelf && rightFootPaint.activeSelf)
        {
            if (bleedRoutine == null)
                bleedRoutine = StartCoroutine(BleedRoutine());
        }
    }

    private IEnumerator BleedRoutine()
    {
        float elapsed = 0f;

        while (elapsed < bleedDuration)
        {
            if (player == null || player.isDead)
                yield break;

            player.TakeDamage(
                physicalDamage: bleedDamagePerSecond,
                magicDamage: 0f,
                isCritical: false
            );

            yield return new WaitForSeconds(1f);
            elapsed += 1f;
        }

        bleedRoutine = null;
    }

    private IEnumerator ClearSlimeAfterTime()
    {
        yield return new WaitForSeconds(bleedDuration);

        leftFootPaint.SetActive(false);
        rightFootPaint.SetActive(false);
    }
}
