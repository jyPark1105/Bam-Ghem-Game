using UnityEngine;

public class PlayerHitAttachHelper : MonoBehaviour
{
    [Header("Core")]
    public Transform spine;
    public Transform chest;

    [Header("Arms")]
    public Transform upperArmL;
    public Transform upperArmR;

    [Header("Sides")]
    public Transform sideL;
    public Transform sideR;

    [Header("Legs")]
    public Transform thighL;
    public Transform thighR;

    [Header("Feet")]
    public Transform footL;
    public Transform footR;

    private Transform[] bones;

    private void Awake()
    {
        bones = new Transform[]
        {
            spine, chest,
            upperArmL, upperArmR,
            sideL, sideR,
            thighL, thighR,
            footL, footR
        };
    }

    public Transform GetBone(string boneName)
    {
        foreach (Transform t in GetComponentsInChildren<Transform>())
        {
            if (t.name.Contains(boneName))
                return t;
        }
        return null;
    }

    public Transform GetClosestBone(Vector3 hitPoint)
    {
        Transform closest = null;
        float minDist = float.MaxValue;

        foreach (var b in bones)
        {
            if (b == null) continue;

            float d = Vector3.Distance(b.position, hitPoint);
            if (d < minDist)
            {
                minDist = d;
                closest = b;
            }
        }

        return closest != null ? closest : transform;
    }
}