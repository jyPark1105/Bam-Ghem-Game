using UnityEngine;

public class PlayerTurtleShellDebuffController : MonoBehaviour
{
    [Header("Stack Settings")]
    public int maxStack = 3;
    public int currentStack = 0;

    [Header("Debuff Amount")]
    public float physicalDefDownPerStack = 3f;
    public float magicDefDownPerStack = 3f;

    private PlayerStatus player;

    private void Awake()
    {
        player = GetComponent<PlayerStatus>();
    }

    // =========================
    // Shell Attached
    // =========================
    public void OnShellAttached()
    {
        if (currentStack >= maxStack)
            return;

        currentStack++;

        ApplyDebuff();
    }

    // =========================
    // Shell Detached
    // =========================
    public void OnShellDetached()
    {
        if (currentStack <= 0)
            return;

        currentStack--;

        RemoveDebuff();
    }

    // =========================
    private void ApplyDebuff()
    {
        player.bonusPhysicalDEF -= physicalDefDownPerStack;
        player.bonusMagicDEF -= magicDefDownPerStack;

        Debug.Log($"?? Shell Stack +1 �� {currentStack}");
    }

    private void RemoveDebuff()
    {
        player.bonusPhysicalDEF += physicalDefDownPerStack;
        player.bonusMagicDEF += magicDefDownPerStack;

        Debug.Log($"?? Shell Stack -1 �� {currentStack}");
    }
}