﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using StarterAssets;
using System.Collections.Generic;
using System;

public class UI_PlayerStatus : MonoBehaviour
{
    public static UI_PlayerStatus Instance;

    [Header("HP")]
    public Image hpFillImage;
    public TMP_Text currentHPText;
    public TMP_Text fullHPText;

    [Header("MP")]
    public Image mpFillImage;
    public TMP_Text currentMPText;
    public TMP_Text fullMPText;

    // =============================
    // HP / MP Cache
    // =============================
    private float cachedHP;
    private float cachedMaxHP;
    private float cachedMP;
    private float cachedMaxMP;

    [Header("Low HP Warning")]
    public Image lowHPWarningBG;
    public float lowHPPercent = 0.3f;
    public float blinkSpeed = 2f;

    [Header("Base Panel")]
    public TMP_Text physicalATKText_Base;
    public TMP_Text magicATKText_Base;
    public TMP_Text physicalCritText_Base;
    public TMP_Text magicCritText_Base;
    public TMP_Text physicalDEFText_Base;
    public TMP_Text magicDEFText_Base;
    public TMP_Text cooldownText_Base;
    public TMP_Text skillDamageText_Base;
    public TMP_Text moveSpeedText_Base;
    public TMP_Text atkSpeedText_Base;

    [Header("Augment Panel")]
    public TMP_Text physicalATKText_Aug;
    public TMP_Text magicATKText_Aug;
    public TMP_Text physicalCritText_Aug;
    public TMP_Text magicCritText_Aug;
    public TMP_Text physicalDEFText_Aug;
    public TMP_Text magicDEFText_Aug;
    public TMP_Text cooldownText_Aug;
    public TMP_Text skillDamageText_Aug;
    public TMP_Text moveSpeedText_Aug;
    public TMP_Text atkSpeedText_Aug;

    [Header("Panel Toggle")]
    public CanvasGroup basePanelGroup;
    public CanvasGroup augmentPanelGroup;

    private bool isBaseMode = true;

    private Coroutine hpWarningRoutine;

    [Header("Auto Refresh")]
    public float refreshInterval = 1f;

    private PlayerStatus player;
    private ThirdPersonController controller;
    private PlayerAugmentManager augment;

    // =============================
    // Cached Values (이전 상태)
    // =============================
    private float lastPhysicalATK = -1f;
    private float lastMagicATK = -1f;
    private float lastMoveSpeed = -1f;
    private float lastSprintSpeed = -1f;
    private float lastSizeMultiplier = -1f;

    // =============================
    // ✅ 범용 스탯 감시 (추가)
    // =============================
    [Serializable]
    public class StatWatch
    {
        public string key;
        public TMP_Text anchorText;           // 팝업 뜰 기준 텍스트
        public Func<float> getter;            // 현재 값 가져오기
        public Action<float> applyText;       // UI 텍스트 반영 (값이 변했을 때만 호출)
        public string deltaFormat = "0";      // 델타 표시 포맷
        public float threshold = 0.01f;       // 변화 감지 임계값
        public bool showDeltaPopup = true;    // 팝업 표시 여부
    }

    private readonly Dictionary<string, float> lastStatValues = new();
    private readonly List<StatWatch> watches = new();

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        if (lowHPWarningBG != null)
            lowHPWarningBG.gameObject.SetActive(false);

        SetPanelMode(true); // 기본은 Base
    }

    public void SetHP(float current, float max)
    {
        cachedHP = current;
        cachedMaxHP = max;
    }

    public void SetMP(float current, float max)
    {
        cachedMP = current;
        cachedMaxMP = max;
    }

    // ✅ 초기화 함수
    public void Bind(PlayerStatus ps, ThirdPersonController ctrl, PlayerAugmentManager am)
    {
        player = ps;
        controller = ctrl;
        augment = am;

        RegisterDefaultWatches();
        ForceRefreshAndSnapshot();

        StopAllCoroutines();
        StartCoroutine(RefreshRoutine());
    }

    // 1초마다 갱신
    private IEnumerator RefreshRoutine()
    {
        WaitForSeconds wait = new WaitForSeconds(refreshInterval);

        while (true)
        {
            RefreshStats();          // 스탯 텍스트
            RefreshHPMPUI();         // 🔥 HP / MP UI
            yield return wait;
        }
    }

    private void RefreshHPMPUI()
    {
        if (cachedMaxHP > 0f)
        {
            float hpRatio = cachedHP / cachedMaxHP;

            hpFillImage.fillAmount = hpRatio;
            currentHPText.text = Mathf.CeilToInt(cachedHP).ToString();
            fullHPText.text = $"/ {Mathf.CeilToInt(cachedMaxHP)}";

            HandleLowHPWarning(hpRatio);
        }

        if (cachedMaxMP > 0f)
        {
            mpFillImage.fillAmount = cachedMP / cachedMaxMP;
            currentMPText.text = Mathf.CeilToInt(cachedMP).ToString();
            fullMPText.text = $"/ {Mathf.CeilToInt(cachedMaxMP)}";
        }
    }

    // ✅ 감시 목록 구성 (여기만 늘리면 스탯 계속 추가 가능)
    private void RegisterDefaultWatches()
    {
        watches.Clear();
        lastStatValues.Clear();

        if (player != null)
        {
            // =========================
            // Physical ATK
            // =========================
            watches.Add(new StatWatch
            {
                key = "PhysicalATK",
                anchorText = physicalATKText_Base,
                getter = () => player.PhysicalATK,
                applyText = v =>
                {
                    if (physicalATKText_Base != null)
                        physicalATKText_Base.text = $"{v:0}";

                    if (physicalATKText_Aug != null)
                        physicalATKText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.PhysicalATK);
                }
            });

            // =========================
            // Magic ATK
            // =========================
            watches.Add(new StatWatch
            {
                key = "MagicATK",
                anchorText = magicATKText_Base,
                getter = () => player.MagicATK,
                applyText = v =>
                {
                    if (magicATKText_Base != null)
                        magicATKText_Base.text = $"{v:0}";

                    if (magicATKText_Aug != null)
                        magicATKText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.MagicATK);
                }
            });

            // =========================
            // Physical Crit
            // =========================
            watches.Add(new StatWatch
            {
                key = "PhysicalCrit",
                anchorText = physicalCritText_Base,
                getter = () => player.PhysicalCritChance,
                deltaFormat = "0%",
                threshold = 0.001f,
                applyText = v =>
                {
                    if (physicalCritText_Base != null)
                        physicalCritText_Base.text = $"{v * 100f:0}%";

                    if (physicalCritText_Aug != null)
                        physicalCritText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.PhysicalCritChance);
                }
            });

            // =========================
            // Magic Crit
            // =========================
            watches.Add(new StatWatch
            {
                key = "MagicCrit",
                anchorText = magicCritText_Base,
                getter = () => player.MagicCritChance,
                deltaFormat = "0%",
                threshold = 0.001f,
                applyText = v =>
                {
                    if (magicCritText_Base != null)
                        magicCritText_Base.text = $"{v * 100f:0}%";

                    if (magicCritText_Aug != null)
                        magicCritText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.MagicCritChance);
                }
            });

            // =========================
            // Physical DEF
            // =========================
            watches.Add(new StatWatch
            {
                key = "PhysicalDEF",
                anchorText = physicalDEFText_Base,
                getter = () => player.PhysicalDEF,
                applyText = v =>
                {
                    if (physicalDEFText_Base != null)
                        physicalDEFText_Base.text = $"{v:0}";

                    if (physicalDEFText_Aug != null)
                        physicalDEFText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.PhysicalDEF);
                }
            });

            // =========================
            // Magic DEF
            // =========================
            watches.Add(new StatWatch
            {
                key = "MagicDEF",
                anchorText = magicDEFText_Base,
                getter = () => player.MagicDEF,
                applyText = v =>
                {
                    if (magicDEFText_Base != null)
                        magicDEFText_Base.text = $"{v:0}";

                    if (magicDEFText_Aug != null)
                        magicDEFText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.MagicDEF);
                }
            });

            //// =========================
            //// Skill Damage
            //// =========================
            //watches.Add(new StatWatch
            //{
            //    key = "SkillDMG",
            //    anchorText = skillDamageText_Base,
            //    getter = () => player.SkillDMG,
            //    deltaFormat = "0.00",
            //    threshold = 0.001f,
            //    applyText = v =>
            //    {
            //        if (skillDamageText_Base != null)
            //            skillDamageText_Base.text = $"{v:0.00}x";

            //        if (skillDamageText_Aug != null)
            //            skillDamageText_Aug.text =
            //                GetAugmentCountSuffix(AugmentStatType.SkillDamage);
            //    }
            //});

            // =========================
            // Max HP
            // =========================
            watches.Add(new StatWatch
            {
                key = "MaxHP",
                anchorText = fullHPText,
                getter = () => player.MaxHP,
                applyText = v =>
                {
                    fullHPText.text = $"/ {Mathf.CeilToInt(v)}";

                    // HP 증강 개수 표시 원하면 여기에 추가 가능
                }
            });
        }

        if (augment != null)
        {
            // =========================
            // Cooldown
            // =========================
            watches.Add(new StatWatch
            {
                key = "Cooldown",
                anchorText = cooldownText_Base,
                getter = () => augment.cooldownMultiplier,
                deltaFormat = "0%",
                threshold = 0.001f,
                applyText = v =>
                {
                    float reduction = (1f - v) * 100f;
                    reduction = Mathf.Clamp(reduction, 0f, 100f);

                    if (cooldownText_Base != null)
                        cooldownText_Base.text = $"{reduction:0}%";

                    if (cooldownText_Aug != null)
                        cooldownText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.Cooldown);
                }
            });
        }

        if (controller != null)
        {
            // =========================
            // Move Speed
            // =========================
            watches.Add(new StatWatch
            {
                key = "MoveSpeed",
                anchorText = moveSpeedText_Base,
                getter = () => controller.MoveSpeed,
                deltaFormat = "0.0",
                threshold = 0.01f,
                applyText = v =>
                {
                    if (moveSpeedText_Base != null)
                        moveSpeedText_Base.text =
                            $"{controller.MoveSpeed:0.0} / {controller.SprintSpeed:0.0}";

                    if (moveSpeedText_Aug != null)
                        moveSpeedText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.MoveSpeed);
                }
            });

            // =========================
            // ATK Speed
            // =========================
            watches.Add(new StatWatch
            {
                key = "ATKSpeed",
                anchorText = atkSpeedText_Base,
                getter = () => augment.bonusATKSpeed,
                deltaFormat = "0%",
                threshold = 0.001f,
                applyText = v =>
                {
                    float percent = v * 100f;

                    if (atkSpeedText_Base != null)
                        atkSpeedText_Base.text = $"{percent:0}%";

                    if (atkSpeedText_Aug != null)
                        atkSpeedText_Aug.text =
                            GetAugmentCountSuffix(AugmentStatType.ATKSpeed);
                }
            });
        }
    }

    // ✅ 최초 1회: 현재값을 UI에 반영 + lastStatValues 스냅샷
    public void ForceRefreshAndSnapshot()
    {
        foreach (var w in watches)
        {
            if (w.getter == null) continue;
            float cur = w.getter.Invoke();

            // UI 반영
            w.applyText?.Invoke(cur);

            // 스냅샷
            lastStatValues[w.key] = cur;
        }
    }

    // ✅ 실제 갱신 로직 → “변한 것만” 반영 + 팝업
    private void RefreshStats()
    {
        if (player == null && controller == null && augment == null) return;

        foreach (var w in watches)
        {
            if (w.getter == null) continue;

            float cur = w.getter.Invoke();
            float last = lastStatValues.TryGetValue(w.key, out var v) ? v : cur;

            float delta = cur - last;

            // 🔥 쿨타임은 감소율 기준으로 뒤집기
            if (w.key == "Cooldown")
            {
                delta = (last - cur) * 100f;
            }

            // 변화 없으면 스킵 (텍스트도 안 건드림)
            if (Mathf.Abs(delta) < w.threshold)
                continue;

            // 1) 텍스트 갱신 (값이 바뀐 경우에만)
            w.applyText?.Invoke(cur);

            // 2) 델타 팝업
            if (w.showDeltaPopup && StatPopupManager.Instance != null && w.anchorText != null)
            {
                string deltaStr = delta > 0
                    ? $"+{delta.ToString(w.deltaFormat)}"
                    : delta.ToString(w.deltaFormat);

                StatPopupManager.Instance.ShowDelta(
                    w.anchorText,                 // ✅ 해당 스탯 우측에서 뜨게
                    deltaStr,
                    delta > 0 ? Color.green : Color.red
                );
            }

            // 3) 스냅샷 업데이트
            lastStatValues[w.key] = cur;
        }
    }

    // =========================
    // HP / MP UI (기존 유지)
    // =========================
    public void UpdateHP(float current, float max)
    {
        float clampedCurrent = Mathf.Max(0f, current);
        float ratio = clampedCurrent / max;

        hpFillImage.fillAmount = ratio;
        currentHPText.text = Mathf.CeilToInt(clampedCurrent).ToString();
        fullHPText.text = $"/ {Mathf.CeilToInt(max)}";

        HandleLowHPWarning(ratio);
    }

    public void UpdateMP(float current, float max)
    {
        mpFillImage.fillAmount = current / max;
        currentMPText.text = Mathf.CeilToInt(current).ToString();
        fullMPText.text = $"/ {Mathf.CeilToInt(max)}";
    }

    // 🔥 HP 즉시 1회 갱신 (피격용)
    public void ForceRefreshHP()
    {
        if (cachedMaxHP <= 0f) return;

        float hpRatio = cachedHP / cachedMaxHP;

        hpFillImage.fillAmount = hpRatio;
        currentHPText.text = Mathf.CeilToInt(cachedHP).ToString();
        fullHPText.text = $"/ {Mathf.CeilToInt(cachedMaxHP)}";

        HandleLowHPWarning(hpRatio);
    }

    // 🔥 MP 즉시 1회 갱신 (Hold용)
    public void ForceRefreshMP()
    {
        if (cachedMaxMP <= 0f) return;

        mpFillImage.fillAmount = cachedMP / cachedMaxMP;
        currentMPText.text = Mathf.CeilToInt(cachedMP).ToString();
        fullMPText.text = $"/ {Mathf.CeilToInt(cachedMaxMP)}";
    }

    private void HandleLowHPWarning(float hpRatio)
    {
        if (lowHPWarningBG == null) return;

        if (hpRatio <= lowHPPercent)
        {
            if (hpWarningRoutine == null)
                hpWarningRoutine = StartCoroutine(BlinkLowHP());
        }
        else
        {
            if (hpWarningRoutine != null)
            {
                StopCoroutine(hpWarningRoutine);
                hpWarningRoutine = null;
            }

            lowHPWarningBG.gameObject.SetActive(false);
        }
    }

    private IEnumerator BlinkLowHP()
    {
        lowHPWarningBG.gameObject.SetActive(true);

        while (true)
        {
            float a = (Mathf.Sin(Time.time * blinkSpeed) + 1f) * 0.5f;

            Color tonedDownRed = new Color(0.7f, 0.12f, 0.12f);
            tonedDownRed.a = Mathf.Lerp(0.08f, 0.3f, a);

            lowHPWarningBG.color = tonedDownRed;

            yield return null;
        }
    }

    private string GetAugmentCountSuffix(AugmentStatType stat)
    {
        if (augment == null) return "";

        int s = augment.GetAugmentCountByStatAndRarity(stat, AugmentRarity.Silver);
        int g = augment.GetAugmentCountByStatAndRarity(stat, AugmentRarity.Gold);
        int d = augment.GetAugmentCountByStatAndRarity(stat, AugmentRarity.Diamond);

        return $" ({s}, {g}, {d})";
    }

    public void TogglePanel()
    {
        isBaseMode = !isBaseMode;
        SetPanelMode(isBaseMode);
    }

    private void SetPanelMode(bool baseMode)
    {
        if (basePanelGroup != null)
        {
            basePanelGroup.alpha = baseMode ? 1f : 0f;
        }

        if (augmentPanelGroup != null)
        {
            augmentPanelGroup.alpha = baseMode ? 0f : 1f;
        }
    }
}