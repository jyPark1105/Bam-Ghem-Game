using UnityEngine;

public class CameraLook : MonoBehaviour
{
    [Header("Look Settings")]
    public Transform player;
    public float sensitivity = 0.2f;
    public float pitchMin = -30f;
    public float pitchMax = 60f;

    private float yaw = 0f;
    private float pitch = 15f;
    private Vector2 lastTouchPos;
    private bool isLooking = false;

    void Start()
    {
        Vector3 euler = transform.eulerAngles;
        yaw = euler.y;
        pitch = euler.x;
    }

    void Update()
    {
        if (Input.touchCount > 0)
        {
            Touch t = Input.GetTouch(0);
            Vector2 normalized = new Vector2(t.position.x / Screen.width, t.position.y / Screen.height);

            // ������ ����(���θ�� ����) ��ġ �� ȸ�� ����
            if (normalized.x > 0.5f)
            {
                if (t.phase == TouchPhase.Began)
                {
                    isLooking = true;
                    lastTouchPos = t.position;
                }
                else if (t.phase == TouchPhase.Moved && isLooking)
                {
                    Vector2 delta = t.position - lastTouchPos;
                    lastTouchPos = t.position;

                    yaw += delta.x * sensitivity;
                    pitch -= delta.y * sensitivity;
                    pitch = Mathf.Clamp(pitch, pitchMin, pitchMax);
                }
                else if (t.phase == TouchPhase.Ended)
                {
                    isLooking = false;
                }
            }
        }

        if (player != null)
        {
            Quaternion rotation = Quaternion.Euler(pitch, yaw, 0);
            transform.position = player.position + rotation * new Vector3(0, 1.6f, -3f);
            transform.LookAt(player.position + Vector3.up * 1.2f);
        }
    }
}