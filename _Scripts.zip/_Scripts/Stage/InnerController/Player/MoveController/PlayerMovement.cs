using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerMovement : MonoBehaviour
{
    [Header("References")]
    public FloatingJoystick joystick;
    public Animator animator;
    public Transform cameraPivot; // ī�޶� ����� Pivot
    public Camera mainCamera;

    [Header("Movement Settings")]
    public float moveSpeed = 4f;
    public float rotationSpeed = 8f;
    public float gravity = -9.81f;

    [Header("Camera Look")]
    public float lookSensitivity = 80f;
    public float lookSmooth = 8f;

    private CharacterController controller;
    private Vector3 velocity;
    private float camYaw = 0f;
    private float camPitch = 10f;

    private bool isDragging = false;
    private Vector2 lastTouchPos;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (mainCamera == null)
            mainCamera = Camera.main;
    }

    void Update()
    {
        HandleMovement();
        HandleCameraLook();
    }

    // ============================================================
    // �̵� ó��
    // ============================================================
    void HandleMovement()
    {
        float h = joystick.Horizontal;
        float v = joystick.Vertical;
        Debug.Log($"Joystick: H={joystick.Horizontal}, V={joystick.Vertical}");

        Vector3 inputDir = new Vector3(h, 0, v);

        if (inputDir.magnitude > 1f)
            inputDir.Normalize();

        // ī�޶� ���� ���� �̵�
        Vector3 camForward = mainCamera.transform.forward;
        Vector3 camRight = mainCamera.transform.right;
        camForward.y = camRight.y = 0;

        Vector3 moveDir = camForward * inputDir.z + camRight * inputDir.x;
        controller.Move(moveDir * moveSpeed * Time.deltaTime);

        // ȸ��
        if (moveDir.sqrMagnitude > 0.01f)
        {
            Quaternion targetRot = Quaternion.LookRotation(moveDir);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, rotationSpeed * Time.deltaTime);
        }

        // �߷� ó��
        if (controller.isGrounded && velocity.y < 0)
            velocity.y = -2f;
        else
            velocity.y += gravity * Time.deltaTime;

        controller.Move(velocity * Time.deltaTime);

        // �ִϸ��̼� ����
        UpdateAnimations(inputDir);
    }

    // ============================================================
    // ī�޶� ȸ�� ó�� (������ ���� �巡��)
    // ============================================================
    void HandleCameraLook()
    {
#if UNITY_EDITOR
        // ���콺�� �׽�Ʈ��
        if (Input.GetMouseButtonDown(0))
        {
            if (Input.mousePosition.x > Screen.width * 0.5f)
            {
                isDragging = true;
                lastTouchPos = Input.mousePosition;
            }
        }
        if (Input.GetMouseButtonUp(0))
            isDragging = false;

        if (isDragging)
        {
            Vector2 delta = (Vector2)Input.mousePosition - lastTouchPos;
            camYaw += delta.x * lookSensitivity * Time.deltaTime;
            camPitch -= delta.y * lookSensitivity * Time.deltaTime;
            camPitch = Mathf.Clamp(camPitch, -10f, 40f);
            lastTouchPos = Input.mousePosition;
        }
#else
        // ����� ��ġ
        if (Input.touchCount > 0)
        {
            Touch t = Input.GetTouch(0);
            if (t.position.x > Screen.width * 0.5f)
            {
                if (t.phase == TouchPhase.Began)
                {
                    isDragging = true;
                    lastTouchPos = t.position;
                }
                else if (t.phase == TouchPhase.Moved && isDragging)
                {
                    Vector2 delta = t.position - lastTouchPos;
                    camYaw += delta.x * lookSensitivity * Time.deltaTime;
                    camPitch -= delta.y * lookSensitivity * Time.deltaTime;
                    camPitch = Mathf.Clamp(camPitch, -10f, 40f);
                    lastTouchPos = t.position;
                }
                else if (t.phase == TouchPhase.Ended)
                    isDragging = false;
            }
        }
#endif

        // ī�޶� ȸ�� ����
        cameraPivot.rotation = Quaternion.Lerp(
            cameraPivot.rotation,
            Quaternion.Euler(camPitch, camYaw, 0),
            Time.deltaTime * lookSmooth
        );

        // ī�޶� ��ġ ���� (Pivot ���� ����)
        if (mainCamera != null)
        {
            mainCamera.transform.position = cameraPivot.position
                - cameraPivot.forward * 2.5f
                + Vector3.up * 1.5f;
            mainCamera.transform.LookAt(cameraPivot.position + Vector3.up * 1.0f);
        }
    }

    // ============================================================
    // �ִϸ��̼� ��ȯ
    // ============================================================
    void UpdateAnimations(Vector3 inputDir)
    {
        float h = inputDir.x;
        float v = inputDir.z;

        // �߾� (����)
        if (inputDir.magnitude < 0.1f)
        {
            animator.Play("Idle");
            return;
        }

        // ���� �Ǵ�
        if (Mathf.Abs(v) >= Mathf.Abs(h))
        {
            animator.Play("walk_front"); // ��/���� ����
        }
        else if (h > 0)
        {
            animator.Play("walk_right");
        }
        else if (h < 0)
        {
            animator.Play("walk_left");
        }
    }
}