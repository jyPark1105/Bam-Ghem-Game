﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using static PlayerAbsorbEffect;
using Cinemachine;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace StarterAssets
{
    public class ThirdPersonController : MonoBehaviour
    {
        public StageSceneController stageController;

        [Header("Player Status")]
        public PlayerStatus playerStatus;
        public ThirdPersonController playerController;
        public PlayerAugmentManager playerAugment;

        // ===== 기존 변수들 =====
        [Header("Player Speed")]
        public float MoveSpeed;
        public float SprintSpeed;
        public float BaseMoveSpeed { get; private set; }
        public float BaseSprintSpeed { get; private set; }

        public float SpeedChangeRate;

        [Range(0.0f, 0.3f)] public float RotationSmoothTime = 0.12f;

        public AudioClip LandingAudioClip;
        public AudioClip[] FootstepAudioClips;
        public float FootstepAudioVolume = 0.5f;

        [Space(10)]
        public float JumpHeight = 1.2f;
        public float Gravity = -15.0f;
        public float JumpTimeout = 0.50f;
        public float FallTimeout = 0.15f;

        [Header("Player Grounded")]
        public bool isGrounded = true;
        public float GroundedOffset = -0.14f;
        public float GroundedRadius = 0.28f;
        public LayerMask GroundLayers;

        [Header("InAir Safety")]
        [SerializeField] private float maxInAirTime = 1.2f; // 조절 가능
        private float inAirTimer = 0f;

        [Header("Attack Settings")]
        public SlashVFXManager slashVFXManager;
        public AttackDetector attackDetector;
        private bool isAttacking = false;
        private bool _lastAttackIsRight;
        // 🔥 공격 시점 Transform 스냅샷
        private Vector3 _attackSnapshotPos;
        private Quaternion _attackSnapshotRot;

        [Header("Camera Shake")]
        public CinemachineImpulseSource attackImpulse;

        // ===================== Action Cooldowns =====================
        [Header("Action Cooldowns")]
        public float attackCooldown = 1.0f;
        public float jumpCooldown = 0.5f;
        public float getItemCooldown = 0.5f;
        public float climbCooldown = 0.5f;

        private float attackCooldownTimer = 0f;
        private float jumpCooldownTimer = 0f;
        private float getItemCooldownTimer = 0f;
        private float climbCooldownTimer = 0f;
        
        [Header("Attack Speed Base")]
        [SerializeField] private float baseAttackSpeed = 2.0f;

        [Header("Attack Speed Limit")]
        [SerializeField] private float maxAttackSpeedMultiplier = 3.0f;
        // Attack
        public bool IsAttackCooldown => attackCooldownTimer > 0f;
        private float currentAttackCooldownDuration;
        public float AttackCooldownRatio =>
            currentAttackCooldownDuration <= 0
                ? 0
                : attackCooldownTimer / currentAttackCooldownDuration;
        public float AttackCooldownDuration => attackCooldown;

        // Jump
        public bool IsJumpCooldown => jumpCooldownTimer > 0f;
        public float JumpCooldownRatio =>
            jumpCooldown <= 0 ? 0 : jumpCooldownTimer / jumpCooldown;
        public float JumpCooldownDuration => jumpCooldown;

        // GetItem
        public bool IsGetItemCooldown => getItemCooldownTimer > 0f;
        public float GetItemCooldownRatio =>
            getItemCooldown <= 0 ? 0 : getItemCooldownTimer / getItemCooldown;
        public float GetItemCooldownDuration => getItemCooldown;

        // Climb
        public bool IsClimbCooldown => climbCooldownTimer > 0f;
        public float ClimbCooldownRatio =>
            climbCooldown <= 0 ? 0 : climbCooldownTimer / climbCooldown;
        public float ClimbCooldownDuration => climbCooldown;

        // ===================== Skill Controllers =====================
        private Player_SkillACtrl skillACtrl;
        private Player_SkillBCtrl skillBCtrl;
        private Player_SkillCCtrl skillCCtrl;
        private Player_SkillRCtrl skillRCtrl;

        // Ready 플래그
        public bool IsPlayerReady =>
            absorbEffect != null && absorbEffect.IsInitialized;

        [Header("Climb Settings")]
        public ClimbSensor climbSensor;
        public float climbEndOffset = 0.01f;
        public float offsetFactor = 0.5f;

        private bool isClimbing = false;
        public bool IsClimbing => isClimbing;
        private Collider climbTargetWall;

        // 🔥 Ground Lock 추가
        private float groundedLockTimer = 0f;
        private float climbLandingLock = 0f;

        [Header("GetItem Settings")]
        // Item Scanner
        [SerializeField]
        private ItemScanner itemScanner;
        public Transform itemHoldPoint;
        public Item currentHeldItem; // 스캔으로 얻은 '실제 오브젝트'
        // Attribute Changing Effect
        private bool isAbsorbing = false;
        public bool IsAbsorbing => isAbsorbing;

        // 🔥 footstepLock 추가 (점프 순간 발소리 무시)
        private float footstepLock = 0f;
        private bool _fromJump = false;

        [Header("Cinemachine")]
        public GameObject CinemachineCameraTarget;
        public float TopClamp = 70.0f;
        public float BottomClamp = -30.0f;
        public float CameraAngleOverride = 0.0f;
        public bool LockCameraPosition = false;

        public bool IsCCTVMode { get; private set; }

        // Cinemachine Access => PlayerAbsorbEffect.cs
        public PlayerAbsorbEffect absorbEffect;
        public float _cinemachineTargetYaw;
        public float _cinemachineTargetPitch;

        private float _speed;
        private float _animationBlend;
        private float _targetRotation = 0.0f;
        private float _rotationVelocity;
        private float _verticalVelocity;
        private float _terminalVelocity = 53.0f;

        private float _jumpTimeoutDelta;
        private float _fallTimeoutDelta;

        // Animator IDs
        private int _animIDSpeed;
        private int _animIDGrounded;
        private int _animIDJump;
        private int _animIDFreeFall;
        private int _animIDMotionSpeed;
        private int _animIDAttackL;
        private int _animIDAttackR;
        private int _animIDIsAttacking;
        private int _animIDAttackSpeed;
        private int _animIDClimb;
        private int _animIDGetItem;
        private int _animIDSkillA;
        private int _animIDSkillB;
        private int _animIDSkillR;

        // Player Layer
        private int originalLayer;

        // 캐싱 영역
#if ENABLE_INPUT_SYSTEM
        private PlayerInput _playerInput;
#endif
        private Animator _animator;
        public Animator Animator => _animator;
        private CharacterController _controller;
        private StarterAssetsInputs _input;
        private GameObject _mainCamera;

        private const float _threshold = 0.01f;
        private bool _hasAnimator;

        // Transform 캐싱
        private Transform _transform;
        private Transform _cameraTargetTransform;
        private Transform _mainCameraTransform;

        private bool isBusy = false;
        public bool IsBusy => isBusy;

        public bool IsChatMode { get; private set; }

        private bool IsCurrentDeviceMouse =>
#if ENABLE_INPUT_SYSTEM
            _playerInput.currentControlScheme == "KeyboardMouse";
#else
            false;
#endif

        private void Awake()
        {
            _transform = transform;

            _hasAnimator = TryGetComponent(out _animator);
            _controller = GetComponent<CharacterController>();
            _input = GetComponent<StarterAssetsInputs>();

#if ENABLE_INPUT_SYSTEM
            _playerInput = GetComponent<PlayerInput>();
#endif

            // MainCamera 캐싱 (Find 1회만)
            Camera cam = Camera.main;
            if (cam != null)
            {
                _mainCameraTransform = cam.transform;
            }

            _cameraTargetTransform = CinemachineCameraTarget.transform;

            // SnapShot(UI_PlayerStatus 클래스 전용)
            BaseMoveSpeed = MoveSpeed;
            BaseSprintSpeed = SprintSpeed;
        }

        private void Start()
        {
            _cinemachineTargetYaw = _cameraTargetTransform.rotation.eulerAngles.y;

            AssignAnimationIDs();

            _jumpTimeoutDelta = JumpTimeout;
            _fallTimeoutDelta = FallTimeout;

            itemScanner = GetComponent<ItemScanner>();

            skillACtrl = GetComponent<Player_SkillACtrl>();
            skillBCtrl = GetComponent<Player_SkillBCtrl>();
            skillCCtrl = GetComponent<Player_SkillCCtrl>();
            skillRCtrl = GetComponent<Player_SkillRCtrl>();

#if UNITY_EDITOR
            MoveSpeed = 20f;
            SprintSpeed = 30f;
            SpeedChangeRate = 15f;
#elif UNITY_ANDROID
            MoveSpeed = 7f;
            SprintSpeed = 10f;
            SpeedChangeRate = 5f;
#endif

            SceneTransitionManager.Instance?.RegisterPlayer(this);

            stageController.RegisterPlayer(this);
        }

        private void OnDestroy()
        {
            if (SceneTransitionManager.Instance != null)
            {
                SceneTransitionManager.Instance.UnregisterPlayer(this);
            }
        }

        private void Update()
        {
            // 게임 극초기 업데이트
            // 1. 채팅 중일 때
            if (IsChatMode)
                return;
            // 2. 속성 흡수 중일 때
            if (absorbEffect != null && absorbEffect.IsAbsorbing)
                return;

#if UNITY_EDITOR
            EditorSkillAHoldHack(); // Q를 꾹 누르면 SkillA_Blue: Hold 유지
#endif
            if (attackCooldownTimer > 0f)
                attackCooldownTimer -= Time.deltaTime;

            if (jumpCooldownTimer > 0f)
                jumpCooldownTimer -= Time.deltaTime;

            if (getItemCooldownTimer > 0f)
                getItemCooldownTimer -= Time.deltaTime;

            if (climbCooldownTimer > 0f)
                climbCooldownTimer -= Time.deltaTime;

            if (footstepLock > 0f)
                footstepLock -= Time.deltaTime;

            if (climbLandingLock > 0f)
            {
                climbLandingLock -= Time.deltaTime;
                isGrounded = true;
                _verticalVelocity = 0;
                _animator.SetBool(_animIDJump, false);
                _animator.SetBool(_animIDFreeFall, false);
                return;
            }

            // Frame Update
            if (!isClimbing)
            {
                // 1. Check Move
                Move();
                GroundedCheck();
                JumpAndGravity();

                // 2. Handle Attacks & Skills
                HandleAttack();
                //HandleAttackSlash();
                skillACtrl?.Tick();
                skillBCtrl?.Tick();
                skillCCtrl?.Tick();
                skillRCtrl?.Tick();

                // 3. Rest
#if UNITY_EDITOR
                HandleEditorShortcut(); // Climb, GetItem
#endif
            }
            else
            {
                _verticalVelocity = 0;
            }
        }

        private void LateUpdate()
        {
            if (IsChatMode)
                return;

            CameraRotation();
            CheckInAirStuck();
        }

        // ChatManager 클래스에서 사용하는 명시적 API 함수
        public void SetChatMode(bool active)
        {
            IsChatMode = active;

            if (active)
            {
                SetBusy(true);          // 게임 로직 차단
                _verticalVelocity = 0;
                _speed = 0;

                if (_hasAnimator)
                {
                    _animator.SetFloat(_animIDSpeed, 0);
                    _animator.SetBool(_animIDIsAttacking, false);
                }
            }
            else
            {
                SetBusy(false);
            }
        }

        private void AssignAnimationIDs()
        {
            _animIDSpeed = Animator.StringToHash("Speed");
            _animIDGrounded = Animator.StringToHash("Grounded");
            _animIDJump = Animator.StringToHash("Jump");
            _animIDFreeFall = Animator.StringToHash("FreeFall");
            _animIDMotionSpeed = Animator.StringToHash("MotionSpeed");

            _animIDClimb = Animator.StringToHash("Climb");
            _animIDGetItem = Animator.StringToHash("GetItem");

            // Two Attacks
            _animIDAttackL = Animator.StringToHash("AttackL");
            _animIDAttackR = Animator.StringToHash("AttackR");
            _animIDIsAttacking = Animator.StringToHash("IsAttacking");
            _animIDAttackSpeed = Animator.StringToHash("AttackSpeed");

            _animIDSkillA = Animator.StringToHash("SkillA");
            _animIDSkillB = Animator.StringToHash("SkillB");
            _animIDSkillR = Animator.StringToHash("SkillR");
        }

        /// <summary>
        /// 움직임 디버깅 함수
        /// </summary>
        /*
        public void DebugInputState(string from)
        {
            var inputs = GetComponent<StarterAssetsInputs>();
            if (inputs == null)
            {
                StageLogPanel.Log($"[InputState:{from}] StarterAssetsInputs = null", LogType.Error);
                return;
            }

            StageLogPanel.Log(
                $"[InputState:{from}] move={inputs.move}, jump={inputs.jump}, sprint={inputs.sprint}",
                LogType.Warning
            );
        }
        */


#if UNITY_EDITOR
        private void HandleEditorShortcut()
        {
            // GetItem : P 키
            if (Input.GetKeyDown(KeyCode.P))
            {
                ExecuteGetItem();
            }

            // Climb : U 키
            if (Input.GetKeyDown(KeyCode.U))
            {
                ExecuteClimb();
            }
        }
#endif

#if UNITY_EDITOR
        private void EditorSkillAHoldHack()
        {
            // Q 키를 누르고 있는 동안 SkillA를 true로 유지
            if (Input.GetKey(KeyCode.Q))
            {
                _input.skillA = true;
            }
            else if (Input.GetKeyUp(KeyCode.Q))
            {
                _input.skillA = false;
            }
        }
#endif

        // ===================== Grounded Check =====================
        private void GroundedCheck()
        {
            // 🔥 climbLandingLock 중에는 Grounded 체크를 하지 않음!
            if (climbLandingLock > 0f)
            {
                isGrounded = true;
                _animator.SetBool(_animIDGrounded, true);
                return;
            }

            // ▶ 기존 Ground Lock 기능 유지
            if (groundedLockTimer > 0f)
            {
                groundedLockTimer -= Time.deltaTime;
                isGrounded = false;

                if (_hasAnimator)
                    _animator.SetBool(_animIDGrounded, false);

                return;
            }

            // ------------------------------------------
            // 1) 우선 CheckSphere로 "바닥 후보"를 감지
            // ------------------------------------------
            Vector3 pos = _transform.position;
            Vector3 spherePos = new Vector3(
                pos.x,
                pos.y - GroundedOffset,
                pos.z
            );

            bool sphereHit = Physics.CheckSphere(spherePos, GroundedRadius, GroundLayers);

            if (!sphereHit)
            {
                // 바닥과 접점 없음 → 공중
                isGrounded = false;
                if (_hasAnimator)
                    _animator.SetBool(_animIDGrounded, false);
                return;
            }

            // ------------------------------------------
            // 2) Raycast로 바닥 normal 검사 (벽 구분 핵심!)
            // ------------------------------------------
            RaycastHit hit;
            Vector3 rayOrigin = _transform.position + Vector3.up * 0.2f;
            float rayLength = GroundedOffset + 0.5f;

            if (Physics.Raycast(rayOrigin, Vector3.down, out hit, rayLength, GroundLayers))
            {
                // normal.y == 1 → 수직 바닥  
                // normal.y == 0 → 수직 벽  
                // 0.5f 기준으로 벽과 바닥 구분
                if (hit.normal.y > 0.5f)
                {
                    isGrounded = true;  // ✔ 진짜 바닥
                }
                else
                {
                    isGrounded = false; // ❌ 벽 → Ground 취급 금지
                }
            }
            else
            {
                isGrounded = false;
            }

            if (_hasAnimator)
                _animator.SetBool(_animIDGrounded, isGrounded);
        }

        // InAir 갇힘 체크 함수
        private void CheckInAirStuck()
        {
            if (!_hasAnimator) return;

            AnimatorStateInfo state = _animator.GetCurrentAnimatorStateInfo(0);

            bool isInAirState =
                state.IsName("InAir") ||
                state.IsName("Jump") ||
                state.IsName("FreeFall");

            if (!isInAirState)
            {
                inAirTimer = 0f;
                return;
            }

            // InAir 상태 유지 시간 누적
            inAirTimer += Time.deltaTime;

            // 🔥 핵심: "실제 바닥 감지 시"만 강제 복구
            if (inAirTimer >= maxInAirTime && isGrounded)
            {
                InAirHelperFunction();
            }
        }

        // 헬퍼 함수
        private void InAirHelperFunction()
        {
            Debug.LogWarning("⚠ InAir Stuck detected → Force Reset");

            // 🔥 상태 강제 복구
            isGrounded = true;
            isAttacking = false;

            _verticalVelocity = 0f;

            // 🔥 Animator 파라미터 정리
            _animator.SetBool(_animIDGrounded, true);
            _animator.SetBool(_animIDJump, false);
            _animator.SetBool(_animIDFreeFall, false);
            _animator.SetBool(_animIDIsAttacking, false);

            // 🔥 Busy 해제
            SetBusy(false);

            // 🔥 타이머 리셋
            inAirTimer = 0f;
        }

        // ===================== Camera =====================
        public void PlayAttackCameraShake()
        {
            if (attackImpulse == null)
                return;

            attackImpulse.GenerateImpulse(0.3f);
        }

        public void PlaySkillCameraShake()
        {
            if (attackImpulse == null)
                return;

            int rand = Random.Range(3, 8);  // 3 ~ 7

            float power = rand * 0.1f; // 0.3 ~ 0.7

            attackImpulse.GenerateImpulse(power);
        }

        private void CameraRotation()
        {
            if (IsCCTVMode)
                return;

            if (_input.look.sqrMagnitude >= _threshold && !LockCameraPosition)
            {
                float mul = IsCurrentDeviceMouse ? 1.0f : Time.deltaTime;

                _cinemachineTargetYaw += _input.look.x * mul;
                _cinemachineTargetPitch += _input.look.y * mul;
            }

            _cinemachineTargetYaw = ClampAngle(_cinemachineTargetYaw, float.MinValue, float.MaxValue);
            _cinemachineTargetPitch = ClampAngle(_cinemachineTargetPitch, BottomClamp, TopClamp);

            _cameraTargetTransform.rotation =
                Quaternion.Euler(
                    _cinemachineTargetPitch + CameraAngleOverride,
                    _cinemachineTargetYaw,
                    0f
                );
        }

        public void SetCCTVMode(bool active)
        {
            IsCCTVMode = active;
            LockCameraPosition = active; // 기존 변수 재활용
        }

        public void SetBusy(bool busy)
        {
            isBusy = busy;

            if (busy)
            {
                // 이동 중단만 한다
                _speed = 0;
                _verticalVelocity = 0;
            }
            else
            {
                EnableAllInputs(); // 🔥 이 줄 추가
            }
        }

        // ===================== Move =====================
        private void Move()
        {
            if (isBusy && !isAttacking)
            {
                _controller.Move(new Vector3(0, _verticalVelocity, 0) * Time.deltaTime);
                return;
            }

            float targetSpeed = _input.sprint ? SprintSpeed : MoveSpeed;

            // 🔵 SkillA (Blue Hold) 이동 감속 – 외부 위임
            if (skillACtrl != null)
            {
                float mul = skillACtrl.GetMoveSpeedMultiplier();
                if (mul < 1f)
                    _input.sprint = false;

                targetSpeed *= mul;
            }

            // 🔥 공격 중엔 이동 속도 20% 감속
            if (isAttacking)
                targetSpeed *= 0.8f;

            if (_input.move == Vector2.zero) targetSpeed = 0f;

            float currentSpeed =
                new Vector3(_controller.velocity.x, 0, _controller.velocity.z).magnitude;

            float speedOffset = 0.1f;
            float inputMag = _input.analogMovement ? _input.move.magnitude : 1f;

            if (currentSpeed < targetSpeed - speedOffset || currentSpeed > targetSpeed + speedOffset)
            {
                _speed = Mathf.Lerp(currentSpeed, targetSpeed * inputMag, Time.deltaTime * SpeedChangeRate);
                _speed = Mathf.Round(_speed * 1000f) / 1000f;
            }
            else _speed = targetSpeed;

            _animationBlend = Mathf.Lerp(_animationBlend, targetSpeed, Time.deltaTime * SpeedChangeRate);
            if (_animationBlend < 0.01f) _animationBlend = 0;

            Vector3 inputDir = new Vector3(_input.move.x, 0, _input.move.y).normalized;

            if (_input.move != Vector2.zero)
            {
                _targetRotation = Mathf.Atan2(inputDir.x, inputDir.z) * Mathf.Rad2Deg
                                  + _mainCameraTransform.eulerAngles.y;

                float rotation = Mathf.SmoothDampAngle(
                    _transform.eulerAngles.y, _targetRotation, ref _rotationVelocity, RotationSmoothTime
                );

                _transform.rotation = Quaternion.Euler(0, rotation, 0);
            }

            Vector3 targetDir = Quaternion.Euler(0, _targetRotation, 0) * Vector3.forward;

            _controller.Move(
                targetDir.normalized * (_speed * Time.deltaTime)
                + new Vector3(0, _verticalVelocity, 0) * Time.deltaTime
            );

            if (_hasAnimator)
            {
                _animator.SetFloat(_animIDSpeed, _animationBlend);
                _animator.SetFloat(_animIDMotionSpeed, inputMag);
            }
        }

        // ===================== Jump & Gravity =====================
        private void JumpAndGravity()
        {
            if (isGrounded)
            {
                _fallTimeoutDelta = FallTimeout;

                if (_verticalVelocity < 0)
                    _verticalVelocity = -2f;

                if (_input.jump
                    && _jumpTimeoutDelta <= 0
                    && !IsJumpCooldown
                    && !isBusy
                    && (skillACtrl == null || skillACtrl.GetMoveSpeedMultiplier() >= 1f))   // 🔥 스킬/공격/아이템 중 점프 금지
                {
                    jumpCooldownTimer = jumpCooldown;

                    _verticalVelocity = Mathf.Sqrt(JumpHeight * -2f * Gravity);

                    // 🔥 점프 시 footstepLock 적용 (발소리 잠시 꺼짐)
                    footstepLock = 0.12f;

                    if (_hasAnimator)
                    {
                        _animator.SetBool(_animIDJump, true);

                        if (isAttacking)
                            _animator.SetBool(_animIDJump, false);
                    }

                    StageManager.Instance.OnSkillUsed("Jump");

                    if (!isAttacking)
                        AudioManager.Instance.PlayJump();

                    _fromJump = true;   // ← 점프 상태 표시
                }

                if (_jumpTimeoutDelta >= 0)
                    _jumpTimeoutDelta -= Time.deltaTime;
            }
            else
            {
                _jumpTimeoutDelta = JumpTimeout;

                if (_fallTimeoutDelta >= 0)
                    _fallTimeoutDelta -= Time.deltaTime;
                else
                    _animator.SetBool(_animIDFreeFall, true);

                _input.jump = false;
            }

            if (_verticalVelocity < _terminalVelocity)
                _verticalVelocity += Gravity * Time.deltaTime;

            if (_animator.GetCurrentAnimatorStateInfo(0).IsName("JumpStart"))
                _animator.SetBool(_animIDJump, false);
        }

        // ==================================================
        // ===================== Attack =====================
        // ==================================================
        private void HandleAttack()
        {
            if (!_input.attack)
                return;

            if (!isGrounded)
            {
                DebugStateAnimator_InStage.Instance.AnimateAll(GameMessage.NOT_GROUNDED);
                _input.attack = false;
                return;
            }

            if (isBusy || IsAttackCooldown)
                return;

            // =============================
            // 🔥 공격속도 계산 (Multiplier)
            // =============================
            float attackSpeed = baseAttackSpeed;

            // 공격속도 상한선 추가
            if (playerAugment != null)
            {
                float mul = Mathf.Clamp(
                    1f + playerAugment.bonusATKSpeed,
                    0.1f,
                    maxAttackSpeedMultiplier
                );

                attackSpeed = baseAttackSpeed * mul;
            }

            // 실제 쿨타임
            currentAttackCooldownDuration = 
                attackCooldown / (attackSpeed / baseAttackSpeed);

            attackCooldownTimer = currentAttackCooldownDuration;

            // Animator Multiplier에 전달
            _animator.SetFloat(_animIDAttackSpeed, attackSpeed);

            isAttacking = true;
            _animator.SetBool(_animIDIsAttacking, true);
            attackDetector.StartAttack();

            AudioManager.Instance.PlayAttack();

            bool isRight = Random.Range(0, 2) == 1;
            _lastAttackIsRight = isRight;

            _animator.SetTrigger(isRight ? _animIDAttackR : _animIDAttackL);

            StageManager.Instance.OnSkillUsed("Attack");

            _input.attack = false;
        }

        public void Attack_Effect()
        {
            if (slashVFXManager == null || attackDetector == null)
                return;

            slashVFXManager.PlaySlash(
                absorbEffect.colorType,
                _lastAttackIsRight,
                attackDetector
            );
        }

        // Attack animation: Last frame event
        public void OnAttackEnd()
        {
            if (attackDetector != null) attackDetector.EndAttack();
            isAttacking = false;
            _animator.SetBool(_animIDIsAttacking, false);

            if (_animator != null)
            {
                _animator.SetBool(_animIDIsAttacking, false);
                _animator.SetFloat(_animIDAttackSpeed, baseAttackSpeed);
            }
        }

        // ===================== Skill UI Control =====================
        public bool HasSkillAttribute()
        {
            return absorbEffect != null &&
                   absorbEffect.colorType != PlayerAbsorbEffect.ColorType.None;
        }

        // =================================================
        // ===================== Climb =====================
        // =================================================
        public bool CanClimb()
        {
            if (isBusy || IsClimbCooldown) return false;
            if (climbSensor == null) return false;

            return climbSensor.IsTouchingWall && climbSensor.CurrentWall != null;
        }

        public void ExecuteClimb()
        {
            if (!CanClimb()) return;

            climbCooldownTimer = climbCooldown;
            StartClimb();
        }

        private void StartClimb()
        {
            isClimbing = true;
            _input.move = Vector2.zero;
            _verticalVelocity = 0;

            climbTargetWall = climbSensor.CurrentWall;

            // 🔥 레이어 저장
            originalLayer = LayerMask.NameToLayer("Player");

            // 🔥 전체 오브젝트를 PlayerClimb로 변경
            int climbLayer = LayerMask.NameToLayer("PlayerClimb");
            SetLayerRecursively(gameObject, climbLayer);

            // 🔥 앞으로 0.1만큼 이동해서 벽 밀착
            Vector3 forwardOffset = _transform.forward * 0.15f;
            Vector3 pos = _transform.position;

            Vector3 snapPos = new Vector3(
                pos.x + forwardOffset.x,
                pos.y,
                pos.z + forwardOffset.z
            );

            _controller.enabled = false;
            _transform.position = snapPos;
            _controller.enabled = true;

            //AudioManager.Instance.PlayClimb();

            if (_hasAnimator)
            {
                _animator.ResetTrigger(_animIDClimb);
                _animator.SetTrigger(_animIDClimb);
            }
        }

        public void OnClimbFinish()
        {
            isClimbing = false;

            // 🔥 전체 오브젝트 레이어 원상복구
            int playerLayer = LayerMask.NameToLayer("Player");
            SetLayerRecursively(gameObject, playerLayer);

            // 🔥 기존 climb 처리
            float wallTopY = climbTargetWall.bounds.max.y;
            float feetOffset = _controller.center.y - (_controller.height * 0.5f);
            float baseY = wallTopY - feetOffset;

            float forwardOffset = 0.45f;
            Vector3 fwd = _transform.forward;
            Vector3 forwardXZ = new Vector3(fwd.x, 0f, fwd.z).normalized;

            Vector3 finalPos = _transform.position + forwardXZ * forwardOffset;
            finalPos.y = baseY + 0.01f;

            _controller.enabled = false;
            _transform.position = finalPos;
            _controller.enabled = true;

            climbLandingLock = 0.25f;

            isGrounded = true;
            _verticalVelocity = 0;

            _animator.SetBool(_animIDJump, false);
            _animator.SetBool(_animIDFreeFall, false);

            StageManager.Instance.OnSkillUsed("Climb");

            AudioManager.Instance.PlayLand();
            _fromJump = false;
            SetBusy(false);
        }

        private void SetLayerRecursively(GameObject obj, int newLayer)
        {
            obj.layer = newLayer;

            foreach (Transform child in obj.transform)
            {
                SetLayerRecursively(child.gameObject, newLayer);
            }
        }

        // 현재 트리거 방식 사용으로 인해, 굳이 사용하지는 않음.
        // ===================================================
        // ===================== GetItem =====================
        // ===================================================
        public bool CanGetItem()
        {
            if (isBusy || IsGetItemCooldown) return false;
            if (itemScanner == null) return false;

            return itemScanner.TryScanAndPickup() != null;
        }

        public void ExecuteGetItem()
        {
            if (!CanGetItem()) return;

            getItemCooldownTimer = getItemCooldown;

            Item item = itemScanner.TryScanAndPickup();
            if (item == null) return;

            SetBusy(true);
            DisableAllInputs();

            currentHeldItem = item.OnPickup();

            AudioManager.Instance.PlayItemScan();
            _animator.SetTrigger(_animIDGetItem);

            StageManager.Instance.OnSkillUsed("GetItem");
        }

        // Get Item Event: 25th frame
        public void OnItemGrabAnimationEvent()
        {
            if (currentHeldItem == null) return;

            Collider col = currentHeldItem.GetComponent<Collider>();
            if (col != null) col.enabled = false;

            currentHeldItem.transform.SetParent(itemHoldPoint);
            currentHeldItem.transform.localPosition = Vector3.zero;
            currentHeldItem.transform.localRotation = Quaternion.identity;
        }

        // Get Item Event: the last frame
        public void OnItemFinishAnimationEvent()
        {
            Debug.Log("🔥🔥 OnItemFinishAnimationEvent() 호출됨!");

            if (currentHeldItem == null) return;

            string name = currentHeldItem.gameObject.name;

            if (name.StartsWith("Absorb_"))
            {
                // Absorb 색상 추출 (Absorb_Red → Red)
                string colorName = name.Substring(7);

                if (absorbEffect != null)
                {
                    absorbEffect.StartAbsorb(currentHeldItem.gameObject);
                }
                else
                {
                    Debug.LogError("PlayerAbsorbEffect 참조 없음");
                }

                return; // 기존 GetItem 처리 중단
            }

            StageManager.Instance.OnSkillUsed("Absorb");

            // 기존 아이템 로직
            AudioManager.Instance.PlayGetItem();
            Destroy(currentHeldItem.gameObject);
            currentHeldItem = null;

            EnableAllInputs();
            SetBusy(false);
        }

        public void DisableAllInputs()
        {
            // 이동, 공격, 점프, 습득, 클라임, 회피를 전부 차단
            _input.move = Vector2.zero;
            _input.look = Vector2.zero;

            _input.attack = false;
            _input.skillA = false;
            _input.skillB = false;
            _input.jump = false;
            _input.climb = false;

            // 입력 자체를 잠가버리기
#if ENABLE_INPUT_SYSTEM
            _playerInput.enabled = false;
#endif

            // 플레이어 이동/중력 정지
            _verticalVelocity = 0;
            _speed = 0;
        }

        public void EnableAllInputs()
        {
#if ENABLE_INPUT_SYSTEM
            _playerInput.enabled = true;
#endif
        }
        private static float ClampAngle(float lfAngle, float lfMin, float lfMax)
        {
            if (lfAngle < -360f) lfAngle += 360f;
            if (lfAngle > 360f) lfAngle -= 360f;
            return Mathf.Clamp(lfAngle, lfMin, lfMax);
        }

        // ===================== FOOTSTEP =====================
        private void OnFootstep(AnimationEvent animationEvent)
        {
            // 🔥 jump 직후에는 footstep 금지
            if (footstepLock > 0f)
                return;

            if (animationEvent.animatorClipInfo.weight > 0.5f)
            {
                AudioManager.Instance.PlayGrass(1f);
            }
        }

        private void OnLand(AnimationEvent animationEvent)
        {
            if (animationEvent.animatorClipInfo.weight > 0.5f)
            {
                if (_fromJump)
                {
                    // 점프 착지 → Grass 소리
                    AudioManager.Instance.PlayGrass(1f);
                    _fromJump = false;   // 한 번만 Grass 재생
                }
                else
                {
                    // Climb 착지 또는 기타 착지 → Land 소리
                    AudioManager.Instance.PlayLand();
                }
            }
        }
    }
}