﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CameraFollow : MonoBehaviour
{
    [Header("Follow Target")]
    public Transform target;     // 캐릭터
    public Transform pivot;      // 카메라 피봇 (루트 오브젝트)
    public Transform cam;        // 실제 카메라 (pivot의 자식)

    [Header("Camera Settings")]
    public float lookSensitivity = 0.8f;
    public float rotationSmoothTime = 10f;

    [Header("Fixed Offsets")]
    public Vector3 pivotOffset = new Vector3(0f, 2.7f, -2f); // target 기준 offset
    public Vector3 camLocalPosition = Vector3.zero;
    public float pivotFixedPitch = 30f;  // 카메라 고정 pitch 각도

    private bool isDragging = false;
    private int activeTouchId = -1;
    private float yaw;                // 캐릭터 Y 회전값
    private float yawVelocity = 0f;

    private RectTransform rightTouchZoneUI;
    private Camera uiCamera;

    void Start()
    {
        if (!IsStageScene())
        {
            Debug.Log("[CameraFollow] Non-stage scene detected. Disabled.");
            enabled = false;
            return;
        }

        // ✅ pivot을 반드시 루트(월드)로 이동시킴
        if (pivot.parent != null)
            pivot.SetParent(null);

        // ✅ 초기 설정
        yaw = target.eulerAngles.y;

        // ✅ 초기 위치/회전 세팅
        FixCameraTransform();

        SafeLog("<color=#00FFAA>[CameraFollow]</color> Initialized");
        SetupRightTouchZoneUI();
    }

    void LateUpdate()
    {
        if (!target || !pivot || !cam) return;

        HandleTouchRotation();

        // ✅ 1️⃣ 캐릭터 회전 먼저 반영
        Quaternion desiredRot = Quaternion.Euler(0f, yaw, 0f);
        target.rotation = Quaternion.Lerp(target.rotation, desiredRot, Time.deltaTime * rotationSmoothTime);

        // ✅ 2️⃣ pivot 위치 계산
        // 캐릭터 중심에서 일정 거리(반지름)를 유지하면서 yaw 기준으로 회전
        float distance = 1.1f;   // 캐릭터로부터 떨어질 거리 (기존 offset.z 대신)
        float height = 1.5f;   // y 높이 고정

        // yaw -> 라디안 변환
        float rad = Mathf.Deg2Rad * yaw;

        // XZ 오프셋 계산
        float offsetX = Mathf.Sin(rad) * distance;
        float offsetZ = Mathf.Cos(rad) * distance;

        // 목표 위치 계산 (부드럽게 따라오도록 Lerp)
        Vector3 targetPivotPos = new Vector3(
            target.position.x - offsetX,
            target.position.y + height,
            target.position.z - offsetZ
        );
        pivot.position = Vector3.Lerp(pivot.position, targetPivotPos, Time.deltaTime * 10f);

        // ✅ 3️⃣ pivot 회전은 pitch 고정 + yaw 따라가기
        pivot.rotation = Quaternion.Euler(pivotFixedPitch, yaw, 0f);

        // ✅ 4️⃣ 카메라 로컬 위치/회전 고정
        cam.localPosition = camLocalPosition;
        cam.localRotation = Quaternion.identity;
    }


    // 🎮 좌↔우 드래그 → 캐릭터 Y축 회전
    private void HandleTouchRotation()
    {
#if UNITY_EDITOR
        if (Input.GetMouseButtonDown(0))
            isDragging = IsTouchInsideRightZone(Input.mousePosition);
        else if (Input.GetMouseButtonUp(0))
            isDragging = false;

        if (isDragging)
        {
            float dx = Input.GetAxis("Mouse X");
            float rotationSpeed = 200f;
            float targetYawSpeed = dx * rotationSpeed * lookSensitivity;

            yawVelocity = Mathf.Lerp(yawVelocity, targetYawSpeed, Time.deltaTime * 10f);
        }
        else
        {
            yawVelocity = Mathf.Lerp(yawVelocity, 0f, Time.deltaTime * 8f);
        }

        yaw += yawVelocity * Time.deltaTime;

#else
        if (Input.touchCount == 0)
        {
            isDragging = false;
            yawVelocity = Mathf.Lerp(yawVelocity, 0f, Time.deltaTime * 8f);
            return;
        }

        foreach (var t in Input.touches)
        {
            switch (t.phase)
            {
                case TouchPhase.Began:
                    if (!IsTouchInsideRightZone(t.position)) continue;
                    isDragging = true;
                    activeTouchId = t.fingerId;
                    break;

                case TouchPhase.Moved:
                    if (t.fingerId != activeTouchId || !isDragging) break;

                    float dx = t.deltaPosition.x;
                    float rotationSpeed = 150f;
                    float targetYawSpeed = dx * lookSensitivity * rotationSpeed * Time.deltaTime;

                    yawVelocity = Mathf.Lerp(yawVelocity, targetYawSpeed, Time.deltaTime * 10f);
                    break;

                case TouchPhase.Ended:
                case TouchPhase.Canceled:
                    if (t.fingerId == activeTouchId)
                    {
                        isDragging = false;
                        activeTouchId = -1;
                    }
                    break;
            }
        }

        yaw += yawVelocity; // ✅ 캐릭터 회전 누적
#endif
    }

    // ✅ 오른쪽 반화면 터치 감지
    private bool IsTouchInsideRightZone(Vector2 screenPos)
    {
        if (rightTouchZoneUI == null) return false;
        Canvas canvas = rightTouchZoneUI.GetComponentInParent<Canvas>();
        if (canvas == null) return false;

        Camera cam = canvas.renderMode == RenderMode.ScreenSpaceCamera ? canvas.worldCamera : null;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas.GetComponent<RectTransform>(), screenPos, cam, out Vector2 localPoint);
        RectTransform canvasRect = canvas.GetComponent<RectTransform>();
        float normalizedX = Mathf.InverseLerp(canvasRect.rect.xMin, canvasRect.rect.xMax, localPoint.x);
        float normalizedY = Mathf.InverseLerp(canvasRect.rect.yMin, canvasRect.rect.yMax, localPoint.y);

        return normalizedX >= 0.5f && normalizedY >= 0f && normalizedY <= 1f;
    }

    // 🎨 UI 터치 영역 생성
    private void SetupRightTouchZoneUI()
    {
        if (rightTouchZoneUI != null)
            Destroy(rightTouchZoneUI.gameObject);

        Canvas[] canvases = Resources.FindObjectsOfTypeAll<Canvas>();
        Canvas canvas = null;
        foreach (var c in canvases)
        {
            if (c.isActiveAndEnabled)
            {
                canvas = c;
                break;
            }
        }

        if (canvas == null)
        {
            Debug.LogError("[CameraFollow] No active Canvas found!");
            return;
        }

        if (canvas.renderMode == RenderMode.ScreenSpaceCamera && canvas.worldCamera == null)
            canvas.worldCamera = Camera.main;

        uiCamera = canvas.renderMode == RenderMode.ScreenSpaceCamera ? canvas.worldCamera : null;

        GameObject touchPanel = new GameObject("RightTouchZone_UI", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        touchPanel.transform.SetParent(canvas.transform, false);

        Image img = touchPanel.GetComponent<Image>();
        img.color = new Color(0f, 0.3f, 1f, 0.15f);

        rightTouchZoneUI = touchPanel.GetComponent<RectTransform>();
        rightTouchZoneUI.anchorMin = new Vector2(0.5f, 0f);
        rightTouchZoneUI.anchorMax = new Vector2(1f, 1f);
        rightTouchZoneUI.offsetMin = Vector2.zero;
        rightTouchZoneUI.offsetMax = Vector2.zero;
    }

    // 초기 카메라 정렬용 함수
    private void FixCameraTransform()
    {
        pivot.position = target.position + pivotOffset;
        pivot.rotation = Quaternion.Euler(pivotFixedPitch, yaw, 0f);

        if (cam.parent != pivot) cam.SetParent(pivot, false);
        cam.localPosition = camLocalPosition;
        cam.localRotation = Quaternion.identity;
    }

    private void SafeLog(string msg, LogType type = LogType.Info)
    {
        if (StageLogPanel.Instance != null)
            StageLogPanel.Log(msg, type);
        else
            Debug.Log($"[CameraFollow] {msg}");
    }

    private bool IsStageScene()
    {
        string currentScene = SceneManager.GetActiveScene().name;
        return currentScene.StartsWith("Stage_") || currentScene.Contains("Stage");
    }
}