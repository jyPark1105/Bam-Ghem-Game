﻿using UnityEngine;

public class ItemScanner : MonoBehaviour
{
    [Header("Scan Settings")]
    public float scanMaxDistance = 0.5f;
    public float scanVerticalAngle = 90f;
    public float scanHorizontalAngle = 90f;
    public float scanSphereRadius = 2f;
    public LayerMask scanLayer;

    public Transform scanOrigin;

    public Item TryScanAndPickup()
    {
        if (scanOrigin == null) return null;

        // ✔ 아래로 약간 향하게 (30도)
        Vector3 baseDir = Quaternion.AngleAxis(30f, scanOrigin.right) * scanOrigin.forward;

        // ✔ 스캔 중심을 아래로 조금 내림 (코인 높이 맞추기)
        Vector3 center = scanOrigin.position + Vector3.down * 0.4f;

        Collider[] hits = Physics.OverlapSphere(
            center + baseDir * (scanMaxDistance * 0.5f),
            scanSphereRadius,
            scanLayer
        );

        if (hits.Length == 0) return null;

        Item bestItem = null;
        float bestDist = Mathf.Infinity;

        foreach (var hit in hits)
        {
            Vector3 dir = (hit.transform.position - center);
            float dist = dir.magnitude;

            if (dist > scanMaxDistance)
                continue;

            dir.Normalize();

            // ✔ 수평 각도
            float horiz = Vector3.SignedAngle(
                new Vector3(baseDir.x, 0, baseDir.z),
                new Vector3(dir.x, 0, dir.z),
                Vector3.up
            );

            if (Mathf.Abs(horiz) > scanHorizontalAngle * 0.5f)
                continue;

            // ✔ 수직 각도
            float vert = Vector3.SignedAngle(baseDir, dir, scanOrigin.right);

            if (Mathf.Abs(vert) > scanVerticalAngle * 0.5f)
                continue;

            // ✔ 가장 가까운 아이템
            if (dist < bestDist)
            {
                bestDist = dist;
                bestItem = hit.GetComponent<Item>();
            }
        }

        return bestItem;
    }

    private void OnDrawGizmos()
    {
        if (scanOrigin == null) return;

        Gizmos.color = new Color(1f, 0f, 1f, 0.3f);

        Vector3 origin = scanOrigin.position + Vector3.down * 0.6f;
        Vector3 baseDir = Quaternion.AngleAxis(30f, scanOrigin.right) * scanOrigin.forward;

        float halfH = scanHorizontalAngle * 0.5f;
        float halfV = scanVerticalAngle * 0.5f;

        int step = 20;

        for (int h = -step; h <= step; h++)
        {
            for (int v = -step; v <= step; v++)
            {
                float tH = Mathf.Lerp(-halfH, halfH, (h + step) / (float)(step * 2));
                float tV = Mathf.Lerp(-halfV, halfV, (v + step) / (float)(step * 2));

                Vector3 dir = Quaternion.AngleAxis(tH, Vector3.up) * baseDir;
                dir = Quaternion.AngleAxis(tV, scanOrigin.right) * dir;

                Gizmos.DrawLine(origin, origin + dir.normalized * scanMaxDistance);
            }
        }
    }
}