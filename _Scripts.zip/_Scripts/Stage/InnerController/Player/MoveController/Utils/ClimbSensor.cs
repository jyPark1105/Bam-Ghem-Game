using UnityEngine;

public class ClimbSensor : MonoBehaviour
{
    public LayerMask climbableLayer;

    public bool IsTouchingWall => CheckOverlap();
    public Collider CurrentWall { get; private set; }

    private bool CheckOverlap()
    {
        Vector3 center = transform.position;
        Vector3 halfExtents = transform.localScale * 0.5f;
        Quaternion rotation = transform.rotation;

        Collider[] hits = Physics.OverlapBox(center, halfExtents, rotation, climbableLayer);

        if (hits.Length > 0)
        {
            CurrentWall = hits[0]; // ���� ����� collider
            return true;
        }

        CurrentWall = null;
        return false;
    }

    public bool TryDetectWall(out Collider wall, out float hitY)
    {
        Vector3 center = transform.position;
        Vector3 halfExtents = transform.localScale * 0.5f;
        Quaternion rotation = transform.rotation;

        Collider[] hits = Physics.OverlapBox(center, halfExtents, rotation, climbableLayer);

        if (hits.Length > 0)
        {
            wall = hits[0];
            hitY = transform.position.y; // ���� ���� y = ���� ���� y
            return true;
        }

        wall = null;
        hitY = 0;
        return false;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.matrix = transform.localToWorldMatrix;
        Gizmos.DrawWireCube(Vector3.zero, Vector3.one);
    }
}