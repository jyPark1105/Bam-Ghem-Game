﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace StarterAssets
{
    public class UI_SkillIconController : MonoBehaviour
    {
        [Header("Target Images")]
        public Image skillAIconImage;
        public Image skillBIconImage;
        public Image skillCIconImage;
        public Image skillRIconImage;

        [Header("Skill A Icon Size")]
        public Vector2 skillA_NormalSize = new Vector2(100f, 100f);
        public Vector2 skillA_LargeSize = new Vector2(120f, 120f);

        [Header("References")]
        public PlayerAbsorbEffect absorbEffect;
        public Player_SkillBCtrl skillBCtrl;

        // =========================
        // Skill A Icons
        // =========================
        [Header("Skill A Icons")]
        public Sprite skillA_Red;
        public Sprite skillA_Green;
        public Sprite skillA_Blue;
        public Sprite skillA_Purple;

        // =========================
        // Skill B Icons
        // =========================
        [Header("Skill B Icons")]
        public Sprite skillB_Blue_1;
        public Sprite skillB_Blue_2;
        public Sprite skillB_Blue_3;

        public Sprite skillB_Red;
        public Sprite skillB_Green;
        public Sprite skillB_Purple;


        // =========================
        // Skill C Icon
        // =========================
        [Header("Skill C Icon")]
        public Sprite skillC_Red;
        public Sprite skillC_Green;
        public Sprite skillC_Blue;
        public Sprite skillC_Purple;

        // =========================
        // Skill R Icons
        // =========================
        [Header("Skill R Icons")]
        public Sprite skillR_Red;
        public Sprite skillR_Green;
        public Sprite skillR_Blue;
        public Sprite skillR_Purple;

        [Header("Icon Scale Pop Effect")]
        public float popDuration = 0.18f;
        public float popMinScale = 0.9f;
        public float popMaxScale = 1.1f;

        // 내부 상태 추적
        private PlayerAbsorbEffect.ColorType prevColor;
        private int prevComboIndex = -1;

        // ref 사용(코루틴 포인터 전달)
        private Coroutine skillAPopRoutine;
        private Coroutine skillBPopRoutine;
        private Coroutine skillCPopRoutine;
        private Coroutine skillRPopRoutine;

        private void Start()
        {
            ForceRefreshAll();
        }

        private void Update()
        {
            AutoRefresh();
        }

        // =================================================
        // 외부에서 호출하는 API
        // =================================================

        /// <summary>
        /// 속성 변경 직후 강제 갱신
        /// </summary>
        public void ForceRefreshAll()
        {
            RefreshSkillAIcon();
            RefreshSkillBIcon();
            RefreshSkillCIcon();
            RefreshSkillRIcon();

            prevColor = absorbEffect.colorType;
            prevComboIndex = GetComboIndex();
        }

        /// <summary>
        /// SkillB 콤보 변경 시 수동 호출 가능
        /// </summary>
        public void RefreshSkillBOnly()
        {
            RefreshSkillBIcon();
            prevComboIndex = GetComboIndex();
        }

        // =================================================
        // 자동 감지 (보험용)
        // =================================================
        private void AutoRefresh()
        {
            // 속성 변경 감지
            if (prevColor != absorbEffect.colorType)
            {
                RefreshSkillAIcon();
                RefreshSkillBIcon();
                RefreshSkillRIcon();
                prevColor = absorbEffect.colorType;
            }

            // Blue 콤보 변경 감지
            if (absorbEffect.colorType == PlayerAbsorbEffect.ColorType.Blue)
            {
                int combo = GetComboIndex();
                if (combo != prevComboIndex)
                {
                    RefreshSkillBIcon();
                    prevComboIndex = combo;
                }
            }
        }

        // =================================================
        // 실제 아이콘 갱신 로직
        // =================================================
        private void RefreshSkillAIcon()
        {
            if (skillAIconImage == null) return;

            // ❌ 속성 없음 → 아이콘 숨김
            if (absorbEffect.colorType == PlayerAbsorbEffect.ColorType.None)
            {
                skillAIconImage.gameObject.SetActive(false);
                return;
            }

            skillAIconImage.gameObject.SetActive(true);

            Sprite next = null;
            bool useLargeSize = false;

            switch (absorbEffect.colorType)
            {
                case PlayerAbsorbEffect.ColorType.Blue:
                    next = skillA_Blue;
                    useLargeSize = true;   // 🔵 Blue는 120
                    break;

                case PlayerAbsorbEffect.ColorType.Red:
                    next = skillA_Red;
                    useLargeSize = true;   // 🔴 Red는 120
                    break;

                case PlayerAbsorbEffect.ColorType.Green:
                    next = skillA_Green;
                    break;

                case PlayerAbsorbEffect.ColorType.Purple:
                    next = skillA_Purple;
                    break;
            }

            if (skillAIconImage.sprite != next)
            {
                skillAIconImage.sprite = next;

                // ✅ 크기 조절 (Scale 아님!)
                RectTransform rt = skillAIconImage.rectTransform;
                rt.sizeDelta = useLargeSize ? skillA_LargeSize : skillA_NormalSize;

                // 🔥 Pop 이펙트
                PlayPop(rt, ref skillAPopRoutine);
            }
        }

        private void RefreshSkillBIcon()
        {
            if (skillBIconImage == null) return;

            if (absorbEffect.colorType == PlayerAbsorbEffect.ColorType.None)
            {
                skillBIconImage.gameObject.SetActive(false);
                return;
            }

            skillBIconImage.gameObject.SetActive(true);

            Sprite next = null;
            var type = absorbEffect.colorType;

            if (type == PlayerAbsorbEffect.ColorType.Blue)
            {
                int combo = GetComboIndex();

                switch (combo)
                {
                    case 0:
                        next = skillB_Blue_1;
                        break;
                    case 1:
                        next = skillB_Blue_2;
                        break;
                    case 2:
                        next = skillB_Blue_3;
                        break;
                }
            }
            else
            {
                switch (type)
                {
                    case PlayerAbsorbEffect.ColorType.Red:
                        next = skillB_Red;
                        break;
                    case PlayerAbsorbEffect.ColorType.Green:
                        next = skillB_Green;
                        break;
                    case PlayerAbsorbEffect.ColorType.Purple:
                        next = skillB_Purple;
                        break;
                }
            }

            if (skillBIconImage.sprite != next)
            {
                skillBIconImage.sprite = next;

                // 🔥 Pop 이펙트
                PlayPop(skillBIconImage.rectTransform, ref skillBPopRoutine);
            }
        }

        private int GetComboIndex()
        {
            if (skillBCtrl == null)
                return 0;

            return skillBCtrl.GetSkillBComboIndexRaw();
        }

        // =================================================
        // 실제 아이콘 갱신 로직
        // =================================================
        private void RefreshSkillCIcon()
        {
            if (skillCIconImage == null) return;

            if (absorbEffect.colorType == PlayerAbsorbEffect.ColorType.None)
            {
                skillCIconImage.gameObject.SetActive(false);
                return;
            }

            Sprite next = null;

            switch (absorbEffect.colorType)
            {
                case PlayerAbsorbEffect.ColorType.Blue:
                    next = skillC_Blue;
                    break;

                case PlayerAbsorbEffect.ColorType.Red:
                    next = skillC_Red;
                    break;

                case PlayerAbsorbEffect.ColorType.Green:
                    next = skillC_Green;
                    break;

                case PlayerAbsorbEffect.ColorType.Purple:
                    next = skillC_Purple;
                    break;
            }

            if (skillCIconImage.sprite != next)
            {
                skillCIconImage.sprite = next;

                // 🔥 Pop 이펙트
                PlayPop(skillCIconImage.rectTransform, ref skillCPopRoutine);
            }
        }

        // =================================================
        // 실제 아이콘 갱신 로직
        // =================================================
        private void RefreshSkillRIcon()
        {
            if (skillRIconImage == null) return;

            if (absorbEffect.colorType == PlayerAbsorbEffect.ColorType.None)
            {
                skillRIconImage.gameObject.SetActive(false);
                return;
            }

            Sprite next = null;

            switch (absorbEffect.colorType)
            {
                case PlayerAbsorbEffect.ColorType.Blue:
                    next = skillR_Blue;
                    break;

                case PlayerAbsorbEffect.ColorType.Red:
                    next = skillR_Red;
                    break;

                case PlayerAbsorbEffect.ColorType.Green:
                    next = skillR_Green;
                    break;

                case PlayerAbsorbEffect.ColorType.Purple:
                    next = skillR_Purple;
                    break;
            }

            if (skillRIconImage.sprite != next)
            {
                skillRIconImage.sprite = next;

                // 🔥 Pop 이펙트
                PlayPop(skillRIconImage.rectTransform, ref skillRPopRoutine);
            }
        }

        private void PlayPop(RectTransform rt, ref Coroutine routine)
        {
            if (rt == null) return;

            if (routine != null)
                StopCoroutine(routine);

            routine = StartCoroutine(ScalePopRoutine(rt));
        }

        private IEnumerator ScalePopRoutine(RectTransform rt)
        {
            float half = popDuration * 0.5f;
            Vector3 baseScale = Vector3.one;

            // 0.9 → 1.1
            float t = 0f;
            while (t < half)
            {
                float p = t / half;
                float s = Mathf.Lerp(popMinScale, popMaxScale, EaseOutBack(p));
                rt.localScale = baseScale * s;

                t += Time.deltaTime;
                yield return null;
            }

            // 1.1 → 1.0
            t = 0f;
            while (t < half)
            {
                float p = t / half;
                float s = Mathf.Lerp(popMaxScale, 1f, p);
                rt.localScale = baseScale * s;

                t += Time.deltaTime;
                yield return null;
            }

            rt.localScale = baseScale;
        }

        private float EaseOutBack(float x)
        {
            const float c1 = 1.70158f;
            const float c3 = c1 + 1f;
            return 1 + c3 * Mathf.Pow(x - 1, 3) + c1 * Mathf.Pow(x - 1, 2);
        }
    }
}