using System.Collections.Generic;

public static class SkillACriticalTable
{
    private static readonly Dictionary<PlayerAbsorbEffect.ColorType, float> baseCritChance =
        new Dictionary<PlayerAbsorbEffect.ColorType, float>
    {
        { PlayerAbsorbEffect.ColorType.Red,    0.20f }, // 20%
        { PlayerAbsorbEffect.ColorType.Green,  0.25f }, // 5%
        { PlayerAbsorbEffect.ColorType.Blue,   0.10f }, // 10%
        { PlayerAbsorbEffect.ColorType.Purple, 0.15f }, // 15%
    };

    public static float GetBaseCrit(PlayerAbsorbEffect.ColorType type)
    {
        return baseCritChance.TryGetValue(type, out var v) ? v : 0.1f;
    }
}