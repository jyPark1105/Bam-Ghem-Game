using static PlayerAbsorbEffect;

public struct SkillADamageRatio
{
    public float physical;
    public float magic;
}

public static class SkillADamageRatioTable
{
    public static SkillADamageRatio GetRatio(ColorType type)
    {
        return type switch
        {
            ColorType.Red => new SkillADamageRatio { physical = 0.5f, magic = 0.25f },            
            ColorType.Green => new SkillADamageRatio { physical = 0f, magic = 0.35f },
            ColorType.Blue => new SkillADamageRatio { physical = 0.4f, magic = 0.3f },
            ColorType.Purple => new SkillADamageRatio { physical = 0.3f, magic = 0.4f },
            _ => new SkillADamageRatio { physical = 0f, magic = 0f },
        };
    }
}