using static PlayerAbsorbEffect;

public static class SkillAManaTable
{
    public static float GetCost(ColorType type)
    {
        switch (type)
        {
            case ColorType.Red:
                return 30f;

            case ColorType.Green:
                return 20f;

            case ColorType.Blue:
                return 20f;

            case ColorType.Purple:
                return 25f;

            default:
                return 20f;
        }
    }
}