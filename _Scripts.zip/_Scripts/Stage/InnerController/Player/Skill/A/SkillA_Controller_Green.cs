﻿using UnityEngine;

public class SkillA_Controller_Green : SkillA_Controller_Base
{
    protected override void Awake()
    {
        base.Awake();
    }

    public override void Activate()
    {
        // 🟢 Green 도트 데미지 공식 (초당)
        float dps =
            3f +
            0.35f * player.MagicATK;

        // Base는 damageInterval마다 damage를 주므로 변환
        damage = dps * damageInterval;

        // 지속시간 고정 5초
        lifeTime = 5f;

        // 공통 Activate
        base.Activate();

        AudioManager.Instance.PlaySkillA_Green();

        // 즉시 판정 (Blue와 동일)
        skillCollider.enabled = true;
    }
}