﻿//using UnityEngine;
//using System.Collections.Generic;
//using System.Linq;

//public abstract class SkillAPool_Base<T> : MonoBehaviour where T : SkillA_Controller_Base
//{
//    public static SkillAPool_Base<T> Instance;

//    public T skillPrefab;
//    public int maxCount = 3;

//    private Queue<T> pool = new Queue<T>();
//    private Queue<T> active = new Queue<T>();

//    protected virtual void Awake()
//    {
//        Instance = this;
//    }

//    public T Spawn(
//        Vector3 pos,
//        Quaternion rot,
//        PlayerStatus player,
//        PlayerAbsorbEffect absorb,
//        PlayerAugmentManager augment
//    )
//    {
//        T obj;

//        // Instantiate 최소화
//        // SetActive 기반 재사용
//        // GC / CPU / 메모리 모두 안정적
//        if (pool.Count > 0)
//        {
//            obj = pool.Dequeue();
//            obj.gameObject.SetActive(true);
//        }
//        else
//        {
//            obj = Instantiate(skillPrefab, pos, rot);
//        }

//        // 🔥 반드시 초기화
//        obj.ResetState();

//        if (active.Count >= maxCount)
//        {
//            T oldest = active.Dequeue();
//            oldest.Deactivate();
//        }

//        obj.transform.position = pos;
//        obj.transform.rotation = rot;

//        // 🔥 핵심: 반드시 주입
//        obj.SetPlayer(player, absorb, augment);

//        active.Enqueue(obj);
//        obj.Activate();
//        return obj;
//    }


//    public void ReturnObject(T obj)
//    {
//        obj.gameObject.SetActive(false);
//        active = new Queue<T>(active.Except(new[] { obj }));
//        pool.Enqueue(obj);
//    }
//}

using UnityEngine;
using System.Collections.Generic;

public abstract class SkillAPool_Base<T> : MonoBehaviour
    where T : SkillA_Controller_Base
{
    public static SkillAPool_Base<T> Instance;

    public T skillPrefab;
    public int maxCount = 3;

    private readonly Queue<T> pool = new();
    private readonly List<T> active = new();

    protected virtual void Awake()
    {
        Instance = this;
    }

    public T Spawn(
        Vector3 pos,
        Quaternion rot,
        PlayerStatus player,
        PlayerAbsorbEffect absorb,
        PlayerAugmentManager augment
    )
    {
        T obj;

        if (pool.Count > 0)
        {
            obj = pool.Dequeue();
            obj.gameObject.SetActive(true);
        }
        else
        {
            obj = Instantiate(skillPrefab);
        }

        obj.ResetState();

        // 🔥 최대 개수 초과 시 가장 오래된 것 제거
        if (active.Count >= maxCount)
        {
            T oldest = active[0];
            active.RemoveAt(0);
            oldest.Deactivate();   // 내부에서 ReturnObject 호출
        }

        obj.transform.SetPositionAndRotation(pos, rot);
        obj.SetPlayer(player, absorb, augment);

        active.Add(obj);
        obj.Activate();

        return obj;
    }

    public void ReturnObject(T obj)
    {
        if (obj == null) return;

        obj.gameObject.SetActive(false);
        active.Remove(obj);     // 🔥 GC 0
        pool.Enqueue(obj);
    }
}