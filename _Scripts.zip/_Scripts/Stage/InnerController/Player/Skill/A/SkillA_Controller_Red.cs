﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillA_Controller_Red : SkillA_Controller_Base
{
    [Header("Slash Move")]
    public float spawnOffset = 1f;
    public float moveSpeed = 10f;

    [Range(0.1f, 1f)]
    public float speedMultiplier = 0.33f; // 🔥 1/3 속도

    [Header("Red Skill")]
    public float activateDelay = 0.5f;
    public float colliderDelay = 0.2f;
    public float pullForce = 3f;

    private const float PULL_DURATION = 2f;
    private const float DOT_INTERVAL = 0.3f;
    private const float DOT_DAMAGE = 10f;
    private const float FINAL_DAMAGE = 100f;

    private readonly List<EnemyAI> insideEnemies = new();
    private float dotTimer;

    private Vector3 moveDir;
    private bool isMoving;
    private float cachedMoveSpeed;

    // 캐싱
    private Transform playerTransform;
    private Transform selfTransform;
    private WaitForSeconds lifeWait_ActivateDelay;
    private WaitForSeconds lifeWait_ColliderDelay;

    protected override void Awake()
    {
        base.Awake();
        
        selfTransform = transform;

        lifeWait_ActivateDelay = new WaitForSeconds(activateDelay);
        lifeWait_ColliderDelay = new WaitForSeconds(colliderDelay);
    }

    public override void Activate()
    {
        if (player == null)
        {
            Debug.LogError("SkillA_Red : player is null");
            return;
        }

        // 🔥 여기서 캐싱
        playerTransform = player.transform;

        base.Activate();

        cachedMoveSpeed = moveSpeed * speedMultiplier;

        selfTransform.position =
            playerTransform.position +
            playerTransform.forward * spawnOffset +
            Vector3.up * 0.02f;

        moveDir = playerTransform.forward.normalized;

        skillCollider.enabled = false;
        isMoving = true;

        StartCoroutine(RedRoutine());
    }

    protected override void Update()
    {
        base.Update();

        if (!isMoving) return;

        selfTransform.position +=
            moveDir * cachedMoveSpeed * Time.deltaTime;
    }

    private IEnumerator RedRoutine()
    {
        AudioManager.Instance.PlaySkillA_Red();

        yield return lifeWait_ActivateDelay;
        yield return lifeWait_ColliderDelay;

        skillCollider.enabled = true;

        float elapsed = 0f;
        dotTimer = 0f;

        while (elapsed < PULL_DURATION)
        {
            PullEnemies();

            dotTimer += Time.deltaTime;
            if (dotTimer >= DOT_INTERVAL)
            {
                ApplyDotDamage();
                dotTimer -= DOT_INTERVAL;
            }

            elapsed += Time.deltaTime;
            yield return null;
        }

        // 🔥 종료 처리
        isMoving = false;
        skillCollider.enabled = false;

        ApplyFinalDamage();
        ClearEnemies();

        Deactivate();
    }

    // =========================
    // Pull
    // =========================
    private void PullEnemies()
    {
        Vector3 center = selfTransform.position;

        for (int i = insideEnemies.Count - 1; i >= 0; i--)
        {
            EnemyAI enemy = insideEnemies[i];
            if (enemy == null || enemy.IsDead())
            {
                insideEnemies.RemoveAt(i);
                continue;
            }

            Transform enemyTr = enemy.transform;

            Vector3 dir = (center - enemyTr.position).normalized;
            enemyTr.position += dir * pullForce * Time.deltaTime;
        }
    }

    private void ApplyDotDamage()
    {
        foreach (EnemyAI enemy in insideEnemies)
        {
            if (enemy == null || enemy.IsDead()) continue;

            enemy.TakeDamage(new DamageInfo
            {
                physical = DOT_DAMAGE,
                magical = 0f,
                isCritical = false,
                damageType = DamageText.DamageType.Physical
            });
        }
    }

    private void ApplyFinalDamage()
    {
        foreach (EnemyAI enemy in insideEnemies)
        {
            if (enemy == null || enemy.IsDead()) continue;

            enemy.TakeDamage(new DamageInfo
            {
                physical = FINAL_DAMAGE,
                magical = 0f,
                isCritical = true,
                damageType = DamageText.DamageType.Physical
            });
        }
    }

    private void ClearEnemies()
    {
        insideEnemies.Clear();
    }

    // =========================
    // Trigger
    // =========================
    protected override void OnTriggerEnter(Collider other)
    {
        base.OnTriggerEnter(other);

        if (!other.CompareTag("Enemy")) return;

        EnemyAI e = other.GetComponent<EnemyAI>();
        if (e != null && !insideEnemies.Contains(e))
            insideEnemies.Add(e);
    }

    protected override void OnTriggerExit(Collider other)
    {
        base.OnTriggerExit(other);

        EnemyAI e = other.GetComponent<EnemyAI>();
        if (e != null)
            insideEnemies.Remove(e);
    }
}