﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using static UnityEngine.Rendering.HableCurve;

[RequireComponent(typeof(Collider))]
[RequireComponent(typeof(Rigidbody))]
public abstract class SkillA_Controller_Base : MonoBehaviour
{
    protected PlayerStatus player;
    protected PlayerAbsorbEffect absorb;
    protected PlayerAugmentManager augment;

    [Header("Base Settings")]
    public float lifeTime = 5f;

    [Header("Damage Settings")]
    public float damage = 10f;
    public float damageInterval = 0.5f;

    protected Collider skillCollider;
    protected Rigidbody rb;
    protected bool running = false;

    // Enemy마다 머무른 시간
    private Dictionary<EnemyAI, float> stayTime = new Dictionary<EnemyAI, float>();

    // 캐싱
    private WaitForSeconds lifeWait;

    // -------------------- 초기 세팅 --------------------
    protected virtual void Awake()
    {
        skillCollider = GetComponent<Collider>();
        rb = GetComponent<Rigidbody>();

        // 물리 영향 안 받고, 트리거만 처리
        rb.isKinematic = true;
        rb.useGravity = false;

        skillCollider.isTrigger = true;
        skillCollider.enabled = false;   // 기본은 꺼둔다 → 각 스킬에서 켜는 타이밍 제어

        lifeWait = new WaitForSeconds(lifeTime);
    }

    public virtual void SetPlayer(PlayerStatus ps, PlayerAbsorbEffect ae, PlayerAugmentManager am)
    {
        player = ps;
        absorb = ae;
        augment = am;
    }

    // -------------------- 공통 Activate --------------------
    public virtual void Activate()
    {
        running = true;
        stayTime.Clear();

        gameObject.SetActive(true);

        if (skillCollider != null)
            skillCollider.enabled = true; // ✅ 반드시 켜기

        StartCoroutine(LifeCycle());
    }

    protected virtual IEnumerator LifeCycle()
    {
        // 기본: lifeTime 후 종료 (자식에서 필요하면 override 가능)
        yield return lifeWait;
        Deactivate();
    }

    public virtual void Deactivate()
    {
        running = false;
        stayTime.Clear();
        
        StopAllCoroutines();

        if (skillCollider != null)
            skillCollider.enabled = false;

        gameObject.SetActive(false);
    }

    public virtual void ResetState()
    {
        running = false;
        stayTime.Clear();

        StopAllCoroutines();

        if (skillCollider != null)
            skillCollider.enabled = false;
    }

    // -------------------- 데미지 처리 --------------------
    protected virtual void Update()
    {
        if (!running) return;
        if (stayTime.Count == 0) return;

        var enemies = new List<EnemyAI>(stayTime.Keys);

        foreach (var enemy in enemies)
        {
            if (enemy == null)
            {
                stayTime.Remove(enemy);
                continue;
            }

            stayTime[enemy] += Time.deltaTime;

            if (stayTime[enemy] < damageInterval)
                continue;

            // =========================
            // 1️⃣ 크리티컬 계산
            // =========================
            var skillType = absorb.colorType;
            var absorbType = absorb.colorType;

            float baseCrit = SkillACriticalTable.GetBaseCrit(skillType);
            float bonusCrit = AbsorbCritBonusTable.GetBonus(absorbType);

            bool isCritical =
                Random.value < Mathf.Clamp01(baseCrit + bonusCrit);

            float finalDamage = CalculateSkillDamage(damage);
            if (isCritical)
                finalDamage *= 1.25f;

            // =========================
            // 2️⃣ 물리 / 마법 비율
            // =========================
            SkillADamageRatio ratio =
                SkillADamageRatioTable.GetRatio(skillType);

            float physical = finalDamage * ratio.physical;
            float magical = finalDamage * ratio.magic;

            // =========================
            // 3️⃣ 🔥 DamageType 결정
            // =========================
            DamageText.DamageType damageType =
                (physical > 0f && magical > 0f)
                    ? DamageText.DamageType.Hybrid
                    : (magical > 0f
                        ? DamageText.DamageType.Magical
                        : DamageText.DamageType.Physical);

            // =========================
            // 4️⃣ ✅ DamageInfo 생성
            // =========================
            DamageInfo info = new DamageInfo
            {
                physical = physical,
                magical = magical,
                isCritical = isCritical,
                damageType = damageType
            };

            // =========================
            // 5️⃣ Enemy에게 전달
            // =========================
            enemy.TakeDamage(info);
            enemy.TryPlayHitSound();

            stayTime[enemy] -= damageInterval;
        }
    }

    protected float CalculateSkillDamage(float baseDamage)
    {
        float physicalPart = player.PhysicalATK * 0.3f;
        float magicPart = player.MagicATK * 0.2f;

        float raw = baseDamage + physicalPart + magicPart;

        return raw * augment.skillDamageMultiplier;
    }

    protected virtual void OnTriggerEnter(Collider other)
    {
        if (!running) return;
        if (!other.CompareTag("Enemy")) return;

        EnemyAI e = other.GetComponent<EnemyAI>();
        if (e != null && !stayTime.ContainsKey(e))
            stayTime.Add(e, 0f);
    }

    protected virtual void OnTriggerExit(Collider other)
    {
        EnemyAI e = other.GetComponent<EnemyAI>();
        if (e != null && stayTime.ContainsKey(e))
            stayTime.Remove(e);
    }

    // EnemySkillHitbox.cs에서 사용되는 공개 메서드(몬스터 콜라이더 트리거 관련)
    public void OnEnemyEnter(EnemyAI enemy)
    {
        if (!stayTime.ContainsKey(enemy))
            stayTime.Add(enemy, 0f);
    }

    public void OnEnemyExit(EnemyAI enemy)
    {
        if (stayTime.ContainsKey(enemy))
            stayTime.Remove(enemy);
    }
}