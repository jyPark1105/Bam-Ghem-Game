using UnityEngine;
using UnityEngine.Rendering.Universal;

public class GroundSlashDecalController : MonoBehaviour
{
    public DecalProjector projector;

    [Header("Life")]
    public float lifeTime = 1.0f;
    public float fadeOutTime = 0.3f;

    private float timer;
    private float startFade;

    private void Awake()
    {
        if (projector == null)
            projector = GetComponent<DecalProjector>();

        startFade = projector.fadeFactor;
    }

    private void Update()
    {
        timer += Time.deltaTime;

        if (timer >= lifeTime - fadeOutTime)
        {
            float t =
                (timer - (lifeTime - fadeOutTime)) / fadeOutTime;

            projector.fadeFactor =
                Mathf.Lerp(startFade, 0f, t);
        }

        if (timer >= lifeTime)
        {
            Destroy(gameObject);
        }
    }
}