﻿using UnityEngine;
using System.Collections;
using StarterAssets;
using System.Collections.Generic;
using static PlayerAbsorbEffect;

public class SkillA_Controller_Blue : SkillA_Controller_Base
{
    [Header("Blue Hold Settings")]
    public float manaCostPerSecond = 6f;   // ✅ 초당 6
    public float tickDamage = 3f;

    private Player_SkillACtrl skillACtrl;
    private Coroutine holdRoutine;

    // 🔥 MP UI 갱신용 (0.25초)
    private float uiTickTimer;
    private const float UI_TICK_INTERVAL = 0.25f;

    private readonly List<EnemyAI> hitTargets = new();

    protected override void Awake()
    {
        base.Awake();
    }

    // 베이스 Update를 아예 안 타게 오버라이드
    protected override void Update()
    {
        // Blue는 HoldRoutine이 틱 데미지 담당
    }

    public void SetController(Player_SkillACtrl ctrl)
    {
        skillACtrl = ctrl;
    }

    public override void ResetState()
    {
        base.ResetState();

        if (holdRoutine != null)
        {
            StopCoroutine(holdRoutine);
            holdRoutine = null;
        }

        uiTickTimer = 0f;
        hitTargets.Clear();

        if (skillCollider != null)
            skillCollider.enabled = false;

        // 🔒 혹시 남아있을 Hold 상태 강제 해제
        if (skillACtrl != null)
            skillACtrl.SetSkillAHoldBusy(false);
    }

    public override void Activate()
    {
        damage = tickDamage;

        base.Activate();

        // 🔵 Blue Hold 시작
        if (skillACtrl != null)
            skillACtrl.SetSkillAHoldBusy(true);

        AudioManager.Instance.PlaySkillA_Blue();

        holdRoutine = StartCoroutine(HoldRoutine());
    }

    // ❌ Blue는 lifeTime 자동 종료 안 씀
    protected override IEnumerator LifeCycle()
    {
        yield break;
    }

    public override void Deactivate()
    {
        if (holdRoutine != null)
        {
            StopCoroutine(holdRoutine);
            holdRoutine = null;
        }

        hitTargets.Clear();

        base.Deactivate();

        // 🔴 Blue Hold 종료
        if (skillACtrl != null)
            skillACtrl.SetSkillAHoldBusy(false);

        // 🔥 손 뗐거나 마나 소진 → SkillA 쿨타임 시작
        if (skillACtrl != null)
        {
            float cd = SkillACooldownTable.GetFinalCooldown(
                ColorType.Blue,
                augment
            );

            skillACtrl.ForceStartCooldown(cd);
        }
    }



    protected override void OnTriggerEnter(Collider other)
    {
        if (!running) return;                 // ✅ activated -> running
        if (!other.CompareTag("Enemy")) return;

        // (너 코드 기준: EnemyAI가 자식에 붙는 경우가 많아서 InParent가 안전)
        EnemyAI enemy = other.GetComponentInParent<EnemyAI>();
        if (enemy == null) return;

        // IsDead()가 없다면 enemy.isDead 같은 걸로 바꿔
        if (enemy.IsDead()) return;

        if (!hitTargets.Contains(enemy))
            hitTargets.Add(enemy);
    }

    protected override void OnTriggerExit(Collider other)
    {
        EnemyAI enemy = other.GetComponentInParent<EnemyAI>();
        if (enemy != null)
            hitTargets.Remove(enemy);
    }

    private IEnumerator HoldRoutine()
    {
        float damageTick = 0f;

        while (true)
        {
            float cost = manaCostPerSecond * Time.deltaTime;
            if (!player.HasEnoughMana(cost))
                break;

            player.ConsumeMana(cost);

            // 🔥 데미지 틱 (0.25초)
            damageTick += Time.deltaTime;
            if (damageTick >= 0.25f)
            {
                damageTick = 0f;

                for (int i = hitTargets.Count - 1; i >= 0; i--)
                {
                    EnemyAI enemy = hitTargets[i];

                    if (enemy == null || enemy.IsDead())
                    {
                        hitTargets.RemoveAt(i);
                        continue;
                    }

                    // ✅ DealDamage 대신: 베이스의 계산 로직 재사용해서 enemy.TakeDamage(info)
                    ApplySkillADamageToEnemy(enemy, tickDamage);
                }
            }

            // 🔄 MP UI는 Hold 중에만 0.25초마다 갱신
            uiTickTimer += Time.deltaTime;
            if (uiTickTimer >= UI_TICK_INTERVAL)
            {
                uiTickTimer = 0f;
                UI_PlayerStatus.Instance?.SetMP(player.currentMP, player.MaxMP);
                UI_PlayerStatus.Instance?.ForceRefreshMP();
            }

            yield return null;
        }

        Deactivate();
    }

    // ✅ Blue 전용: 베이스의 "스킬 A 데미지 공식"을 그대로 써서 enemy.TakeDamage(info) 호출
    private void ApplySkillADamageToEnemy(EnemyAI enemy, float baseDamage)
    {
        // 1) 크리티컬
        var skillType = absorb.colorType;
        var absorbType = absorb.colorType;

        float baseCrit = SkillACriticalTable.GetBaseCrit(skillType);
        float bonusCrit = AbsorbCritBonusTable.GetBonus(absorbType);

        bool isCritical = Random.value < Mathf.Clamp01(baseCrit + bonusCrit);

        float finalDamage = CalculateSkillDamage(baseDamage);
        if (isCritical)
            finalDamage *= 1.25f;

        // 2) 물리/마법 비율
        SkillADamageRatio ratio = SkillADamageRatioTable.GetRatio(skillType);

        float physical = finalDamage * ratio.physical;
        float magical = finalDamage * ratio.magic;

        // 3) DamageType
        DamageText.DamageType damageType =
            (physical > 0f && magical > 0f)
                ? DamageText.DamageType.Hybrid
                : (magical > 0f
                    ? DamageText.DamageType.Magical
                    : DamageText.DamageType.Physical);

        // 4) DamageInfo 만들어 전달
        DamageInfo info = new DamageInfo
        {
            physical = physical,
            magical = magical,
            isCritical = isCritical,
            damageType = damageType
        };

        enemy.TakeDamage(info);
        //enemy.TryPlayHitSound();
    }
}