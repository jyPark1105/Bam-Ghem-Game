﻿using UnityEngine;
using static PlayerAbsorbEffect;

public static class SkillACooldownTable
{
    public static float GetBaseCooldown(ColorType type)
    {
        return type switch
        {
            ColorType.Red => 4f,
            ColorType.Green => 5f,
            ColorType.Blue => 3f,
            ColorType.Purple => 4f,
            _ => 3f
        };
    }

    // ✅ 증강 반영된 최종 쿨타임
    public static float GetFinalCooldown(
        ColorType type,
        PlayerAugmentManager augment
    )
    {
        float baseCd = GetBaseCooldown(type);
        float multiplier = augment != null ? augment.cooldownMultiplier : 1f;

        return Mathf.Max(0.1f, baseCd * multiplier);
    }
}