﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SkillA_Controller_Purple : SkillA_Controller_Base
{
    [Header("Purple Slash")]
    public GameObject purpleVFXPrefab;
    public float spawnOffset = 0.5f;
    public float moveSpeed = 5f;
    public float colliderStartTime = 0.1f;
    public float vfxDuration = 1.0f;

    [Header("Poison")]
    public float poisonDps = 5f; // 🔥 초당 독 데미지

    private Vector3 moveDir;
    private bool isMoving;

    // 🔥 Purple 전용
    private readonly List<EnemyAI> insideEnemies = new();

    private static readonly Color PURPLE_OUTLINE_COLOR =
        new Color(0.75f, 0.45f, 1.0f, 1f);

    private WaitForSeconds lifeWait_ColliderStart;
    private WaitForSeconds lifeWait_vfxDurationOffset;

    protected override void Awake()
    {
        base.Awake();

        lifeWait_ColliderStart = new WaitForSeconds(colliderStartTime);
        lifeWait_vfxDurationOffset = new WaitForSeconds(vfxDuration - colliderStartTime);
    }

    public override void Activate()
    {
        // 🟣 Purple 데미지 계산
        damage =
            6f +
            0.4f * player.PhysicalATK +
            0.4f * player.MagicATK;

        base.Activate();

        // =========================
        // 🔥 루트 위치 / 방향 확정
        // =========================
        Transform playerTr = player.transform;

        // 플레이어 forward 기준 앞쪽 위치
        Vector3 spawnPos =
            playerTr.position +
            playerTr.forward * spawnOffset;

        // Y축만 회전 (바닥에 평행)
        Quaternion spawnRot =
            Quaternion.Euler(0f, playerTr.eulerAngles.y, 0f);

        transform.SetPositionAndRotation(spawnPos, spawnRot);

        moveDir = playerTr.forward.normalized;

        // =========================
        // VFX 생성 (자식)
        // =========================
        GameObject vfx = Instantiate(purpleVFXPrefab, transform);
        vfx.transform.localPosition = Vector3.zero;
        vfx.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);

        isMoving = true;

        AudioManager.Instance.PlaySkillA_Purple();
        StartCoroutine(PurpleRoutine());
    }

    protected override void Update()
    {
        base.Update();

        if (isMoving)
        {
            transform.position +=
                moveDir * moveSpeed * Time.deltaTime;
        }

        ApplyPoisonDamage();
    }

    private IEnumerator PurpleRoutine()
    {
        skillCollider.enabled = false;

        yield return lifeWait_ColliderStart;
        skillCollider.enabled = true;

        yield return lifeWait_vfxDurationOffset;

        isMoving = false;
        Deactivate();
    }

    // =========================
    // 🔥 독 데미지 (초당 5)
    // =========================
    private void ApplyPoisonDamage()
    {
        if (insideEnemies.Count == 0) return;

        float dmg = poisonDps * Time.deltaTime;

        for (int i = insideEnemies.Count - 1; i >= 0; i--)
        {
            EnemyAI enemy = insideEnemies[i];
            if (enemy == null || enemy.IsDead())
            {
                RemoveEnemy(enemy);
                continue;
            }

            enemy.TakeDamage(new DamageInfo
            {
                physical = 0f,
                magical = dmg,
                isCritical = false,
                damageType = DamageText.DamageType.Magical
            });
        }
    }

    // =========================
    // Trigger
    // =========================
    protected override void OnTriggerEnter(Collider other)
    {
        base.OnTriggerEnter(other);

        if (!other.CompareTag("Enemy")) return;

        EnemyAI enemy = other.GetComponent<EnemyAI>();
        if (enemy == null) return;

        if (!insideEnemies.Contains(enemy))
        {
            insideEnemies.Add(enemy);

            // 🔥 연보라 아웃라인 ON
            Outline outline = enemy.GetComponent<Outline>();
            if (outline != null)
            {
                outline.OutlineColor = PURPLE_OUTLINE_COLOR;
                outline.enabled = true;
            }
        }
    }

    protected override void OnTriggerExit(Collider other)
    {
        if (!other.CompareTag("Enemy")) return;

        EnemyAI enemy = other.GetComponent<EnemyAI>();
        RemoveEnemy(enemy);
    }

    private void RemoveEnemy(EnemyAI enemy)
    {
        if (enemy == null) return;

        if (insideEnemies.Remove(enemy))
        {
            Outline outline = enemy.GetComponent<Outline>();
            if (outline != null)
                outline.enabled = false;
        }
    }

    public override void Deactivate()
    {
        // 🔥 남아있는 적들 정리
        foreach (var enemy in insideEnemies)
        {
            if (enemy == null) continue;

            Outline outline = enemy.GetComponent<Outline>();
            if (outline != null)
                outline.enabled = false;
        }

        insideEnemies.Clear();
        isMoving = false;

        base.Deactivate();
    }
}
