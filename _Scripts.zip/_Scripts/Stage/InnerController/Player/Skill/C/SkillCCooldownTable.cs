﻿using UnityEngine;
using static PlayerAbsorbEffect;

public static class SkillCCooldownTable
{
    public static float GetBaseCooldown(ColorType type)
    {
        return type switch
        {
            ColorType.Red => 10f,
            ColorType.Green => 10f,
            ColorType.Blue => 10f,
            ColorType.Purple => 10f,
            _ => 6f
        };
    }

    // ✅ 증강 반영된 최종 쿨타임
    public static float GetFinalCooldown(
        ColorType type,
        PlayerAugmentManager augment
    )
    {
        float baseCd = GetBaseCooldown(type);
        float multiplier = augment != null ? augment.cooldownMultiplier : 1f;

        return Mathf.Max(0.1f, baseCd * multiplier);
    }
}