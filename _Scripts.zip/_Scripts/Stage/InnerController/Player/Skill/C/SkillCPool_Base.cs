using UnityEngine;
using System.Collections.Generic;

public abstract class SkillCPool_Base<T> : MonoBehaviour
    where T : SkillC_Controller_Base
{
    public static SkillCPool_Base<T> Instance;

    public T skillPrefab;
    public int maxCount = 3;

    private readonly Queue<T> pool = new();
    private readonly List<T> active = new();

    protected virtual void Awake()
    {
        Instance = this;
    }

    public T Spawn(
        Vector3 pos,
        Quaternion rot,
        PlayerStatus player,
        PlayerAbsorbEffect absorb,
        PlayerAugmentManager augment
    )
    {
        T obj;

        if (pool.Count > 0)
        {
            obj = pool.Dequeue();
            obj.gameObject.SetActive(true);
        }
        else
        {
            obj = Instantiate(skillPrefab);
        }

        obj.ResetState();

        if (active.Count >= maxCount)
        {
            T oldest = active[0];
            active.RemoveAt(0);
            oldest.Deactivate();
        }

        obj.transform.position = pos + Vector3.up * obj.spawnHeight;
        obj.transform.rotation = rot;

        obj.SetPlayer(player, absorb, augment);

        active.Add(obj);
        obj.Activate();

        return obj;
    }

    public void ReturnObject(T obj)
    {
        obj.gameObject.SetActive(false);
        active.Remove(obj);
        pool.Enqueue(obj);
    }
}