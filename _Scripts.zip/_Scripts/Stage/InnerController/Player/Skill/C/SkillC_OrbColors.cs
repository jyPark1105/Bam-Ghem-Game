using UnityEngine;
using System;

[System.Serializable]
public class SkillC_OrbComponent
{
    public Color FrontColor;
    public Color BackColor;

    public Color FlareDarkColor;
    public Color FlareBrightColor;

    public Color ParticleColor;

    public SkillC_OrbComponent(Color front, Color back, Color flareDark, Color flareBright, Color particle)
    {
        FrontColor = front;
        BackColor = back;
        FlareDarkColor = flareDark;
        FlareBrightColor = flareBright;
        ParticleColor = particle;
    }
}
public static class SkillC_OrbColors
{
    // HSV ����
    const float S = 0.91f;
    const float V = 0.75f;

    // Intensity
    const float FrontIntensity = -1f;
    const float BackIntensity = 0.5f;
    const float FlareDarkIntensity = 0f;
    const float FlareBrightIntensity = 3.5f;
    const float ParticleIntensity = 7f;

    static Color HSV(float h)
    {
        return Color.HSVToRGB(h / 360f, S, V);
    }

    static SkillC_OrbComponent Build(float hue)
    {
        Color baseColor = HSV(hue);

        return new SkillC_OrbComponent(
            baseColor * FrontIntensity,
            baseColor * BackIntensity,
            baseColor * FlareDarkIntensity,
            baseColor * FlareBrightIntensity,
            baseColor * ParticleIntensity
        );
    }

    // =========================
    // R G B P ����
    // =========================

    public static readonly SkillC_OrbComponent Red = Build(358f);
    public static readonly SkillC_OrbComponent Green = Build(100f);
    public static readonly SkillC_OrbComponent Blue = Build(177f);
    public static readonly SkillC_OrbComponent Purple = Build(255f);
}