using static PlayerAbsorbEffect;

public static class SkillCManaTable
{
    public static float GetCost(ColorType type)
    {
        switch (type)
        {
            case ColorType.Red:
                return 30f;

            case ColorType.Green:
                return 30f;

            case ColorType.Blue:
                return 30f;

            case ColorType.Purple:
                return 30f;

            default:
                return 30f;
        }
    }
}