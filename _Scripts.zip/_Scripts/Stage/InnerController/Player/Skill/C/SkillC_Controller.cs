public class SkillC_Controller : SkillC_Controller_Base
{
    private StatusEffectType statusType;
    private float duration;

    public void Init(StatusEffectType type, float dur)
    {
        statusType = type;
        duration = dur;
    }

    protected override void ApplyStatus(
        EnemyStatusController enemy
    )
    {
        enemy.ApplyStatus(statusType, duration);
    }
}