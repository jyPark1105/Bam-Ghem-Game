using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(Collider))]
[RequireComponent(typeof(Rigidbody))]
public abstract class SkillC_Controller_Base : MonoBehaviour
{
    protected PlayerStatus player;
    protected PlayerAbsorbEffect absorb;
    protected PlayerAugmentManager augment;

    public float spawnHeight = 2f;
    public float lifeTime = 6f;

    protected Collider skillCollider;
    protected Rigidbody rb;

    protected bool active = false;

    // �̹� ���� ����� ���ʹ� �����ϱ� ���� �߰�
    private HashSet<EnemyStatusController> appliedEnemies
        = new HashSet<EnemyStatusController>();

    protected virtual void Awake()
    {
        skillCollider = GetComponent<Collider>();
        rb = GetComponent<Rigidbody>();

        skillCollider.isTrigger = true;
        skillCollider.enabled = false;

        rb.useGravity = true;
    }

    public virtual void SetPlayer(
        PlayerStatus ps,
        PlayerAbsorbEffect ae,
        PlayerAugmentManager am
    )
    {
        player = ps;
        absorb = ae;
        augment = am;
    }

    public virtual void Activate()
    {
        active = true;

        StartCoroutine(LifeCycle());
    }

    IEnumerator LifeCycle()
    {
        yield return new WaitForSeconds(lifeTime);

        Deactivate();
    }

    public virtual void Deactivate()
    {
        StopAllCoroutines();
        gameObject.SetActive(false);

        appliedEnemies.Clear();
    }

    public virtual void ResetState()
    {
        StopAllCoroutines();
        skillCollider.enabled = false;
        active = false;
    }

    protected virtual void OnCollisionEnter(Collision col)
    {
        if (!active) return;

        if (col.gameObject.CompareTag("Ground"))
        {
            rb.linearVelocity = Vector3.zero;
            rb.isKinematic = true;

            skillCollider.enabled = true;
        }
    }

    protected virtual void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Enemy")) return;

        EnemyStatusController status =
            other.GetComponent<EnemyStatusController>();

        if (status == null) return;

        if (appliedEnemies.Contains(status)) return;

        appliedEnemies.Add(status);

        ApplyStatus(status);
    }

    protected abstract void ApplyStatus(
        EnemyStatusController enemy
    );
}