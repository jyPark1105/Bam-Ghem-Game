using static PlayerAbsorbEffect;

public static class SkillRCriticalTable
{
    public static float GetBaseCrit(ColorType type)
    {
        switch (type)
        {
            case ColorType.Red: return 0.35f;
            case ColorType.Blue: return 0.35f;
            case ColorType.Green: return 0.30f;
            case ColorType.Purple: return 0.30f;
            default: return 0f;
        }
    }
}