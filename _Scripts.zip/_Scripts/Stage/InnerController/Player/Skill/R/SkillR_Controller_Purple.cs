﻿using UnityEngine;
using System.Collections;

public class SkillR_Controller_Purple : SkillR_Controller_Base
{
    [Header("Purple Objects")]
    public Transform sphere;

    [Header("Purple Materials")]
    public Material fresnelMat;
    public Material heatDistortionMat;

    [Header("Pull Settings")]
    public float pullStrength = 0.01f; // Red의 1/3

    public override void StartCasting()
    {
        Execute();
        skillRCtrl.OnSkillRCastingFinished();
    }

    public override void Execute()
    {
        Vector3 center = player.transform.position;

        AudioManager.Instance.PlaySkillR_Purple();

        // Area
        SkillRVFXPool.Instance.Spawn(
            SkillRVFXPool.SkillRVFXType.Area,
            new Vector3(center.x, 0f, center.z),
            Quaternion.identity,
            6f
        );

        player.StartCoroutine(PurpleSequence());
    }

    IEnumerator PurpleSequence()
    {
        Vector3 center = player.transform.position;

        Collider[] hits =
            Physics.OverlapSphere(center, radius, enemyMask);

        float time = 0f;

        Vector3 startScale = Vector3.one * 0.5f;
        Vector3 endScale = Vector3.one * 1f;

        while (time < 8f)
        {
            float dt = Time.deltaTime;
            time += dt;

            // =========================
            // 0~3초 연출
            // =========================
            if (time <= 3f)
            {
                float t = time / 3f;

                // Sphere Scale
                if (sphere != null)
                {
                    sphere.localScale =
                        Vector3.Lerp(startScale, endScale, t);
                }

                // Fresnel intensity
                float fresnelIntensity =
                    Mathf.Lerp(0f, 6.8f, t);

                fresnelMat.SetColor(
                    "_FresnelColor",
                    Color.white * fresnelIntensity
                );

                // Heat distortion
                float distortion =
                    Mathf.Lerp(0f, 1f, t);

                heatDistortionMat.SetFloat(
                    "_DistortionAmount",
                    distortion
                );
            }

            // =========================
            // 몬스터 흡입
            // =========================
            foreach (var hit in hits)
            {
                EnemyAI enemy =
                    hit.GetComponentInParent<EnemyAI>();

                if (enemy == null || enemy.IsDead())
                    continue;

                Vector3 pos = enemy.transform.position;

                Vector3 target =
                    new Vector3(center.x, pos.y, center.z);

                enemy.transform.position =
                    Vector3.Lerp(pos, target, pullStrength);
            }

            yield return null;
        }
    }
}