﻿using UnityEngine;

public class PooledVFX : MonoBehaviour
{
    private SkillRVFXPool owner;
    private float life;
    private float t;

    // ✅ string 제거 → enum만 사용
    public SkillRVFXPool.SkillRVFXType PoolType { get; private set; }

    /// <summary>
    /// preload / runtime 공통 초기화
    /// </summary>
    public void Init(SkillRVFXPool pool, SkillRVFXPool.SkillRVFXType type)
    {
        owner = pool;
        PoolType = type;
    }

    public void Play(float lifeTime)
    {
        life = Mathf.Max(0.01f, lifeTime);
        t = 0f;
        gameObject.SetActive(true);
    }

    private void Update()
    {
        // SkillR은 timeScale 제어하므로 unscaled 사용
        t += Time.unscaledDeltaTime;

        if (t >= life)
        {
            owner?.Return(this);
        }
    }
}