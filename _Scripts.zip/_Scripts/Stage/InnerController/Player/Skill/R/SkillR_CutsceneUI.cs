﻿using UnityEngine;

public class SkillR_CutsceneUI : MonoBehaviour
{
    [Header("References")]
    public Animator cutinAnimator;

    private static readonly int HideHash =
        Animator.StringToHash("Hide");

    private void Awake()
    {
        if (cutinAnimator == null)
            cutinAnimator = GetComponent<Animator>();

        // 처음엔 꺼진 상태로 시작
        gameObject.SetActive(false);
    }

    // =========================
    // 🔥 컷인 시작
    // =========================
    public void Play()
    {
        gameObject.SetActive(true);

        // Entry → Cutin_In 강제 시작
        cutinAnimator.Play("Cutin_In", 0, 0f);
    }

    // =========================
    // 🔥 컷인 종료 요청
    // =========================
    public void Hide()
    {
        if (!gameObject.activeSelf)
            return;

        cutinAnimator.SetTrigger(HideHash);
    }

    // =========================
    // 🔥 Cutin_Out 끝에서 호출됨
    // (Animation Event)
    // =========================
    public void OnCutinOutFinished()
    {
        gameObject.SetActive(false);
    }
}