﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SkillR_Controller_Blue : SkillR_Controller_Base
{
    [Header("Blue Ultimate")]
    public float duration = 6f;
    public float hitInterval = 0.12f;
    public float hitDamage = 8f;

    public override void StartCasting()
    {
        Execute();
        skillRCtrl.OnSkillRCastingFinished();
    }

    public override void Execute()
    {
        Vector3 center = player.transform.position;

        // Area VFX
        SkillRVFXPool.Instance.Spawn(
            SkillRVFXPool.SkillRVFXType.Area,
            new Vector3(center.x, 0f, center.z),
            Quaternion.identity,
            duration
        );

        player.StartCoroutine(BlueSequence());
    }

    private IEnumerator BlueSequence()
    {
        Vector3 center =
            player.transform.position +
            player.transform.forward * 1f;

        // =========================
        // 타겟 캐싱 (1회)
        // =========================
        Collider[] hits =
            Physics.OverlapSphere(center, radius, enemyMask);

        List<EnemyAI> targets = new(hits.Length);

        for (int i = 0; i < hits.Length; i++)
        {
            var col = hits[i];
            if (!col) continue;

            EnemyAI enemy = col.GetComponentInParent<EnemyAI>();

            if (enemy != null && !enemy.IsDead())
                targets.Add(enemy);
        }

        float elapsed = 0f;
        float hitTimer = 0f;

        // 🔊 사운드 타이머
        float soundTimer = 0f;

        while (elapsed < duration)
        {
            float dt = Time.deltaTime;

            elapsed += dt;
            hitTimer += dt;
            soundTimer += dt;

            // =========================
            // 1초마다 사운드
            // =========================
            if (soundTimer >= 1f)
            {
                soundTimer = 0f;
                AudioManager.Instance.PlaySkillR_Blue();
            }

            // =========================
            // 데미지 처리
            // =========================
            if (hitTimer >= hitInterval)
            {
                hitTimer = 0f;

                for (int i = 0; i < targets.Count; i++)
                {
                    EnemyAI enemy = targets[i];
                    if (enemy == null || enemy.IsDead())
                        continue;

                    DealDamage(enemy, hitDamage);
                }

                // 타격 연출
                SpawnExplosion(center, 1.5f);
            }

            yield return null;
        }
    }
}