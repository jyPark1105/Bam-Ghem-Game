﻿using UnityEngine;
using System.Collections.Generic;
using StarterAssets;

public class SkillR_CastingFX : MonoBehaviour
{
    [Header("DOT & Pull")]
    public float dotDamage = 5f;
    public float dotInterval = 0.5f;
    public float pullSpeed = 0.8f;

    [Header("Chain Arrows")]
    public GameObject chainArrowsPrefab;

    private Vector3 center;
    private ThirdPersonController playerController;
    private GameObject chainArrowsInstance;

    // 🔥 Enemy별 DOT 타이머
    private Dictionary<EnemyAI, float> dotTimers =
        new Dictionary<EnemyAI, float>();

    private void Start()
    {
        center = transform.position;

        // =========================
        // 🔥 Player 참조
        // =========================
        playerController = FindFirstObjectByType<ThirdPersonController>();

        if (playerController != null)
        {
            // 🔒 캐스팅 중 완전 고정
            playerController.SetBusy(true);
            playerController.DisableAllInputs();
        }

        // =========================
        // 🔥 Chain Arrows 생성
        // =========================
        if (chainArrowsPrefab != null)
        {
            Vector3 arrowPos = new Vector3(
                center.x,
                transform.position.y, // 캐스팅 높이 기준
                center.z
            );

            chainArrowsInstance =
                Instantiate(chainArrowsPrefab, arrowPos, Quaternion.identity);
        }
    }

    private void OnTriggerStay(Collider other)
    {
        EnemyAI enemy = other.GetComponentInParent<EnemyAI>();
        if (enemy == null || enemy.IsDead()) return;

        // =========================
        // 1️⃣ DOT (interval 기반)
        // =========================
        if (!dotTimers.ContainsKey(enemy))
            dotTimers[enemy] = dotInterval;

        dotTimers[enemy] -= Time.deltaTime;

        if (dotTimers[enemy] <= 0f)
        {
            enemy.TakeDamage(new DamageInfo
            {
                physical = 0,
                magical = dotDamage,
                isCritical = false,
                damageType = DamageText.DamageType.Magical
            });

            dotTimers[enemy] = dotInterval;
        }

        // =========================
        // 2️⃣ XZ 흡입 (Y 고정)
        // =========================
        Vector3 target =
            new Vector3(center.x, enemy.transform.position.y, center.z);

        enemy.transform.position =
            Vector3.Lerp(
                enemy.transform.position,
                target,
                pullSpeed * Time.deltaTime
            );
    }

    private void OnTriggerExit(Collider other)
    {
        EnemyAI enemy = other.GetComponentInParent<EnemyAI>();
        if (enemy == null) return;

        if (dotTimers.ContainsKey(enemy))
            dotTimers.Remove(enemy);
    }

    private void OnDestroy()
    {
        // =========================
        // 🔥 정리
        // =========================
        if (chainArrowsInstance != null)
            Destroy(chainArrowsInstance);

        if (playerController != null)
        {
            playerController.EnableAllInputs();
            playerController.SetBusy(false);
        }
    }
}