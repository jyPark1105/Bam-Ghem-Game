﻿using UnityEngine;
using System.Collections;
using StarterAssets;

public abstract class SkillR_Controller_Base : MonoBehaviour
{
    [Header("Skill R Settings")]
    public float radius = 5f;
    public LayerMask enemyMask;

    [Header("Ground / Wall Check")]
    public LayerMask groundMask;
    public LayerMask wallMask;
    public float skillRSpawnDistance = 1.0f;

    [Header("VFX")]
    public float vfxLifetime = 2f;

    public Player_SkillRCtrl skillRCtrl;

    protected ThirdPersonController pController;
    protected PlayerStatus player;
    protected PlayerAbsorbEffect absorb;

    // 🔥 NonAlloc 버퍼 (GC 0)
    private static readonly Collider[] enemyBuffer = new Collider[64];
    private static readonly EnemyAI[] enemyCache = new EnemyAI[64];
    private int enemyCount;

    // ==============================
    // Player Binding
    // ==============================
    public virtual void SetPlayer(
        ThirdPersonController pc,
        PlayerStatus ps,
        PlayerAbsorbEffect ae)
    {
        pController = pc;
        player = ps;
        absorb = ae;
    }

    public abstract void Execute();

    // ==============================
    // Casting Entry
    // ==============================
    public virtual void StartCasting()
    {
        player.StartCoroutine(CastingSequence());
    }

    // ==============================
    // Core Casting Logic
    // ==============================
    protected IEnumerator CastingSequence()
    {
        Vector3 center = CalculateSkillRSpawnPosition() + Vector3.up * 0.5f;

        // 🔥 타임 스케일 제어는 반드시 쌍으로
        ApplyTimeScale(0.5f);

        float castingDuration = 1.2f;
        float vfxLife = castingDuration + 0.25f;

        // ======================
        // VFX Spawn (Pool)
        // ======================
        SpawnCastingVFX(center, vfxLife);

        // ======================
        // Enemy Cache (1회)
        // ======================
        CacheEnemies(center);

        // 🔒 Suppression 시작 (1회)
        BeginSuppression();

        float elapsed = 0f;
        float dotTimer = 0f;
        float dotInterval = 0.25f;
        float pullStrength = 0.04f;

        while (elapsed < castingDuration)
        {
            float dt = Time.unscaledDeltaTime;
            elapsed += dt;
            dotTimer += dt;

            bool doDot = dotTimer >= dotInterval;

            for (int i = 0; i < enemyCount; i++)
            {
                EnemyAI enemy = enemyCache[i];
                if (enemy == null || enemy.IsDead()) continue;

                if (doDot)
                    DealDamage(enemy, 6f);

                // 🔥 XZ 축 흡입
                Vector3 pos = enemy.transform.position;
                Vector3 target =
                    new Vector3(center.x, pos.y, center.z);

                enemy.transform.position =
                    Vector3.Lerp(pos, target, pullStrength);
            }

            if (doDot) dotTimer = 0f;
            yield return null;
        }

        // 🔓 Suppression 종료
        EndSuppression();

        ApplyTimeScale(1f);

        Execute();
        skillRCtrl.OnSkillRCastingFinished();
    }

    // ==============================
    // Enemy Cache (GC 0)
    // ==============================
    private void CacheEnemies(Vector3 center)
    {
        enemyCount = Physics.OverlapSphereNonAlloc(
            center,
            radius,
            enemyBuffer,
            enemyMask
        );

        int write = 0;
        for (int i = 0; i < enemyCount; i++)
        {
            var col = enemyBuffer[i];
            if (!col) continue;

            var enemy = col.GetComponentInParent<EnemyAI>();
            if (enemy == null || enemy.IsDead()) continue;

            enemyCache[write++] = enemy;
        }

        enemyCount = write;
    }

    // ==============================
    // Suppression Control
    // ==============================
    private void BeginSuppression()
    {
        for (int i = 0; i < enemyCount; i++)
            enemyCache[i]?.BeginSkillRSuppression();
    }

    private void EndSuppression()
    {
        for (int i = 0; i < enemyCount; i++)
            enemyCache[i]?.EndSkillRSuppression();
    }

    // ==============================
    // Damage
    // ==============================
    protected void DealDamage(EnemyAI enemy, float damage)
    {
        SkillRDamageRatio ratio =
            SkillRDamageRatioTable.GetRatio(absorb.colorType);

        DamageInfo info = new DamageInfo
        {
            physical = damage * ratio.physical,
            magical = damage * ratio.magic,
            isCritical = false,
            damageType = DamageText.DamageType.Hybrid
        };

        // 🔥 궁극기 중엔 Lite 버전 사용
        enemy.TakeDamage_Lite(info);
    }

    // ==============================
    // Spawn Position Calculation
    // ==============================
    protected Vector3 CalculateSkillRSpawnPosition()
    {
        Vector3 origin =
            player.transform.position + Vector3.up * 0.2f;

        Vector3 forward = player.transform.forward;
        float maxDist = skillRSpawnDistance;

        Vector3 target = origin + forward * maxDist;

        if (Physics.Raycast(origin, forward,
            out RaycastHit wallHit, maxDist, wallMask))
        {
            target = wallHit.point - forward * 0.1f;
        }

        if (Physics.Raycast(
            target + Vector3.up * 2f,
            Vector3.down,
            out RaycastHit groundHit,
            5f,
            groundMask))
        {
            target.y = groundHit.point.y;
        }
        else
        {
            target.y = player.transform.position.y;
        }

        return target;
    }

    // ==============================
    // VFX Spawn Wrapper
    // ==============================
    protected void SpawnCastingVFX(Vector3 center, float life)
    {
        if (!SkillRVFXPool.IsReady || SkillRVFXPool.Instance == null)
        {
            Debug.LogWarning("[SkillR] VFXPool not ready (Casting)");
            return;
        }

        SkillRVFXPool.Instance.Spawn(
            SkillRVFXPool.SkillRVFXType.Casting,
            center,
            Quaternion.identity,
            life
        );

        SkillRVFXPool.Instance.Spawn(
            SkillRVFXPool.SkillRVFXType.Area,
            new Vector3(center.x, 0f, center.z),
            Quaternion.identity,
            life
        );
    }

    protected void SpawnExplosion(Vector3 center, float life = 2f)
    {
        if (!SkillRVFXPool.IsReady || SkillRVFXPool.Instance == null)
        {
            Debug.LogWarning("[SkillR] VFXPool not ready (Explosion)");
            return;
        }

        SkillRVFXPool.Instance.Spawn(
            SkillRVFXPool.SkillRVFXType.Explosion,
            center,
            Quaternion.identity,
            life
        );
    }

    // ==============================
    // TimeScale Helper (안전)
    // ==============================
    private void ApplyTimeScale(float scale)
    {
        Time.timeScale = scale;
        Time.fixedDeltaTime = 0.02f * scale;
    }

    // 연출 구조
    //protected IEnumerator CastingSequence()
    //{
    //    // =========================
    //    // 0️⃣ 캐스팅 기준 위치 계산
    //    // =========================
    //    Vector3 castingCenter = CalculateSkillRSpawnPosition();
    //    castingCenter += Vector3.up * 0.5f; // 캐스팅 연출용 높이 보정

    //    // =========================
    //    // 1️⃣ Casting 시작
    //    // =========================
    //    Time.timeScale = 0.5f;
    //    Time.fixedDeltaTime = 0.02f * Time.timeScale;

    //    GameObject castingObj = null;
    //    GameObject areaObj = null;

    //    if (castingPrefab != null)
    //        castingObj = Instantiate(castingPrefab, castingCenter, Quaternion.identity);

    //    if (areaPrefab != null)
    //    {
    //        Vector3 areaPos = new Vector3(
    //            castingCenter.x,
    //            areaPrefab.transform.position.y, // 프리팹 기준 Y
    //            castingCenter.z
    //        );

    //        areaObj = Instantiate(areaPrefab, areaPos, Quaternion.identity);
    //    }

    //    float castingDuration = 1.2f;
    //    float elapsed = 0f;

    //    float dotInterval = 0.25f;
    //    float dotTimer = 0f;
    //    float pullStrength = 0.04f;

    //    // 🔥 XZ 기준은 castingCenter
    //    Collider[] targets =
    //        Physics.OverlapSphere(castingCenter, radius, enemyMask);

    //    // =========================
    //    // 2️⃣ Casting 연출 루프
    //    // =========================
    //    while (elapsed < castingDuration)
    //    {
    //        float dt = Time.unscaledDeltaTime;
    //        elapsed += dt;
    //        dotTimer += dt;

    //        foreach (Collider col in targets)
    //        {
    //            if (col == null) continue;

    //            EnemyAI enemy = col.GetComponentInParent<EnemyAI>();
    //            if (enemy == null || enemy.IsDead()) continue;

    //            if (dotTimer >= dotInterval)
    //                DealDamage(enemy, 6f);

    //            // 🔥 XZ만 캐스팅 중심으로 흡입
    //            Vector3 pos = enemy.transform.position;
    //            Vector3 targetXZ =
    //                new Vector3(castingCenter.x, pos.y, castingCenter.z);

    //            enemy.transform.position =
    //                Vector3.Lerp(pos, targetXZ, pullStrength);
    //        }

    //        if (dotTimer >= dotInterval)
    //            dotTimer = 0f;

    //        yield return null;
    //    }

    //    // =========================
    //    // 3️⃣ Casting 종료
    //    // =========================
    //    Time.timeScale = 1.0f;
    //    Time.fixedDeltaTime = 0.02f;

    //    if (castingObj != null) Destroy(castingObj);
    //    if (areaObj != null) Destroy(areaObj);

    //    // =========================
    //    // 4️⃣ 실제 Skill R 발동
    //    // =========================
    //    Execute();
    //    pController.OnSkillRCastingFinished();
    //}
}