﻿using System.Collections.Generic;
using UnityEngine;

public class SkillRVFXPool : MonoBehaviour
{
    public static SkillRVFXPool Instance;
    public static bool IsReady { get; private set; }

    // =========================
    // 🔥 VFX Type (단일 진실)
    // =========================
    public enum SkillRVFXType
    {
        Casting,
        Area,
        Explosion
    }

    [System.Serializable]
    public class Entry
    {
        public SkillRVFXType type;
        public PooledVFX prefab;
        public int preload = 8;
    }

    public Entry[] entries;

    // =========================
    // Pools
    // =========================
    private readonly Dictionary<SkillRVFXType, Queue<PooledVFX>> pool = new();
    private readonly Dictionary<SkillRVFXType, PooledVFX> prefabMap = new();

    // =========================
    // Awake
    // =========================
    private void Awake()
    {
        Debug.Log($"[SkillRVFXPool] Awake on {gameObject.name}");

        // Singleton
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("[SkillRVFXPool] Duplicate detected → Destroy");
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        if (entries == null || entries.Length == 0)
        {
            Debug.LogError("[SkillRVFXPool] entries EMPTY");
            return;
        }

        // =========================
        // Init pools
        // =========================
        foreach (var e in entries)
        {
            if (e == null)
            {
                Debug.LogError("[SkillRVFXPool] Entry NULL");
                continue;
            }

            if (e.prefab == null)
            {
                Debug.LogError($"[SkillRVFXPool] Prefab NULL for {e.type}");
                continue;
            }

            prefabMap[e.type] = e.prefab;
            pool[e.type] = new Queue<PooledVFX>(e.preload);

            Debug.Log(
                $"[SkillRVFXPool] Register {e.type} | prefab={e.prefab.name} | preload={e.preload}"
            );

            // Preload
            for (int i = 0; i < e.preload; i++)
            {
                var obj = Instantiate(e.prefab, transform);
                obj.gameObject.SetActive(false);
                obj.Init(this, e.type);
                pool[e.type].Enqueue(obj);
            }
        }

        Debug.Log(
            $"[SkillRVFXPool] Ready. Types = {string.Join(", ", pool.Keys)}"
        );

        IsReady = true;
    }

    // =========================
    // Spawn
    // =========================
    public PooledVFX Spawn(
        SkillRVFXType type,
        Vector3 pos,
        Quaternion rot,
        float lifeTime)
    {
        if (!IsReady)
        {
            Debug.LogError("[SkillRVFXPool] Spawn before ready");
            return null;
        }

        if (!pool.TryGetValue(type, out var q))
        {
            Debug.LogError(
                $"[SkillRVFXPool] Pool missing type={type}"
            );
            return null;
        }

        if (!prefabMap.TryGetValue(type, out var prefab))
        {
            Debug.LogError(
                $"[SkillRVFXPool] Prefab missing type={type}"
            );
            return null;
        }

        var obj =
            q.Count > 0
            ? q.Dequeue()
            : Instantiate(prefab, transform);

        // 🔥 반드시 재주입 (preload / runtime 공통)
        obj.Init(this, type);

        obj.transform.SetPositionAndRotation(pos, rot);
        obj.Play(lifeTime);

        Debug.Log($"[SkillRVFXPool] Spawn {type} → {obj.name}");

        return obj;
    }

    // =========================
    // Return
    // =========================
    public void Return(PooledVFX vfx)
    {
        if (vfx == null)
        {
            Debug.LogError("[SkillRVFXPool] Return NULL");
            return;
        }

        if (!pool.TryGetValue(vfx.PoolType, out var q))
        {
            Debug.LogError(
                $"[SkillRVFXPool] Return failed type={vfx.PoolType}"
            );
            Destroy(vfx.gameObject);
            return;
        }

        vfx.gameObject.SetActive(false);
        vfx.transform.SetParent(transform);
        q.Enqueue(vfx);
    }
}