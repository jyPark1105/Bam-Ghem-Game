﻿using UnityEngine;
using System.Collections;

public class SkillR_Controller_Green : SkillR_Controller_Base
{
    [Header("Green Toxic System")]
    public Transform header;

    public Material toxicPipeMat;
    public Material toxicPuddleMat;

    public float duration = 6f;

    public override void StartCasting()
    {
        Execute();
        skillRCtrl.OnSkillRCastingFinished();
    }

    public override void Execute()
    {
        Vector3 center = player.transform.position;

        AudioManager.Instance.PlaySkillR_Green();

        // Area
        SkillRVFXPool.Instance.Spawn(
            SkillRVFXPool.SkillRVFXType.Area,
            new Vector3(center.x, 0f, center.z),
            Quaternion.identity,
            6f
        );

        player.StartCoroutine(GreenSequence());
    }

    IEnumerator GreenSequence()
    {
        float time = 0f;

        float pipeNormal = 0f;
        float pipeVoronoi = 0f;

        float puddleNormal = 0f;
        float puddleVoronoi = 0f;

        while (time < duration)
        {
            float dt = Time.deltaTime;
            time += dt;

            // -------------------------
            // Header Rotation (4초)
            // -------------------------
            if (header != null)
            {
                float rotT = Mathf.Clamp01(time / 4f);
                float y = rotT * 360f;

                header.localRotation =
                    Quaternion.Euler(0, -y, 0); // 반시계
            }

            // -------------------------
            // Pipe Material
            // 0~6초 Lerp
            // -------------------------
            float pipeT = Mathf.Clamp01(time / 6f);

            pipeNormal = Mathf.Lerp(0f, 0.5f, pipeT);
            pipeVoronoi = Mathf.Lerp(0f, 0.5f, pipeT);

            toxicPipeMat.SetFloat("_NormalSpeedY", pipeNormal);
            toxicPipeMat.SetFloat("_VoronoiSpeedY", pipeVoronoi);

            // -------------------------
            // Puddle Material
            // 2초 이후 시작
            // -------------------------
            if (time > 2f)
            {
                float puddleT = Mathf.Clamp01((time - 2f) / 4f);

                puddleNormal = Mathf.Lerp(0f, 0.5f, puddleT);
                puddleVoronoi = Mathf.Lerp(0f, 0.1f, puddleT);

                toxicPuddleMat.SetVector("_NormalSpeed",
                    new Vector2(0, puddleNormal));

                toxicPuddleMat.SetVector("_VoronoiSpeed",
                    new Vector2(0, puddleVoronoi));
            }

            yield return null;
        }
    }
}