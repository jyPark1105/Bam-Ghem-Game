﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SkillR_Controller_Red : SkillR_Controller_Base
{
    [Header("Red Ultimate Settings")]
    public float baseKnockbackForce = 10f;
    public float damageDelay = 0.25f;

    [Header("Pull Settings")]
    public float pullStrength = 0.03f;   // 기존의 1/3 수준

    [Header("Knockback Curve")]
    [SerializeField]
    private AnimationCurve knockbackCurve =
        AnimationCurve.EaseInOut(0f, 1f, 1f, 0.2f);

    public override void Execute()
    {
        Vector3 center = player.transform.position;

        AudioManager.Instance.PlaySkillR_Red();
        SpawnExplosion(center, 2f);

        HitStopManager.Instance?.Play(0.05f, 0.06f);

        Collider[] hits =
            Physics.OverlapSphere(center, radius, enemyMask);

        List<(EnemyAI enemy, float dmg)> delayed =
            new(hits.Length);

        foreach (var hit in hits)
        {
            EnemyAI enemy = hit.GetComponentInParent<EnemyAI>();
            if (enemy == null || enemy.IsDead()) continue;

            Vector3 pos = enemy.transform.position;

            // 🔴 중앙 흡입
            Vector3 target =
                new Vector3(center.x, pos.y, center.z);

            enemy.transform.position =
                Vector3.Lerp(pos, target, pullStrength);

            Vector3 diff = pos - center;

            float dist = diff.magnitude;
            float t = Mathf.Clamp01(dist / radius);

            float knockbackPower =
                knockbackCurve.Evaluate(1f - t) * baseKnockbackForce;

            enemy.ApplyKnockback(diff.normalized * knockbackPower);

            float damage = CalculateDistanceDamage(t);
            delayed.Add((enemy, damage));
        }

        if (delayed.Count > 0)
        {
            player.StartCoroutine(
                DealDamageBatchAfterDelay(delayed, damageDelay)
            );
        }
    }

    private IEnumerator DealDamageBatchAfterDelay(
        List<(EnemyAI enemy, float dmg)> list,
        float delay
    )
    {
        yield return new WaitForSeconds(delay);

        foreach (var item in list)
        {
            if (item.enemy == null || item.enemy.IsDead()) continue;

            DealDamage(item.enemy, item.dmg);
        }
    }

    private float CalculateDistanceDamage(float t)
    {
        return t * 100f;
    }
}