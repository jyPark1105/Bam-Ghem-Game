using static PlayerAbsorbEffect;

public struct SkillRDamageRatio
{
    public float physical;
    public float magic;
}

public static class SkillRDamageRatioTable
{
    public static SkillRDamageRatio GetRatio(ColorType type)
    {
        return type switch
        {
            ColorType.Red => new SkillRDamageRatio { physical = 0.7f, magic = 0.3f },
            ColorType.Green => new SkillRDamageRatio { physical = 0.5f, magic = 0.5f },
            ColorType.Blue => new SkillRDamageRatio { physical = 0.4f, magic = 0.6f },
            ColorType.Purple => new SkillRDamageRatio { physical = 0.3f, magic = 0.7f },
            _ => new SkillRDamageRatio { physical = 0f, magic = 0f },
        };
    }
}