using static PlayerAbsorbEffect;

public static class SkillRManaTable
{
    public static float GetCost(ColorType type)
    {
        switch (type)
        {
            case ColorType.Red:
            case ColorType.Green:
            case ColorType.Blue:
            case ColorType.Purple:
                return 50f;
            default:
                return 50f;
        }
    }
}