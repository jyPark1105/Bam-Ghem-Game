﻿using UnityEngine;
using static PlayerAbsorbEffect;

public static class SkillRCooldownTable
{
    public static float GetBaseCooldown(ColorType type)
    {
        return type switch
        {
            ColorType.Red => 45f,
            ColorType.Green => 35f,
            ColorType.Blue => 40f,
            ColorType.Purple => 40f,
            _ => 40f
        };
    }

    // ✅ 증강 반영된 최종 쿨타임
    public static float GetFinalCooldown(
        ColorType type,
        PlayerAugmentManager augment
    )
    {
        float baseCd = GetBaseCooldown(type);
        float multiplier = augment != null ? augment.cooldownMultiplier : 1f;

        return Mathf.Max(0.1f, baseCd * multiplier);
    }
}