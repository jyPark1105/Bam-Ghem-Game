using UnityEngine;

public class CharacterCutin_EventRelay : MonoBehaviour
{
    public SkillR_CutsceneUI owner;

    // Animation Event���� ȣ���
    public void OnCutinOutFinished()
    {
        owner?.OnCutinOutFinished();
    }
}