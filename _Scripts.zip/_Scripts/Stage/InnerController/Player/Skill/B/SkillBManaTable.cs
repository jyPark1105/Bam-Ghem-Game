using static PlayerAbsorbEffect;

public static class SkillBManaTable
{
    public static float GetCost(ColorType type)
    {
        switch (type)
        {
            case ColorType.Red:
                return 25f;

            case ColorType.Green:
                return 20f;

            case ColorType.Blue:
                return 30f;

            case ColorType.Purple:
                return 25f;

            default:
                return 20f;
        }
    }
}