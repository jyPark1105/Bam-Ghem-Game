public class SkillBPool_Green : SkillBPool_Base<SkillB_Controller_Green>
{
    public static SkillBPool_Green Instance;

    protected override void Awake()
    {
        Instance = this;
        base.Awake();
    }
}
