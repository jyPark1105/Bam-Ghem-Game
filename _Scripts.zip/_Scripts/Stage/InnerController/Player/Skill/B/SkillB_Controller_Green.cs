﻿public class SkillB_Controller_Green : SkillB_Controller_Base
{
    public override void Activate()
    {
        damage =
            10f +
            0.5f * playerStatus.MagicATK;

        base.Activate();
        AudioManager.Instance.PlaySkillB_Green();
    }
}