﻿using UnityEngine;

public class SkillBBillboardToCamera : MonoBehaviour
{
    private Camera mainCam;

    [Header("Mesh Rotation Offset")]
    [SerializeField] private float yawOffset = -90f;
    // 🔥 여기 값을 조절 (ex: -90, +90, +85 등)

    private Transform selfTransform;
    private Transform camTransform;

    private void Awake()
    {
        selfTransform = transform;
        mainCam = Camera.main;
        if (mainCam != null)
            camTransform = mainCam.transform;
    }

    private void LateUpdate()
    {
        if (mainCam == null) return;

        Vector3 dir =
            selfTransform.position - camTransform.position;

        dir.y = 0f; // 수직 고정

        Quaternion lookRot = Quaternion.LookRotation(dir);

        // 🔥 메쉬 기준 보정
        transform.rotation =
            lookRot * Quaternion.Euler(0f, yawOffset, 0f);
    }
}