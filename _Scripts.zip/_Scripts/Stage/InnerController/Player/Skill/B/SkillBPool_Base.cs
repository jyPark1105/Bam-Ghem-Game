﻿//using StarterAssets;
//using System.Collections.Generic;
//using UnityEngine;
//using System.Linq;

//public abstract class SkillBPool_Base<T> : MonoBehaviour, ISkillBPool
//    where T : SkillB_Controller_Base
//{
//    public static SkillBPool_Base<T> Instance;

//    public T prefab;
//    public int maxCount = 3;

//    protected Queue<T> pool = new();
//    protected Queue<T> active = new();

//    protected virtual void Awake()
//    {
//        Instance = this;
//    }

//    public virtual T Spawn(
//        Vector3 pos,
//        Quaternion rot,
//        ThirdPersonController playerController,
//        PlayerStatus playerStatus,
//        PlayerAbsorbEffect absorb
//    )
//    {
//        T obj;

//        if (pool.Count > 0)
//        {
//            obj = pool.Dequeue();
//            obj.gameObject.SetActive(true);
//        }
//        else
//        {
//            obj = Instantiate(prefab);
//        }

//        // 🔥 ownerPool 주입
//        obj.SetOwnerPool(this);

//        // 🔥 반드시 초기화
//        obj.ResetState();

//        if (active.Count >= maxCount)
//        {
//            T oldest = active.Dequeue();
//            oldest.Deactivate();
//        }

//        obj.transform.SetPositionAndRotation(pos, rot);
//        obj.SetPlayer(playerController, playerStatus, absorb);

//        active.Enqueue(obj);
//        obj.Activate();

//        return obj;
//    }

//    public void ReturnObject(SkillB_Controller_Base obj)
//    {
//        if (obj == null) return;

//        T casted = obj as T;
//        if (casted == null) return;

//        casted.gameObject.SetActive(false);

//        active = new Queue<T>(active.Where(x => x != casted));
//        pool.Enqueue(casted);
//    }
//}

using UnityEngine;
using System.Collections.Generic;
using StarterAssets;

public abstract class SkillBPool_Base<T> : MonoBehaviour, ISkillBPool
    where T : SkillB_Controller_Base
{
    public static SkillBPool_Base<T> Instance;

    public T prefab;
    public int maxCount = 3;

    protected readonly Queue<T> pool = new();
    protected readonly List<T> active = new();

    protected virtual void Awake()
    {
        Instance = this;
    }

    public virtual T Spawn(
        Vector3 pos,
        Quaternion rot,
        ThirdPersonController playerController,
        PlayerStatus playerStatus,
        PlayerAbsorbEffect absorb
    )
    {
        T obj;

        if (pool.Count > 0)
        {
            obj = pool.Dequeue();
            obj.gameObject.SetActive(true);
        }
        else
        {
            obj = Instantiate(prefab);
        }

        obj.SetOwnerPool(this);
        obj.ResetState();

        if (active.Count >= maxCount)
        {
            T oldest = active[0];
            active.RemoveAt(0);
            oldest.Deactivate();
        }

        obj.transform.SetPositionAndRotation(pos, rot);
        obj.SetPlayer(playerController, playerStatus, absorb);

        active.Add(obj);
        obj.Activate();

        return obj;
    }

    public void ReturnObject(SkillB_Controller_Base obj)
    {
        if (obj == null) return;

        T casted = obj as T;
        if (casted == null) return;

        casted.gameObject.SetActive(false);
        active.Remove(casted);   // 🔥 GC 0
        pool.Enqueue(casted);
    }
}