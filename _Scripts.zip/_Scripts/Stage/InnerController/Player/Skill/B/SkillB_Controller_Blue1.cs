﻿public class SkillB_Controller_Blue1 : SkillB_Controller_BlueBase
{
    protected override float CalculateDamage()
    {
        return 4f
             + 0.08f * playerStatus.PhysicalATK
             + 0.2f * playerStatus.MagicATK;
    }
}