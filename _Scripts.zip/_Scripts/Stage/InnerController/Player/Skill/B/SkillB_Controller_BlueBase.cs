﻿using UnityEngine;

public abstract class SkillB_Controller_BlueBase : SkillB_Controller_Base
{
    protected abstract float CalculateDamage();

    public override void Activate()
    {
        damage = CalculateDamage();
        base.Activate();

        AudioManager.Instance.PlaySkillB_Blue();
    }
}
