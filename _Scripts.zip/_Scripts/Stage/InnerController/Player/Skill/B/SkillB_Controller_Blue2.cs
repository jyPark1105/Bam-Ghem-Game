﻿public class SkillB_Controller_Blue2 : SkillB_Controller_BlueBase
{
    protected override float CalculateDamage()
    {
        return 6f
             + 0.12f * playerStatus.PhysicalATK
             + 0.3f * playerStatus.MagicATK;
    }
}