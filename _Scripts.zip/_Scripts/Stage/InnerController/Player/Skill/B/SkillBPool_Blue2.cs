public class SkillBPool_Blue2 : SkillBPool_Base<SkillB_Controller_BlueBase>
{
    public static SkillBPool_Blue2 Instance;

    protected override void Awake()
    {
        Instance = this;
        base.Awake();
    }
}
