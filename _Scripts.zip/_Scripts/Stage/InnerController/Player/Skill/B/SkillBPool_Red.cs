public class SkillBPool_Red : SkillBPool_Base<SkillB_Controller_Red>
{
    public static SkillBPool_Red Instance;

    protected override void Awake()
    {
        Instance = this;
        base.Awake();
    }
}
