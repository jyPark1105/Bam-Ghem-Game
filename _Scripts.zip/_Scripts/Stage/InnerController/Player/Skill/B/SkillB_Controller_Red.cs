﻿using UnityEngine;

public class SkillB_Controller_Red : SkillB_Controller_Base
{
    [SerializeField] private float spawnHeight = 0.7f;
    [SerializeField] private float cameraForwardOffset = 1f; // 🔥 핵심

    private static Camera cachedMainCam;

    protected override void Awake()
    {
        if (cachedMainCam == null)
            cachedMainCam = Camera.main;
    }

    public override void Activate()
    {
        damage =
            15f +
            0.3f * playerStatus.PhysicalATK;

        base.Activate();
        AudioManager.Instance.PlaySkillB_Red();
    }

    public void SetPositionOnEnemy(Transform enemy)
    {
        Camera cam = cachedMainCam;
        if (cam == null)
        {
            transform.position =
                enemy.position + Vector3.up * spawnHeight;
            return;
        }

        // 🔥 몬스터 → 카메라 방향
        Vector3 toCamera =
            (cam.transform.position - enemy.position).normalized;

        // 🔥 카메라 쪽으로 살짝 당김
        Vector3 spawnPos =
            enemy.position
            + Vector3.up * spawnHeight
            + toCamera * cameraForwardOffset;

        transform.position = spawnPos;
    }
}