public class SkillBPool_Blue3 : SkillBPool_Base<SkillB_Controller_BlueBase>
{
    public static SkillBPool_Blue3 Instance;

    protected override void Awake()
    {
        Instance = this;
        base.Awake();
    }
}