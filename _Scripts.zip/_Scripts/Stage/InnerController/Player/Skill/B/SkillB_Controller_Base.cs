﻿using StarterAssets;
using UnityEngine;
using System.Collections;

public abstract class SkillB_Controller_Base : MonoBehaviour
{
    [Header("SkillB Life Time")]
    public float lifeTime = 1.0f;

    protected ThirdPersonController playerController;
    protected PlayerStatus playerStatus;
    protected PlayerAbsorbEffect absorb;

    protected Collider skillCollider;
    protected Rigidbody rb;

    protected float damage;
    protected bool activated;

    // 🔥 자신을 관리하는 Pool
    protected ISkillBPool ownerPool;

    // 캐싱
    protected Transform selfTransform;
    private WaitForSeconds lifeWait;

    protected virtual void Awake()
    {
        selfTransform = transform;

        skillCollider = GetComponent<Collider>();
        rb = GetComponent<Rigidbody>();

        skillCollider.isTrigger = true;
        rb.isKinematic = true;
        rb.useGravity = false;

        skillCollider.enabled = false;

        lifeWait = new WaitForSeconds(lifeTime);
    }

    protected virtual void OnEnable()
    {
        if (!activated) return;

        StartCoroutine(EnableColliderNextFrame());
        StartCoroutine(LifeRoutine());
    }

    // =========================
    // 활성화
    // =========================
    public virtual void Activate()
    {
        activated = true;

        // ❗ 코루틴 직접 실행 금지
        // StartCoroutine 제거
    }

    // 🔥 Pool에서 반드시 주입
    public void SetOwnerPool(ISkillBPool pool)
    {
        ownerPool = pool;
    }

    public virtual void SetPlayer(
        ThirdPersonController controller,
        PlayerStatus status,
        PlayerAbsorbEffect absorbEffect
    )
    {
        playerController = controller;
        playerStatus = status;
        absorb = absorbEffect;
    }


    private IEnumerator EnableColliderNextFrame()
    {
        yield return null; // 1 frame
        if (skillCollider != null)
            skillCollider.enabled = true;
    }

    private IEnumerator LifeRoutine()
    {
        yield return lifeWait;
        Deactivate();
    }

    // =========================
    // 충돌 → 데미지
    // =========================
    protected virtual void OnTriggerEnter(Collider other)
    {
        if (!activated) return;
        if (!other.CompareTag("Enemy")) return;

        EnemyAI enemy = other.GetComponentInParent<EnemyAI>();
        if (enemy == null || enemy.IsDead()) return;

        DealDamage(enemy);
    }

    protected virtual void DealDamage(EnemyAI enemy)
    {
        var type = absorb.colorType;

        float baseCrit = SkillBCriticalTable.GetBaseCrit(type);
        bool isCritical = Random.value < baseCrit;

        float finalDamage = isCritical ? damage * 1.25f : damage;

        SkillBDamageRatio ratio =
            SkillBDamageRatioTable.GetRatio(type);

        enemy.TakeDamage(new DamageInfo
        {
            physical = finalDamage * ratio.physical,
            magical = finalDamage * ratio.magic,
            isCritical = isCritical,
            damageType = DamageText.DamageType.Hybrid
        });

        enemy.TryPlayHitSound();
    }

    // =========================
    // Pool 반환
    // =========================
    public virtual void Deactivate()
    {
        activated = false;

        StopAllCoroutines();

        if (skillCollider != null)
            skillCollider.enabled = false;

        ownerPool?.ReturnObject(this);
    }

    // 재사용 전용 초기화 함수
    public virtual void ResetState()
    {
        activated = false;

        StopAllCoroutines();

        if (skillCollider != null)
            skillCollider.enabled = false;
    }
}