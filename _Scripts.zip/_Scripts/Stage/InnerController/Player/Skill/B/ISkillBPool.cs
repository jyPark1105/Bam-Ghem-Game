public interface ISkillBPool
{
    void ReturnObject(SkillB_Controller_Base obj);
}