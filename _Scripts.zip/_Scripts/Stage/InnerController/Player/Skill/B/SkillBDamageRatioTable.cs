using static PlayerAbsorbEffect;

public struct SkillBDamageRatio
{
    public float physical;
    public float magic;
}

public static class SkillBDamageRatioTable
{
    public static SkillBDamageRatio GetRatio(ColorType type)
    {
        return type switch
        {
            ColorType.Red => new SkillBDamageRatio { physical = 0.3f, magic = 0f },
            ColorType.Green => new SkillBDamageRatio { physical = 0f, magic = 0.5f },
            ColorType.Blue => new SkillBDamageRatio { physical = 0.15f, magic = 0.3f },
            ColorType.Purple => new SkillBDamageRatio { physical = 0.2f, magic = 0.25f },
            _ => new SkillBDamageRatio { physical = 0f, magic = 0f },
        };
    }
}