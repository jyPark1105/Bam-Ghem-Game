﻿public class SkillB_Controller_Blue3 : SkillB_Controller_BlueBase
{
    protected override float CalculateDamage()
    {
        return 8f
             + 0.15f * playerStatus.PhysicalATK
             + 0.35f * playerStatus.MagicATK;
    }
}