public class SkillBPool_Blue1 : SkillBPool_Base<SkillB_Controller_BlueBase>
{
    public static SkillBPool_Blue1 Instance;

    protected override void Awake()
    {
        Instance = this;
        base.Awake();
    }
}