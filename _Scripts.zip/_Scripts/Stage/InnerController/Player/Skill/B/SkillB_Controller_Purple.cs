﻿using UnityEngine;
using System.Collections;

public class SkillB_Controller_Purple : SkillB_Controller_Base
{
    [Header("Purple Collider Expand")]
    [SerializeField] private BoxCollider box1; // Z 확장
    [SerializeField] private BoxCollider box2; // X 확장

    private readonly Vector3 baseCenter = new Vector3(0f, 0.25f, 0f);
    private readonly Vector3 baseSize = new Vector3(0.3f, 0.5f, 0.3f);

    private const float expandedSize = 1.2f;

    public override void Activate()
    {
        damage =
            12f +
            0.2f * playerStatus.PhysicalATK +
            0.25f * playerStatus.MagicATK;

        // 🔥 콜라이더 초기화
        InitColliders();

        base.Activate();

        AudioManager.Instance.PlaySkillB_Purple();

        // 🔥 Purple 전용 확장 연출
        StartCoroutine(ExpandColliderRoutine());
    }

    private void InitColliders()
    {
        if (box1 != null)
        {
            box1.center = baseCenter;
            box1.size = baseSize;
        }

        if (box2 != null)
        {
            box2.center = baseCenter;
            box2.size = baseSize;
        }
    }

    private IEnumerator ExpandColliderRoutine()
    {
        float elapsed = 0f;
        float duration = lifeTime; // 0.75초

        while (elapsed < duration)
        {
            float t = elapsed / duration;

            if (box1 != null)
            {
                Vector3 size = baseSize;
                size.z = Mathf.Lerp(0.3f, expandedSize, t);
                box1.size = size;
            }

            if (box2 != null)
            {
                Vector3 size = baseSize;
                size.x = Mathf.Lerp(0.3f, expandedSize, t);
                box2.size = size;
            }

            elapsed += Time.deltaTime;
            yield return null;
        }

        // 🔥 마지막 값 보정 (정확히 1.2)
        if (box1 != null)
            box1.size = new Vector3(0.3f, 0.5f, expandedSize);

        if (box2 != null)
            box2.size = new Vector3(expandedSize, 0.5f, 0.3f);
    }

    public override void Deactivate()
    {
        base.Deactivate();

        // 🔥 풀 반환 전 초기화
        InitColliders();
    }
}