public class SkillBPool_Purple : SkillBPool_Base<SkillB_Controller_Purple>
{
    public static SkillBPool_Purple Instance;

    protected override void Awake()
    {
        Instance = this;
        base.Awake();
    }
}
