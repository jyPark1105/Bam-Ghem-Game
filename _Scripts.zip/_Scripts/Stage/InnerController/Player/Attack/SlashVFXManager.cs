﻿using UnityEngine;
using static PlayerAbsorbEffect;

public class SlashVFXManager : MonoBehaviour
{
    [Header("None")]
    public SlashVFXController none_L;
    public SlashVFXController none_R;

    [Header("Red")]
    public SlashVFXController red_L;
    public SlashVFXController red_R;

    [Header("Green")]
    public SlashVFXController green_L;
    public SlashVFXController green_R;

    [Header("Blue")]
    public SlashVFXController blue_L;
    public SlashVFXController blue_R;

    [Header("Purple")]
    public SlashVFXController purple_L;
    public SlashVFXController purple_R;

    private void Awake()
    {
        InitAll();
    }

    private void InitAll()
    {
        Init(none_L);
        Init(none_R);

        Init(red_L);
        Init(red_R);

        Init(green_L);
        Init(green_R);

        Init(blue_L);
        Init(blue_R);

        Init(purple_L);
        Init(purple_R);
    }

    private void Init(SlashVFXController vfx)
    {
        if (vfx == null) return;

        vfx.transform.SetParent(transform, false);
        vfx.SetHomeParent(transform);
    }

    public void PlaySlash(
        ColorType color,
        bool isRightAttack,
        AttackDetector detector
    )
    {
        SlashVFXController target = Get(color, isRightAttack);
        if (target == null) return;

        target.Play(detector);
    }

    private SlashVFXController Get(ColorType color, bool isRight)
    {
        return color switch
        {
            ColorType.Red => isRight ? red_R : red_L,
            ColorType.Green => isRight ? green_R : green_L,
            ColorType.Blue => isRight ? blue_R : blue_L,
            ColorType.Purple => isRight ? purple_R : purple_L,
            _ => isRight ? none_R : none_L,
        };
    }
}