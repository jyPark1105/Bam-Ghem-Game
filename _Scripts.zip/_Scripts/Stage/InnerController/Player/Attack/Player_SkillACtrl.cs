﻿using UnityEngine;
using StarterAssets;
using static PlayerAbsorbEffect;

public class Player_SkillACtrl : MonoBehaviour
{
    [Header("References")]
    private ThirdPersonController controller;
    private PlayerStatus playerStatus;
    private PlayerAugmentManager augment;
    private PlayerAbsorbEffect absorb;
    public PlayerAbsorbEffect Absorb => absorb;

    private Animator animator;

    [Header("Skill A Spawn")]
    public LayerMask groundMask;
    public LayerMask wallMask;
    public float spawnDistance = 1.5f;

    [Header("Blue Hold")]
    [SerializeField] private float blueHoldMoveMultiplier = 0.7f;
    private SkillA_Controller_Blue activeBlueSkill;
    private bool isBlueHoldActive;
    public bool IsSkillAHoldBusy { get; private set; }

    // Cooldown
    private float skillACooldownTimer = 0f;
    private float skillACooldownDuration = 0f;
    public bool IsSkillACooldown => skillACooldownTimer > 0f;
    public float SkillACooldownDuration => skillACooldownDuration;
    public float SkillACooldownRatio =>
        skillACooldownDuration <= 0f ? 0f : skillACooldownTimer / skillACooldownDuration;

    private StarterAssetsInputs input;

    private bool bufferSkillA;

    private void Awake()
    {
        controller = GetComponent<ThirdPersonController>();
        playerStatus = GetComponent<PlayerStatus>();
        absorb = GetComponent<PlayerAbsorbEffect>();
        augment = GetComponent<PlayerAugmentManager>();
        input = GetComponent<StarterAssetsInputs>();
        animator = GetComponent<Animator>();
    }

    private void Start()
    {
        absorb.OnAbsorbReady += OnAbsorbReady;
    }

    private void OnAbsorbReady()
    {
        if (bufferSkillA)
        {
            bufferSkillA = false;
            ExecuteSkillA();
        }
    }

    public void Tick()
    {
        if (!controller.IsPlayerReady)
            return;

        // 쿨타임 감소
        if (skillACooldownTimer > 0f)
            skillACooldownTimer -= Time.deltaTime;

        HandleSkillA();
    }

    private void ExecuteSkillA()
    {
        // 🔒 방어 코드 (이중 실행 방지용)
        if (controller.IsBusy) return;
        if (!controller.isGrounded) return;
        if (absorb.colorType == ColorType.None) return;
        if (IsSkillACooldown) return;

        var type = absorb.colorType;
        float manaCost = SkillAManaTable.GetCost(type);
        if (!playerStatus.HasEnoughMana(manaCost))
        {
            DebugStateAnimator_InStage.Instance.AnimateAll(GameMessage.NO_MANA);
            AudioManager.Instance.PlaySkillUnavailable();
            return;
        }

        // 🔥 실제 실행부
        playerStatus.ConsumeMana(manaCost);
        StartCooldown(type);

        controller.SetBusy(true);
        controller.Animator.SetTrigger("SkillA");
    }

    private void HandleSkillA()
    {
        var type = absorb.colorType;

        // 속성 없으면 무시
        if (type == ColorType.None)
        {
            input.skillA = false;
            return;
        }

        // =========================
        // 🔵 Blue (Hold Skill)
        // =========================
        if (type == ColorType.Blue)
        {
            HandleBlueHold();
            return;
        }

        // =========================
        // 🔴 Red / 🟢 Green / 🟣 Purple (1회성)
        // =========================
        if (!input.skillA)
            return;

        if (!controller.isGrounded || controller.IsBusy)
        {
            input.skillA = false;
            return;
        }

        ExecuteSkillA();

        // 🔥 1회성은 즉시 false 처리 (연타 방지)
        input.skillA = false;
    }

    // ============================
    // 🔵 Blue Hold
    // ============================
    private void HandleBlueHold()
    {
        if (input.skillA)
        {
            if (activeBlueSkill == null)
            {
                if (!playerStatus.HasEnoughMana(1f))
                    return;

                controller.SetBusy(true);
                controller.Animator.SetBool("IsSkillABlueHold", true);

                Vector3 pos = CalcBlueHoldPos();
                Quaternion rot = Quaternion.LookRotation(transform.forward);

                activeBlueSkill =
                    SkillAPool_Blue.Instance.Spawn(
                        pos, rot,
                        playerStatus, absorb, augment
                    );

                isBlueHoldActive = true;
            }
            else
            {
                activeBlueSkill.transform.position = CalcBlueHoldPos();
                activeBlueSkill.transform.rotation =
                    Quaternion.LookRotation(transform.forward);
            }
        }
        else
        {
            if (activeBlueSkill != null)
            {
                activeBlueSkill.Deactivate();
                activeBlueSkill = null;

                controller.Animator.SetBool("IsSkillABlueHold", false);
                controller.SetBusy(false);

                isBlueHoldActive = false;

                // 🔥 Blue Hold 종료 → 쿨타임 시작 (여기가 핵심)
                StartCooldown(ColorType.Blue);
            }
        }
    }

    private void StartCooldown(ColorType type)
    {
        float cd = SkillACooldownTable.GetFinalCooldown(
            type,
            augment
        );

        skillACooldownDuration = cd;
        skillACooldownTimer = cd;
    }

    // 🔥 외부에서 강제 쿨타임 시작할 때 (보험)
    public void ForceStartCooldown(float duration)
    {
        skillACooldownDuration = duration;
        skillACooldownTimer = duration;
    }

    public void SetSkillAHoldBusy(bool value)
    {
        IsSkillAHoldBusy = value;
    }

    // ============================
    // Animation Event
    // ============================
    public void SkillA_Effect()
    {
        Vector3 pos = CalcSpawnPos();
        Quaternion rot = Quaternion.Euler(0, transform.eulerAngles.y, 0);

        switch (absorb.colorType)
        {
            case ColorType.Red:
                SkillAPool_Red.Instance.Spawn(pos, rot, playerStatus, absorb, augment);
                break;

            case ColorType.Green:
                SkillAPool_Green.Instance.Spawn(pos, rot, playerStatus, absorb, augment);
                break;

            case ColorType.Purple:
                SkillAPool_Purple.Instance.Spawn(pos, rot, playerStatus, absorb, augment);
                break;
        }
    }

    public void OnSkillAEnd()
    {
        controller.SetBusy(false);
    }

    // ============================
    // Position Helpers
    // ============================
    private Vector3 CalcSpawnPos()
    {
        Vector3 origin = transform.position + Vector3.up * 0.2f;
        Vector3 forward = transform.forward;
        Vector3 target = origin + forward * spawnDistance;

        if (Physics.Raycast(origin, forward, out RaycastHit wallHit, spawnDistance, wallMask))
            target = wallHit.point - forward * 0.1f;

        if (Physics.Raycast(target + Vector3.up * 2f, Vector3.down,
            out RaycastHit groundHit, 5f, groundMask))
            target.y = groundHit.point.y;

        return target;
    }

    private Vector3 CalcBlueHoldPos()
    {
        Vector3 pos = transform.position + transform.forward * 0.15f;
        pos.y += 0.2f;
        return pos;
    }

    public float GetMoveSpeedMultiplier()
    {
        return isBlueHoldActive ? blueHoldMoveMultiplier : 1f;
    }
}