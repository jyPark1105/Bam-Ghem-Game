using UnityEngine;

public class SlashHitDetector : MonoBehaviour
{
    private AttackDetector attackDetector;

    public void Init(AttackDetector detector)
    {
        attackDetector = detector; // null�� ���
    }

    private void OnTriggerEnter(Collider other)
    {
        if (attackDetector == null) return;

        EnemyAI enemy = other.GetComponentInParent<EnemyAI>();
        if (enemy == null) return;

        attackDetector.TryHit(enemy);
    }

    private void OnDisable()
    {
        attackDetector = null;
    }
}