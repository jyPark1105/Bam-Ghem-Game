﻿using UnityEngine;
using System.Collections;

public class SlashVFXController : MonoBehaviour
{
    public float lifeTime = 0.15f;
    public SlashHitDetector hitDetector;

    private Coroutine disableRoutine;

    // 🔒 씬 기준 로컬 값 (절대값)
    private Vector3 baseLocalPos;
    private Quaternion baseLocalRot;
    private Vector3 baseLocalScale;

    private Transform homeParent;

    // ================================
    // Manager가 1회 초기화
    // ================================
    public void SetHomeParent(Transform parent)
    {
        homeParent = parent;

        // 🔥 씬에서 세팅한 값 그대로 캐싱
        baseLocalPos = transform.localPosition;
        baseLocalRot = transform.localRotation;
        baseLocalScale = transform.localScale;
    }

    // ================================
    // Play (로컬만 사용)
    // ================================
    public void Play(AttackDetector detector)
    {
        // 항상 Manager 자식 유지
        if (transform.parent != homeParent)
            transform.SetParent(homeParent, false);

        if (!gameObject.activeSelf)
            gameObject.SetActive(true);

        if (hitDetector != null)
            hitDetector.Init(detector);

        // 🔥 핵심: 월드 계산 ❌ / 로컬 고정 ⭕
        transform.localPosition = baseLocalPos;
        transform.localRotation = baseLocalRot;
        transform.localScale = baseLocalScale;

        if (disableRoutine != null)
            StopCoroutine(disableRoutine);

        disableRoutine = StartCoroutine(DisableAfter());
    }

    private IEnumerator DisableAfter()
    {
        yield return new WaitForSeconds(lifeTime);

        if (hitDetector != null)
            hitDetector.Init(null);

        gameObject.SetActive(false);

        // 🔒 완전 원복
        transform.SetParent(homeParent, false);
        transform.localPosition = baseLocalPos;
        transform.localRotation = baseLocalRot;
        transform.localScale = baseLocalScale;
    }
}