﻿using UnityEngine;
using System.Collections.Generic;
using StarterAssets;
using static PlayerAbsorbEffect;
using static UnityEngine.Rendering.HableCurve;

public class Player_SkillBCtrl : MonoBehaviour
{
    private ThirdPersonController controller;
    private PlayerStatus playerStatus;
    private PlayerAbsorbEffect absorb;
    private PlayerAugmentManager augment;
    private StarterAssetsInputs input;
    private Animator animator;

    private ColorType prevColorType;

    // ===================== Skill B Cooldown =====================
    private float skillBCooldownTimer = 0f;
    private float skillBCooldownDuration = 0f;

    public bool IsSkillBCooldown => skillBCooldownTimer > 0f;
    public float SkillBCooldownRatio =>
        skillBCooldownDuration <= 0f ? 0f : skillBCooldownTimer / skillBCooldownDuration;
    public float SkillBCooldownDuration => skillBCooldownDuration;

    // ===================== Skill B Blue Combo =====================
    private int blueComboIndex = 0; // 0,1,2
    private float blueStepCooldownTimer = 0f;
    private const float BLUE_STEP_COOLDOWN = 2.0f;

    private bool isSkillBInCombo = false;
    private float comboInputTimer = 0f;
    private const float COMBO_INPUT_WINDOW = 2.0f;

    public bool IsSkillBInComboWindow =>
        absorb.colorType == ColorType.Blue && blueComboIndex > 0;

    public bool IsBlueComboActive =>
        absorb.colorType == ColorType.Blue && isSkillBInCombo;

    private bool bufferSkillB;

    private void Awake()
    {
        controller = GetComponent<ThirdPersonController>();
        playerStatus = GetComponent<PlayerStatus>();
        absorb = GetComponent<PlayerAbsorbEffect>();
        augment = GetComponent<PlayerAugmentManager>();
        input = GetComponent<StarterAssetsInputs>();
        animator = GetComponent<Animator>();
    }

    private void Start()
    {
        absorb.OnAbsorbReady += OnAbsorbReady;
    }

    private void OnAbsorbReady()
    {
        if (bufferSkillB)
        {
            bufferSkillB = false;
            ExecuteSkillB();
        }
    }

    public void Tick()
    {
        if (skillBCooldownTimer > 0f)
            skillBCooldownTimer -= Time.deltaTime;

        if (!input.skillB) return;

        // 🔒 아직 준비 안 됐으면 버퍼
        if (!controller.IsPlayerReady)
        {
            bufferSkillB = true;
            input.skillB = false;
            return;
        }

        if (controller.IsBusy || !controller.isGrounded)
        {
            input.skillB = false;
            return;
        }

        input.skillB = false;
        ExecuteSkillB();
    }

    private void ExecuteSkillB()
    {
        // 🔒 방어 코드 (이중 실행 방지용)
        if (controller.IsBusy) return;
        if (!controller.isGrounded) return;

        var type = absorb.colorType;
        if (type == ColorType.None) return;

        if (type == ColorType.Blue)
        {
            HandleSkillBBlue();
        }
        else
        {
            HandleSkillBNormal(type);
        }
    }

    private void ResetBlueStateIfNeeded()
    {
        if (absorb.colorType != ColorType.Blue)
        {
            blueComboIndex = 0;
            isSkillBInCombo = false;
            comboInputTimer = 0f;
            blueStepCooldownTimer = 0f;
        }
    }


    private void HandleSkillBNormal(ColorType type)
    {
        if (IsSkillBCooldown) return;

        float manaCost = SkillBManaTable.GetCost(type);
        if (!playerStatus.HasEnoughMana(manaCost))
        {
            DebugStateAnimator_InStage.Instance.AnimateAll(GameMessage.NO_MANA);
            AudioManager.Instance.PlaySkillUnavailable();
            return;
        }

        playerStatus.ConsumeMana(manaCost);

        StartCooldown(ColorType.Blue);

        skillBCooldownTimer = skillBCooldownDuration;

        animator.SetInteger("SkillBType", GetSkillBType(type));
        animator.SetTrigger("SkillB");

        controller.SetBusy(true);
    }

    private void HandleSkillBBlue()
    {
        if (skillBCooldownTimer > 0f || blueStepCooldownTimer > 0f)
            return;

        float manaCost = SkillBManaTable.GetCost(ColorType.Blue);
        if (!playerStatus.HasEnoughMana(manaCost))
        {
            DebugStateAnimator_InStage.Instance.AnimateAll(GameMessage.NO_MANA);
            AudioManager.Instance.PlaySkillUnavailable();
            return;
        }

        playerStatus.ConsumeMana(manaCost);

        isSkillBInCombo = true;
        comboInputTimer = COMBO_INPUT_WINDOW;

        animator.SetInteger("SkillBType", blueComboIndex);
        animator.SetTrigger("SkillB");

        controller.SetBusy(true);
        blueStepCooldownTimer = BLUE_STEP_COOLDOWN;
    }

    // ===================== Animation Events =====================
    public void OnSkillBEnd()
    {
        controller.SetBusy(false);

        if (absorb.colorType != ColorType.Blue)
            return;

        blueComboIndex++;

        if (blueComboIndex >= 3)
            EndSkillBCombo();
    }

    public void OnSkillBComboFinish()
    {
        EndSkillBCombo();
    }

    private void EndSkillBCombo()
    {
        isSkillBInCombo = false;
        blueComboIndex = 0;
        comboInputTimer = 0f;

        StartCooldown(ColorType.Blue);
    }

    private void StartCooldown(ColorType type)
    {
        float cd = SkillBCooldownTable.GetFinalCooldown(
            type,
            augment
        );

        skillBCooldownDuration = cd;
        skillBCooldownTimer = cd;
    }

    // ===================== Spawn =====================
    public void SkillB_Effect()
    {
        var type = absorb.colorType;

        switch (type)
        {
            case ColorType.Blue:
                SpawnSkillBBlueByIndex();
                break;
            case ColorType.Red:
                SpawnSkillBRed();
                break;
            case ColorType.Green:
                SpawnSkillBToNearestEnemies(pos =>
                    SkillBPool_Green.Instance.Spawn(
                        pos, Quaternion.identity,
                        controller, playerStatus, absorb));
                break;
            case ColorType.Purple:
                SpawnSkillBToNearestEnemies(pos =>
                    SkillBPool_Purple.Instance.Spawn(
                        pos, Quaternion.identity,
                        controller, playerStatus, absorb));
                break;
        }
    }

    private void SpawnSkillBBlueByIndex()
    {
        SpawnSkillBToNearestEnemies(pos =>
        {
            switch (blueComboIndex)
            {
                case 0:
                    SkillBPool_Blue1.Instance.Spawn(pos, Quaternion.identity, controller, playerStatus, absorb);
                    break;
                case 1:
                    SkillBPool_Blue2.Instance.Spawn(pos, Quaternion.identity, controller, playerStatus, absorb);
                    break;
                case 2:
                    SkillBPool_Blue3.Instance.Spawn(pos, Quaternion.identity, controller, playerStatus, absorb);
                    break;
            }
        });
    }

    private void SpawnSkillBRed()
    {
        SpawnSkillBToNearestEnemies(pos =>
        {
            Quaternion rot = Quaternion.LookRotation(transform.forward, Vector3.up);
            var skill = SkillBPool_Red.Instance.Spawn(pos, rot, controller, playerStatus, absorb);
            skill.transform.rotation = rot;
        });
    }

    private void SpawnSkillBToNearestEnemies(
        System.Action<Vector3> spawnAction,
        int maxTargets = 3,
        float radius = 10f)
    {
        List<EnemyAI> enemies =
            EnemyFinder.FindNearestEnemies(transform.position, maxTargets, radius);

        foreach (EnemyAI enemy in enemies)
        {
            if (enemy == null || enemy.IsDead())
                continue;

            spawnAction.Invoke(enemy.transform.position + Vector3.up * 0.5f);
        }
    }

    private int GetSkillBType(ColorType type)
    {
        return type switch
        {
            ColorType.Blue => blueComboIndex,
            ColorType.Red => 4,
            _ => 3
        };
    }

    // ===================== UI Helpers =====================
    public float GetSkillBComboRatio()
    {
        if (!isSkillBInCombo) return 0f;
        return comboInputTimer / COMBO_INPUT_WINDOW;
    }

    public int GetSkillBComboIndexRaw()
    {
        if (absorb.colorType != ColorType.Blue)
            return 0;

        return blueComboIndex;
    }
}