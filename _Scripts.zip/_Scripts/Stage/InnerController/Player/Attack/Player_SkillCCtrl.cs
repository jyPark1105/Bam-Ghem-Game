using UnityEngine;
using StarterAssets;
using static PlayerAbsorbEffect;

public class Player_SkillCCtrl : MonoBehaviour
{
    [Header("References")]
    private ThirdPersonController controller;
    private PlayerStatus playerStatus;
    private PlayerAugmentManager augment;
    private PlayerAbsorbEffect absorb;

    private Animator animator;

    // Cooldown
    private float skillCCooldownTimer = 0f;
    private float skillCCooldownDuration = 0f;
    public bool IsSkillCCooldown => skillCCooldownTimer > 0f;
    public float SkillCCooldownDuration => skillCCooldownDuration;
    public float SkillCCooldownRatio =>
        skillCCooldownDuration <= 0f ? 0f : skillCCooldownTimer / skillCCooldownDuration;

    private StarterAssetsInputs input;

    private void Awake()
    {
        controller = GetComponent<ThirdPersonController>();
        playerStatus = GetComponent<PlayerStatus>();
        absorb = GetComponent<PlayerAbsorbEffect>();
        augment = GetComponent<PlayerAugmentManager>();
        input = GetComponent<StarterAssetsInputs>();
        animator = GetComponent<Animator>();
    }

    public void Tick()
    {
        if (!controller.IsPlayerReady)
            return;

        if (skillCCooldownTimer > 0f)
            skillCCooldownTimer -= Time.deltaTime;

        HandleSkillC();
    }

    private void HandleSkillC()
    {
        if (!input.skillC)
            return;

        if (!controller.isGrounded || controller.IsBusy)
        {
            input.skillC = false;
            return;
        }

        ExecuteSkillC();
        input.skillC = false;
    }

    private void ExecuteSkillC()
    {
        if (controller.IsBusy) return;
        if (!controller.isGrounded) return;
        if (absorb.colorType == ColorType.None) return;
        if (IsSkillCCooldown) return;

        controller.SetBusy(true);

        controller.Animator.SetTrigger("SkillC");

        StartCooldown(absorb.colorType);
    }

    private void StartCooldown(ColorType type)
    {
        float cd = SkillCCooldownTable.GetFinalCooldown(
            type,
            augment
        );

        skillCCooldownDuration = cd;
        skillCCooldownTimer = cd;
    }

    // ============================
    // Animation Event
    // ============================

    public void SkillC_Effect()
    {
        var type = absorb.colorType;

        var skill = SkillCPool.Instance.Spawn(
            transform.position,
            transform.rotation,
            playerStatus,
            absorb,
            augment
        );

        switch (type)
        {
            case ColorType.Red:
                skill.Init(StatusEffectType.Bleed, 5f);
                break;

            case ColorType.Green:
                skill.Init(StatusEffectType.Slow, 5f);
                break;

            case ColorType.Blue:
                skill.Init(StatusEffectType.Shock, 5f);
                break;

            case ColorType.Purple:
                skill.Init(StatusEffectType.Poison, 6f);
                break;
        }
    }

    public void OnSkillCEnd()
    {
        controller.SetBusy(false);
    }
}