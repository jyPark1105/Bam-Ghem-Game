﻿using UnityEngine;
using System.Collections.Generic;

public class AttackDetector : MonoBehaviour
{
    private bool active = false;
    public PlayerStatus player;

    // 🔥 이번 공격에서 이미 맞은 몬스터들
    private HashSet<EnemyAI> hitEnemies = new HashSet<EnemyAI>();

    [Header("Critical")]
    [Range(0f, 1f)]
    public float critChance = 0.15f;
    public float critMultiplier = 1.5f;

    // ================================
    // Attack Lifecycle (외부 제어)
    // ================================
    public void StartAttack()
    {
        active = true;
        hitEnemies.Clear();
    }

    public void EndAttack()
    {
        active = false;
    }

    // ================================
    // Slash에서 호출
    // ================================
    public void TryHit(EnemyAI enemy)
    {
        if (!active) return;
        if (enemy == null) return;
        if (hitEnemies.Contains(enemy)) return;

        hitEnemies.Add(enemy);

        // =========================
        // 데미지 계산
        // =========================
        float baseDamage = player.PhysicalATK;
        bool isCritical = Random.value < critChance;
        float finalDamage = isCritical
            ? baseDamage * critMultiplier
            : baseDamage;

        DamageInfo info = new DamageInfo
        {
            physical = finalDamage,
            magical = 0f,
            isCritical = isCritical,
            damageType = DamageText.DamageType.Physical
        };

        enemy.TakeDamage(info);

        StageManager.Instance?.OnDamageDealt(
            Mathf.RoundToInt(finalDamage)
        );

        AudioManager.Instance?.PlayEnemyHit();
    }
}