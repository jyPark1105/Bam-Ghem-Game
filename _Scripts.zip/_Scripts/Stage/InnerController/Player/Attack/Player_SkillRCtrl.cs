﻿using UnityEngine;
using System.Collections;
using Cinemachine;
using StarterAssets;
using static PlayerAbsorbEffect;

public class Player_SkillRCtrl : MonoBehaviour
{
    private ThirdPersonController controller;
    private PlayerStatus playerStatus;
    private PlayerAbsorbEffect absorb;
    private PlayerAugmentManager augment;
    private StarterAssetsInputs input;
    private Animator animator;

    // ===================== Cooldown =====================
    private float skillRCooldownTimer = 0f;
    private float skillRCooldownDuration = 0f;
    public bool IsSkillRCooldown => skillRCooldownTimer > 0f;
    public float SkillRCooldownDuration => skillRCooldownDuration;
    public float SkillRCooldownRatio =>
        skillRCooldownDuration <= 0f ? 0f : skillRCooldownTimer / skillRCooldownDuration;

    private bool bufferSkillR;

    // ===================== Controllers =====================
    public SkillR_Controller_Red skillR_Red;
    public SkillR_Controller_Blue skillR_Blue;
    public SkillR_Controller_Green skillR_Green;
    public SkillR_Controller_Purple skillR_Purple;

    // ===================== UI / Camera =====================
    public GameObject skillRCutsceneUIPrefab;
    private SkillR_CutsceneUI activeSkillRUI;

    [SerializeField] private CinemachineVirtualCamera skillRCam;
    [SerializeField] private float zoomInFOV = 35f;
    [SerializeField] private float zoomOutFOV = 60f;
    [SerializeField] private float zoomDuration = 0.25f;

    private Coroutine zoomRoutine;

    private bool cleanupDone = false;

    private void Awake()
    {
        controller = GetComponent<ThirdPersonController>();
        playerStatus = GetComponent<PlayerStatus>();
        absorb = GetComponent<PlayerAbsorbEffect>();
        augment = GetComponent<PlayerAugmentManager>();
        input = GetComponent<StarterAssetsInputs>();
        animator = GetComponent<Animator>();
    }

    private void Start()
    {
        absorb.OnAbsorbReady += OnAbsorbReady;
    }

    private void OnDisable()
    {
        Cleanup();
    }

    private void OnAbsorbReady()
    {
        if (bufferSkillR)
        {
            bufferSkillR = false;
            ExecuteSkillR();
        }
    }

    public void Tick()
    {
        if (skillRCooldownTimer > 0f)
            skillRCooldownTimer -= Time.deltaTime;

        if (!input.skillR) return;

        // 🔒 Ready 전이면 버퍼
        if (!controller.IsPlayerReady)
        {
            bufferSkillR = true;
            input.skillR = false;
            return;
        }

        if (controller.IsBusy || !controller.isGrounded)
        {
            input.skillR = false;
            return;
        }

        input.skillR = false;
        ExecuteSkillR();
    }

    private void ExecuteSkillR()
    {
        // 🔒 방어 코드 (이중 실행 방지용)
        if (controller.IsBusy) return;
        if (!controller.isGrounded) return;
        if (absorb.colorType == ColorType.None) return;
        if (IsSkillRCooldown) return;

        cleanupDone = false; // ✅ 멱등성 리셋

        var type = absorb.colorType;
        float manaCost = SkillRManaTable.GetCost(type);
        if (!playerStatus.HasEnoughMana(manaCost))
        {
            DebugStateAnimator_InStage.Instance.AnimateAll(GameMessage.NO_MANA);
            AudioManager.Instance.PlaySkillUnavailable();
            return;
        }

        playerStatus.ConsumeMana(manaCost);

        StartCooldown(type);

        // 쿨타임 계산
        float cd = SkillBCooldownTable.GetFinalCooldown(type, augment);

        skillRCooldownDuration = cd;
        skillRCooldownTimer = cd;

        controller.SetBusy(true);
        animator.SetTrigger("SkillR");
    }

    private void StartCooldown(ColorType type)
    {
        float cd = SkillRCooldownTable.GetFinalCooldown(
            type,
            augment
        );

        skillRCooldownDuration = cd;
        skillRCooldownTimer = cd;
    }

    private void Cleanup()
    {
        // 🔒 멱등성 보장
        if (cleanupDone)
            return;

        cleanupDone = true;

        // 🔒 생명주기 방어
        if (!this || !gameObject.activeInHierarchy)
            return;

        if (activeSkillRUI != null)
        {
            activeSkillRUI.Hide();
            activeSkillRUI = null;
        }

        if (skillRCam != null)
            skillRCam.Priority = 5;

        if (zoomRoutine != null)
        {
            CoroutineRunner.Instance.StopCoroutine(zoomRoutine);
            zoomRoutine = null;
        }

        // 🔥 Player 비활성 상태에서도 안전
        CoroutineRunner.Instance.StartCoroutine(
            ZoomCamera(skillRCam.m_Lens.FieldOfView, zoomOutFOV)
        );

        if (controller != null)
            controller.SetBusy(false);
    }

    // ===================== Animation Events =====================
    public void OnSkillRStart()
    {
        playerStatus?.SetInvincible(0.6f);

        if (skillRCutsceneUIPrefab != null && activeSkillRUI == null)
        {
            GameObject uiObj = Instantiate(skillRCutsceneUIPrefab);
            activeSkillRUI = uiObj.GetComponent<SkillR_CutsceneUI>();
            activeSkillRUI?.Play();
        }

        if (skillRCam != null)
            skillRCam.Priority = 20;

        StartCoroutine(ZoomCamera(skillRCam.m_Lens.FieldOfView, zoomInFOV));
    }

    public void SkillR_Effect()
    {
        StartCoroutine(SkillR_Effect_Safe());
    }

    private IEnumerator SkillR_Effect_Safe()
    {
        while (!SkillRVFXPool.IsReady)
            yield return null;

        var ctrl = GetSkillRController(absorb.colorType);
        if (ctrl == null)
            yield break;

        ctrl.SetPlayer(controller, playerStatus, absorb);
        ctrl.StartCasting();
    }

    public void OnSkillREnd()
    {
        Cleanup();
    }

    public void OnSkillRCastingFinished()
    {
        Cleanup();
    }

    private SkillR_Controller_Base GetSkillRController(ColorType type)
    {
        return type switch
        {
            ColorType.Red => skillR_Red,
            ColorType.Blue => skillR_Blue,
            ColorType.Green => skillR_Green,
            ColorType.Purple => skillR_Purple,
            _ => null
        };
    }

    private IEnumerator ZoomCamera(float from, float to)
    {
        float t = 0f;
        while (t < zoomDuration)
        {
            t += Time.unscaledDeltaTime;
            skillRCam.m_Lens.FieldOfView =
                Mathf.Lerp(from, to, t / zoomDuration);
            yield return null;
        }
        skillRCam.m_Lens.FieldOfView = to;
    }
}