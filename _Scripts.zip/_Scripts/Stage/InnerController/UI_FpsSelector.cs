﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UI_FpsSelector : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private Button leftButton;
    [SerializeField] private Button rightButton;
    [SerializeField] private TMP_Text fpsText;

    [Header("FPS Options")]
    [SerializeField] private int[] fpsOptions = { 30, 60, 90 };

    [Header("Save")]
    [SerializeField] private bool usePlayerPrefs = true;
    private const string PREF_KEY = "OPTION_FPS";

    private int index = 1; // 🔥 기본값 = 60fps

    private void Awake()
    {
        if (leftButton != null) leftButton.onClick.AddListener(OnLeft);
        if (rightButton != null) rightButton.onClick.AddListener(OnRight);

        // 저장값 복원
        if (usePlayerPrefs)
        {
            int saved = PlayerPrefs.GetInt(PREF_KEY, 60);
            index = FindClosestIndex(saved);
        }

        ApplyAndRefresh();
    }

    private int FindClosestIndex(int fps)
    {
        int best = 0;
        int bestDiff = int.MaxValue;

        for (int i = 0; i < fpsOptions.Length; i++)
        {
            int diff = Mathf.Abs(fpsOptions[i] - fps);
            if (diff < bestDiff)
            {
                bestDiff = diff;
                best = i;
            }
        }
        return best;
    }

    private void OnLeft()
    {
        index = Mathf.Max(0, index - 1);
        ApplyAndRefresh();
    }

    private void OnRight()
    {
        index = Mathf.Min(fpsOptions.Length - 1, index + 1);
        ApplyAndRefresh();
    }

    private void ApplyAndRefresh()
    {
        int fps = fpsOptions[index];

        // 🔥 FPS 적용
        ApplyFPS(fps);

        // UI 텍스트
        if (fpsText != null)
            fpsText.text = $"{fps} FPS";

        // UX: 양끝 버튼 비활성화
        if (leftButton != null)
            leftButton.interactable = index > 0;

        if (rightButton != null)
            rightButton.interactable = index < fpsOptions.Length - 1;

        // 저장
        if (usePlayerPrefs)
        {
            PlayerPrefs.SetInt(PREF_KEY, fps);
            PlayerPrefs.Save();
        }
    }

    private void ApplyFPS(int fps)
    {
#if UNITY_EDITOR
        // 🔧 에디터에서는 프레임 제한 해제
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = -1;

        Debug.Log("[UI_FpsSelector] Editor mode → FPS unlocked (-1)");
#else
        // 📱 빌드에서는 선택한 FPS 적용
        QualitySettings.vSyncCount = 0;   // 🔥 targetFrameRate 보호
        Application.targetFrameRate = fps;

        Debug.Log($"[UI_FpsSelector] Target FPS = {fps}");
#endif
    }

    // 외부에서 직접 호출용
    public void SetFPSByValue(int fps)
    {
        index = FindClosestIndex(fps);
        ApplyAndRefresh();
    }
}