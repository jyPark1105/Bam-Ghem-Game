﻿using UnityEngine;

public class DropManager : MonoBehaviour
{
    public static DropManager Instance;

    [Range(0f, 1f)]
    public float dropAugmentChestChance = 0.1f;

    private PlayerAbsorbEffect cachedAbsorb;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        cachedAbsorb = PlayerAbsorbEffect.Instance;
    }

    public void TryDropAugmentChest(
        Vector3 pos,
        EnemyAI.ElementType monsterElement
    )
    {
        if (cachedAbsorb == null || !cachedAbsorb.HasElement())
            return;

        if (Random.value > dropAugmentChestChance)
            return;

        bool isCurse =
            cachedAbsorb.colorType.ToString() ==
            monsterElement.ToString();

        Vector3 spawnPos = pos + Vector3.up * 0.3f;

        AugmentChest chest =
            AugmentChestPool.Instance.Get(monsterElement, spawnPos);

        if (chest == null)
        {
            StageLogPanel.Log(
                $"[DropManager][WARN] Chest pool empty ({monsterElement})",
                LogType.Warning
            );
            return;
        }

        chest.Init(monsterElement, isCurse);
    }
}