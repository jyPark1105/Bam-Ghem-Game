﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Collider))]
[RequireComponent(typeof(AbsorbItem))]
public class AbsorbItemTrigger : MonoBehaviour
{
    public float absorbDelay = 3f;

    private bool isAbsorbing = false;
    private Coroutine absorbRoutine;

    private AbsorbItem absorbItem;

    private void Awake()
    {
        absorbItem = GetComponent<AbsorbItem>();

        var col = GetComponent<Collider>();
        col.isTrigger = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        if (isAbsorbing || absorbRoutine != null)
            return;

        PlayerAbsorbEffect absorb =
            other.GetComponentInChildren<PlayerAbsorbEffect>();

        if (absorb == null || absorb.CircleUI == null)
            return;

        // 🔥 Enter 시 단 1회 색상 캐싱
        absorb.CircleUI.CacheColor(absorbItem.colorType);
        absorb.CircleUI.ResetFill();
        absorb.CircleUI.StartPulse();

        absorbRoutine = StartCoroutine(
            AbsorbAfterDelay(absorb, absorb.CircleUI)
        );
    }

    private IEnumerator AbsorbAfterDelay(
        PlayerAbsorbEffect absorb,
        AbsorbCircleFill circleUI
    )
    {
        float t = 0f;

        while (t < absorbDelay)
        {
            if (absorb == null)
            {
                absorbRoutine = null;
                yield break;
            }

            t += Time.deltaTime;
            circleUI.SetRatio(t / absorbDelay);

            yield return null;
        }

        // ✅ 완료
        circleUI.Complete();

        isAbsorbing = true;
        absorbRoutine = null;

        // 🔥 흡수 시작
        absorb.StartAbsorb(gameObject);
    }

    private void OnTriggerExit(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        if (absorbRoutine != null)
        {
            StopCoroutine(absorbRoutine);
            absorbRoutine = null;
        }

        PlayerAbsorbEffect absorb =
            other.GetComponentInChildren<PlayerAbsorbEffect>();

        if (absorb != null && absorb.CircleUI != null)
        {
            absorb.CircleUI.StopPulse();
            absorb.CircleUI.ResetFill();
        }

        isAbsorbing = false;
    }
}