﻿using UnityEngine;

public class Item : MonoBehaviour
{
    public string itemName;

    public virtual Item OnPickup()
    {
        //Debug.Log("Picked up: " + itemName);
        return this;
    }
}