using UnityEngine;

public class AbsorbItem : MonoBehaviour
{
    [Header("Absorb Attribute")]
    public PlayerAbsorbEffect.ColorType colorType;
}