﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class AbsorbCircleFill : MonoBehaviour
{
    public Image fillImage;

    [Header("Pulse Settings")]
    public float pulseScale = 1.08f;
    public float pulseSpeed = 2.5f;
    public float alphaMin = 0.85f;

    private RectTransform rt;
    private Coroutine pulseCoroutine;
    private Vector3 baseScale;

    // 🔒 캐싱된 색
    private Color cachedColor = Color.white;

    private void Awake()
    {
        if (fillImage != null)
        {
            fillImage.type = Image.Type.Filled;
            rt = fillImage.rectTransform;
            baseScale = rt.localScale;
        }
    }

    // =========================
    // 🔥 Enter 시 1회 호출
    // =========================
    public void CacheColor(PlayerAbsorbEffect.ColorType type)
    {
        cachedColor = GetColorByType(type);

        if (fillImage != null)
            fillImage.color = cachedColor;
    }

    public void SetRatio(float ratio)
    {
        if (fillImage == null)
            return;

        fillImage.fillAmount = Mathf.Clamp01(ratio);
    }

    public void ResetFill()
    {
        SetRatio(0f);
    }

    public void Complete()
    {
        SetRatio(1f);
    }

    // =========================
    // Pulse
    // =========================
    public void StartPulse()
    {
        if (pulseCoroutine == null)
            pulseCoroutine = StartCoroutine(PulseRoutine());
    }

    public void StopPulse()
    {
        if (pulseCoroutine != null)
        {
            StopCoroutine(pulseCoroutine);
            pulseCoroutine = null;
        }

        if (rt != null)
            rt.localScale = baseScale;

        if (fillImage != null)
        {
            Color c = cachedColor;
            c.a = 1f;
            fillImage.color = c;
        }
    }

    private IEnumerator PulseRoutine()
    {
        float t = 0f;

        while (true)
        {
            t += Time.deltaTime * pulseSpeed;
            float sin = (Mathf.Sin(t) + 1f) * 0.5f;

            rt.localScale = baseScale * Mathf.Lerp(1f, pulseScale, sin);

            Color c = cachedColor;
            c.a = Mathf.Lerp(alphaMin, 1f, sin);
            fillImage.color = c;

            yield return null;
        }
    }

    // =========================
    // 🔒 External Control
    // =========================
    public void ForceHide()
    {
        StopPulse();

        if (fillImage == null)
            return;

        fillImage.fillAmount = 0f;
        fillImage.gameObject.SetActive(false);
    }

    public void ForceShow()
    {
        if (fillImage == null)
            return;

        fillImage.gameObject.SetActive(true);
        fillImage.fillAmount = 0f;
    }

    // =========================
    // Color Mapping
    // =========================
    private Color GetColorByType(PlayerAbsorbEffect.ColorType type)
    {
        switch (type)
        {
            case PlayerAbsorbEffect.ColorType.Blue:
                return new Color32(0, 121, 255, 255);
            case PlayerAbsorbEffect.ColorType.Red:
                return new Color32(255, 45, 72, 255);
            case PlayerAbsorbEffect.ColorType.Green:
                return new Color32(109, 219, 91, 255);
            case PlayerAbsorbEffect.ColorType.Purple:
                return new Color32(208, 47, 217, 255);
            default:
                return Color.white;
        }
    }
}