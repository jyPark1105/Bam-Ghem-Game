﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class StageLogPanel : MonoBehaviour
{
    public static StageLogPanel Instance { get; private set; }

    [SerializeField] private CanvasGroup canvasGroup;

    [Header("UI References")]
    [SerializeField] private ScrollRect scrollRect;
    [SerializeField] private Transform content;

    [Header("Prefabs")]
    [SerializeField] private GameObject logItemPrefab; // _Prefabs/StageIn/LogItem

    private class LogEntry
    {
        public string message;
        public int count;
        public TMP_Text textComponent;
        public Image statusImage;
    }

    private readonly List<LogEntry> logEntries = new List<LogEntry>();
    private const int MaxLogs = 50;

    private Sprite warningSprite;
    private Sprite errorSprite;
    private Sprite infoSprite;

    void Start()
    {
        // 스테이지 진입 시 첫 로그 출력
        Log("<color=#00FFAA>[StageLogPanel]</color> Initialized", LogType.Info);
    }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        warningSprite = Resources.Load<Sprite>("LogStatus/Warning");
        errorSprite = Resources.Load<Sprite>("LogStatus/Error");
        infoSprite = Resources.Load<Sprite>("LogStatus/Info");

        // 🔥 Editor / Build 구분
        if (canvasGroup != null)
        {
#if UNITY_EDITOR
            canvasGroup.alpha = 1f;
            canvasGroup.interactable = true;
            canvasGroup.blocksRaycasts = true;
#else
            canvasGroup.alpha = 0f;
            canvasGroup.interactable = false;
            canvasGroup.blocksRaycasts = false;
#endif
        }
    }

    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public static void Log(string message, LogType type = LogType.Info)
    {
        if (Instance != null)
            Instance.AddOrUpdateLog(message, type);
    }

    private void AddOrUpdateLog(string message, LogType type)
    {
        // 기존 로그 중 동일 메시지 탐색
        var existingEntry = logEntries.Find(entry => entry.message == message);
        if (existingEntry != null)
        {
            existingEntry.count++;

            Transform countFrame = existingEntry.textComponent.transform.parent.Find("LogCountFrame");
            if (countFrame != null)
            {
                TMP_Text countText = countFrame.Find("LogCount").GetComponent<TMP_Text>();
                countFrame.gameObject.SetActive(true);
                countText.text = existingEntry.count.ToString();

                float rt_size = existingEntry.count >= 100 ? 40f : 35f;
                ChangeLogCountSize(countFrame, rt_size);

                float ft_size = existingEntry.count >= 100 ? 14f :
                                existingEntry.count >= 10 ? 16f : 18f;
                countText.fontSize = ft_size;
            }

            existingEntry.textComponent.text = existingEntry.message;
            return;
        }

        // 🔹 새 로그 생성
        GameObject newLog = Instantiate(logItemPrefab, content, false);
        TMP_Text textComponent = newLog.transform.Find("LogText").GetComponent<TMP_Text>();
        Image statusImage = newLog.transform.Find("LogStatusImage").GetComponent<Image>();
        textComponent.text = message;

        // 로그 타입별 아이콘
        switch (type)
        {
            case LogType.Warning:
                statusImage.sprite = warningSprite;
                break;
            case LogType.Error:
                statusImage.sprite = errorSprite;
                break;
            default:
                statusImage.sprite = infoSprite;
                break;
        }

        Transform countFrameNew = newLog.transform.Find("LogCountFrame");
        if (countFrameNew != null)
            countFrameNew.gameObject.SetActive(false);

        logEntries.Add(new LogEntry
        {
            message = message,
            count = 1,
            textComponent = textComponent,
            statusImage = statusImage
        });

        // 최대 로그 수 초과 시 오래된 로그 삭제
        if (logEntries.Count > MaxLogs)
        {
            Destroy(logEntries[0].textComponent.transform.parent.gameObject);
            logEntries.RemoveAt(0);
        }

        Canvas.ForceUpdateCanvases();
        scrollRect.verticalNormalizedPosition = 0f;
    }

    private void ChangeLogCountSize(Transform countFrame, float size)
    {
        RectTransform rect = countFrame.GetComponent<RectTransform>();
        rect.sizeDelta = new Vector2(size, size);
    }

    private void OnDestroy()
    {
        // 스테이지 종료 시 로그 초기화
        logEntries.Clear();
    }
}