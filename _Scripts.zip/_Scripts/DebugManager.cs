using UnityEngine;

public class DebugManager : MonoBehaviour
{
    public static DebugManager Instance { get; private set; }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    /// <summary>
    /// FirebaseDebugUI + LogPanel + �ܼ� ��� ���
    /// </summary>
    public static void Log(string message, LogType type = LogType.Info)
    {
        // �����̵� �ִϸ��̼� ����� UI
        if (DebugStateAnimator.Instance != null)
            DebugStateAnimator.Instance.AnimateAll(message);

        // �α� �гο� ���� (Ÿ�� ����)
        if (LogPanel.Instance != null)
            LogPanel.Log(message, type);
    }

    public static void LogSilent(string message, LogType type = LogType.Info)
    {
        if (LogPanel.Instance != null)
            LogPanel.Log(message, type);
    }
}