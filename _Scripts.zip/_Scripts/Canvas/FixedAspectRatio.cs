﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Camera))]
public class FixedAspectRatio : MonoBehaviour
{
    private readonly float targetAspect = 16f / 9f;

    private Camera cam;

    IEnumerator Start()
    {
        cam = GetComponent<Camera>();

        // Android SafeArea 안정화 기다림
        yield return new WaitForSeconds(0.5f);

        UpdateAspect();
    }

    void UpdateAspect()
    {
        cam.backgroundColor = Color.black;

        float windowAspect = (float)Screen.width / Screen.height;
        float scaleHeight = windowAspect / targetAspect;

        Rect rect = new Rect();

        if (scaleHeight < 1f)
        {
            rect.width = 1f;
            rect.height = scaleHeight;
            rect.x = 0;
            rect.y = (1f - scaleHeight) * 0.5f;
        }
        else
        {
            float scaleWidth = 1f / scaleHeight;
            rect.width = scaleWidth;
            rect.height = 1f;
            rect.x = (1f - scaleWidth) * 0.5f;
            rect.y = 0;
        }

        cam.rect = rect;
    }

    public void EnableLetterbox(bool enable)
    {
        enabled = enable;

        if (enable)
        {
            UpdateAspect();
        }
        else
        {
            cam.rect = new Rect(0, 0, 1, 1);
        }
    }
}