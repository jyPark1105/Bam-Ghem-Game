﻿using UnityEngine;
using Firebase.Auth;
using TMPro;
using System.Text;
using System.Collections;
using System.Threading.Tasks;
using Google; // Google Sign-In SDK

public class FirebaseGoogleAuth : MonoBehaviour
{
    [Header("UI References")]
    private StringBuilder logBuilder = new StringBuilder();

    private FirebaseAuth auth;
    private bool isAuthReady = false;

#if UNITY_ANDROID
    private GoogleSignInConfiguration googleConfig;
#endif

    // =========================================================
    //  Firebase 초기화 이벤트 구독
    // =========================================================
    private void OnEnable()
    {
        FirebaseInitializer.OnFirebaseReady += InitializeAuth;
    }

    private void OnDisable()
    {
        FirebaseInitializer.OnFirebaseReady -= InitializeAuth;
    }

    private void InitializeAuth()
    {
        try
        {
            auth = FirebaseInitializer.AuthInstance ?? FirebaseAuth.DefaultInstance;

            if (auth == null)
            {
                DebugManager.Log("[FirebaseGoogleAuth] FirebaseAuth is NULL — initialization failed.", LogType.Error);
                StatusTextUI.Instance?.UpdateStatus("Firebase Auth instance is null.");
                return;
            }

            isAuthReady = true;
            StatusTextUI.Instance?.UpdateStatus("Firebase (Google) Auth Ready");
            DebugManager.Log("[Firebase] Google Auth initialized successfully (via event).");
        }
        catch (System.Exception ex)
        {
            DebugManager.Log($"[FirebaseGoogleAuth] InitializeAuth() failed: {ex.Message}", LogType.Error);
        }
    }

    private void Start()
    {
#if UNITY_ANDROID
        googleConfig = new GoogleSignInConfiguration
        {
            WebClientId = "975791283115-d8sng437bausm69ecnefc1b95l7tk07p.apps.googleusercontent.com",
            RequestIdToken = true,
            RequestEmail = true
        };
#endif
    }

    // =========================================================
    //  Google 로그인 버튼 클릭
    // =========================================================
    public void OnGoogleLoginClicked()
    {
        if (!isAuthReady || auth == null)
        {
            StatusTextUI.Instance?.UpdateStatus("Firebase not ready yet!");
            return;
        }

#if UNITY_EDITOR
        StatusTextUI.Instance?.UpdateStatus("Editor mode: Simulated Google Login.");
#elif UNITY_ANDROID
    StartCoroutine(GoogleLoginFlow());
#else
    StatusTextUI.Instance?.UpdateStatus("Google login supported on Android only.");
#endif
    }

#if UNITY_ANDROID
    private IEnumerator GoogleLoginFlow()
    {
        LobbyLoadingUI.Instance?.Show();
        StatusTextUI.Instance?.UpdateStatus("Starting Google Sign-In...");

        // 🔥 바로 호출 (Canvas 강제 갱신 필요 없음)
        _ = SignInWithGoogleOnAndroid();
        yield break;
    }
#endif

#if UNITY_ANDROID
    private async Task<FirebaseUser> SignInWithGoogleOnAndroid()
    {
        try
        {
            DebugManager.LogSilent("[Firebase] Step 1: Starting Google Sign-In flow...");
            auth ??= FirebaseAuth.DefaultInstance;

            if (auth == null)
            {
                StatusTextUI.Instance?.UpdateStatus("Firebase Auth not initialized.");
                DebugManager.LogSilent("[FirebaseGoogleAuth] Auth instance was null!", LogType.Error);
                return null;
            }

            DebugManager.LogSilent("[Firebase] Step 2: Configuring GoogleSignIn...");
            GoogleSignIn.Configuration = googleConfig;
            GoogleSignIn.Configuration.UseGameSignIn = false;
            GoogleSignIn.Configuration.RequestIdToken = true;

            DebugManager.LogSilent("[Firebase] Step 3: Calling GoogleSignIn.SignIn()");
            var googleUser = await GoogleSignIn.DefaultInstance.SignIn();

            DebugManager.LogSilent($"[Firebase] Step 3-RESULT: googleUser = {googleUser != null}");
            if (googleUser == null)
            {
                StatusTextUI.Instance?.UpdateStatus("Google Sign-In cancelled.");
                LobbyLoadingUI.Instance?.HideAfterMinimum();
                return null;
            }

            DebugManager.LogSilent("[Firebase] Step 4: Creating Firebase credential...");
            string idToken = googleUser.IdToken;
            string accessToken = googleUser.AuthCode;

            DebugManager.LogSilent($"[Firebase] Step 4: idToken = {idToken != null}, accessToken = {accessToken != null}");
            var credential = GoogleAuthProvider.GetCredential(idToken, accessToken);

            DebugManager.LogSilent("[Firebase] Step 5: Authenticating with Firebase...");
            StatusTextUI.Instance?.UpdateStatus("Authenticating with Firebase...");
            var user = await auth.SignInWithCredentialAsync(credential);

            DebugManager.LogSilent($"[Firebase] Step 5-RESULT: user = {user != null}");
            if (user != null)
            {
                DebugManager.LogSilent("[Firebase] Step 6: Calling OnFirebaseLoginComplete...");
                await OnFirebaseLoginComplete(user);
            }

            return user;
        }
        catch (System.Exception ex)
        {
            StatusTextUI.Instance?.UpdateStatus("Google Sign-In failed.");
            LobbyLoadingUI.Instance?.HideAfterMinimum();
            DebugManager.LogSilent("[Firebase] Google Sign-In failed: " + ex.Message, LogType.Error);
            return null;
        }
    }
#endif

    // =========================================================
    //  로그인 완료 후 단계별 안전 처리
    // =========================================================
    private async Task OnFirebaseLoginComplete(FirebaseUser user)
    {
        try
        {
            DebugManager.LogSilent("[FirebaseGoogleAuth] OnFirebaseLoginComplete() started.");
            TryUpdateStatus("Loading user data...");

            // ① UserInfoUI 대기
            int waitCount = 0;
            while (UserInfoUI.Instance == null && waitCount < 30)
            {
                await Task.Delay(200);
                waitCount++;
            }

            if (UserInfoUI.Instance != null)
            {
                DebugManager.LogSilent("[FirebaseGoogleAuth] UserInfoUI detected (pre-MainPanel).");
            }
            else
            {
                DebugManager.LogSilent("[FirebaseGoogleAuth] UserInfoUI.Instance is NULL after initial wait — may appear after MainPanel opens.", LogType.Warning);
            }

            // ② UIManager 대기
            waitCount = 0;
            while (UIManager.Instance == null && waitCount < 30)
            {
                await Task.Delay(200);
                waitCount++;
            }

            // ③ 메인 패널 켜진 후 UserInfoUI 재확인
            await Task.Delay(1200);
            if (UserInfoUI.Instance != null)
            {
                try
                {
                    // b) 유저 정보 세팅
                    UserInfoUI.Instance.UpdateUserName();
                    DebugManager.LogSilent("[FirebaseGoogleAuth] UserInfoUI nickname updated after MainPanel activation.");
                }
                catch (System.Exception uiEx)
                {
                    DebugManager.LogSilent("[FirebaseGoogleAuth] UserInfoUI.UpdateUserName() failed: " + uiEx.Message, LogType.Error);
                }
            }
            else
            {
                DebugManager.LogSilent("[FirebaseGoogleAuth] UserInfoUI still NULL after MainPanel activation.", LogType.Warning);
            }

            // ④ 완료 메시지
            TryUpdateStatus("User data loaded. Welcome!");

            // 🔥 로딩 UI 종료 (지연)
            LobbyLoadingUI.Instance?.HideAfterMinimum(() =>
            {
                UIManager.Instance.HideAuthPanel();
                UIManager.Instance.SafeShowMainPanel();
            });

            DebugManager.LogSilent("[FirebaseGoogleAuth] OnFirebaseLoginComplete() finished successfully.");
        }
        catch (System.Exception ex)
        {
            LobbyLoadingUI.Instance?.HideAfterMinimum(() =>
            {
                UIManager.Instance.HideAuthPanel();
                UIManager.Instance.SafeShowMainPanel();
            });
            DebugManager.LogSilent("[FirebaseGoogleAuth] OnFirebaseLoginComplete() failed: " + ex.Message, LogType.Error);
        }
    }

    /// <summary>
    /// StatusTextUI를 안전하게 갱신하는 헬퍼 함수 (내부 text null 방지)
    /// </summary>
    private void TryUpdateStatus(string message)
    {
        try
        {
            if (StatusTextUI.Instance != null)
                StatusTextUI.Instance.UpdateStatus(message);
            else
                DebugManager.LogSilent("[FirebaseGoogleAuth] StatusTextUI.Instance is NULL (skipped update).", LogType.Warning);
        }
        catch (System.Exception ex)
        {
            DebugManager.LogSilent("[FirebaseGoogleAuth] TryUpdateStatus() failed: " + ex.Message, LogType.Error);
        }
    }

    // =========================================================
    //  로그아웃
    // =========================================================
    public void OnLogoutButtonClicked()
    {
        if (!isAuthReady || auth == null)
        {
            StatusTextUI.Instance?.UpdateStatus("Auth not initialized.");
            DebugManager.LogSilent("[Firebase] Auth not initialized.", LogType.Error);
            return;
        }

        auth.SignOut();
#if UNITY_ANDROID
        GoogleSignIn.DefaultInstance.SignOut();
#endif
        StatusTextUI.Instance?.UpdateStatus("Signed out from Google.");
        DebugManager.LogSilent("[Firebase] User signed out from Google Auth.");
    }
}