﻿using UnityEngine;
using System.Collections;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    [Header("Authentication Panels")]
    public GameObject totalPanel_Auth;
    public GameObject registerSelectionPanel;
    public GameObject loginSelectionPanel;
    public GameObject emailRegisterPanel;
    public GameObject emailLoginPanel;

    [Header("Main Panel")]
    public GameObject totalPanel_Main;
    private CanvasGroup mainCanvasGroup;   // 🔥 추가

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);

        // 🔥 CanvasGroup 캐싱 (없으면 자동 추가)
        if (totalPanel_Main != null)
        {
            mainCanvasGroup = totalPanel_Main.GetComponent<CanvasGroup>();
            if (mainCanvasGroup == null)
                mainCanvasGroup = totalPanel_Main.AddComponent<CanvasGroup>();
        }
    }

    void Start()
    {
        totalPanel_Auth.SetActive(false);
    }

    private void SetPanelState(GameObject panel, bool state)
    {
        if (panel != null && panel.activeSelf != state)
            panel.SetActive(state);
    }

    // =====================================================
    // 🔥 Main Panel 제어 (SetActive ❌)
    // =====================================================
    public void HideMainPanel()
    {
        if (mainCanvasGroup == null) return;

        mainCanvasGroup.alpha = 0f;
        mainCanvasGroup.interactable = false;
        mainCanvasGroup.blocksRaycasts = false;

        DebugManager.Log("[UIManager] MainPanel hidden (CanvasGroup)");
    }

    public void ShowMainPanel()
    {
        if (mainCanvasGroup == null) return;

        mainCanvasGroup.alpha = 1f;
        mainCanvasGroup.interactable = true;
        mainCanvasGroup.blocksRaycasts = true;

        DebugManager.Log("[UIManager] MainPanel shown (CanvasGroup)");
    }

    // =====================================================
    // 🔐 Auth Panel (기존 유지)
    // =====================================================
    public void ShowRegisterSelectionPanel()
    {
        HideMainPanel();   // 🔥 추가

        SetPanelState(totalPanel_Auth, true);
        SetPanelState(registerSelectionPanel, true);
        SetPanelState(loginSelectionPanel, false);
        SetPanelState(emailRegisterPanel, false);
        SetPanelState(emailLoginPanel, false);
    }

    public void ShowLoginSelectionPanel()
    {
        HideMainPanel();   // 🔥 추가

        SetPanelState(totalPanel_Auth, true);
        SetPanelState(registerSelectionPanel, false);
        SetPanelState(loginSelectionPanel, true);
        SetPanelState(emailRegisterPanel, false);
        SetPanelState(emailLoginPanel, false);
    }


    public void ShowEmailRegisterPanel()
    {
        HideMainPanel();   // 🔥 추가

        SetPanelState(totalPanel_Auth, true);
        SetPanelState(registerSelectionPanel, false);
        SetPanelState(loginSelectionPanel, false);
        SetPanelState(emailRegisterPanel, true);
        SetPanelState(emailLoginPanel, false);
    }


    public void ShowEmailLoginPanel()
    {
        HideMainPanel();   // 🔥 추가

        SetPanelState(totalPanel_Auth, true);
        SetPanelState(registerSelectionPanel, false);
        SetPanelState(loginSelectionPanel, false);
        SetPanelState(emailRegisterPanel, false);
        SetPanelState(emailLoginPanel, true);
    }


    public void HideAuthPanel()
    {
        SetPanelState(totalPanel_Auth, false);
        SetPanelState(registerSelectionPanel, false);
        SetPanelState(loginSelectionPanel, false);
        SetPanelState(emailRegisterPanel, false);
        SetPanelState(emailLoginPanel, false);
    }

    // =====================================================
    // 🔁 로그인 후 로비 전환 (안전)
    // =====================================================
    public void SafeShowMainPanel()
    {
        StartCoroutine(SafeShowMainPanelCo());
    }

    private IEnumerator SafeShowMainPanelCo()
    {
        DebugManager.Log("[UIManager] SafeShowMainPanel() start");

        HideAuthPanel();
        ShowMainPanel();   // 🔥 여기서 다시 Raycast 복구

        yield return null;
        yield return new WaitForEndOfFrame();

        var loader = FindFirstObjectByType<StagePanelLoader>();
        if (loader != null)
            loader.LoadStagePanels();

        UserInfoUI.Instance?.UpdateUserName();
        StatusTextUI.Instance?.UpdateStatus("로비 화면으로 전환됨!");

        // 메인 로비 브금 재생
        LobbyBGM_Player.Instance?.PlayMainLobby();

        DebugManager.Log("[UIManager] SafeShowMainPanel() finished");
    }
}