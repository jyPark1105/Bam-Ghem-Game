﻿using UnityEngine;
using Firebase.Auth;
using Firebase.Extensions;
using TMPro;
using Firebase.Database;
using System;
using System.Collections;

public class FirebaseLoginManager : MonoBehaviour
{
    [Header("Login UI")]
    public TMP_InputField idInput;
    public TMP_InputField pwInput;

    private FirebaseAuth auth;
    private FirebaseUser user;
    private bool initialized = false;

    void OnEnable() => FirebaseInitializer.OnFirebaseReady += InitializeAuth;
    void OnDisable() => FirebaseInitializer.OnFirebaseReady -= InitializeAuth;

    private void InitializeAuth()
    {
        auth = FirebaseInitializer.AuthInstance;
        initialized = auth != null;
        string msg = initialized ? "Firebase Auth Ready." : "Firebase Auth init failed.";
        StatusTextUI.Instance.UpdateStatus(msg);
    }

    public void OnLoginButtonClicked()
    {
        if (!initialized)
        {
            StatusTextUI.Instance.UpdateStatus("Firebase not initialized yet.");
            return;
        }

        string email = idInput.text.Trim();
        string password = pwInput.text.Trim();

        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
        {
            StatusTextUI.Instance.UpdateStatus("이메일과 비밀번호를 입력해주세요.");
            return;
        }

        LobbyLoadingUI.Instance?.Show();

        auth.SignInWithEmailAndPasswordAsync(email, password)
            .ContinueWithOnMainThread(task =>
            {
                if (task.IsCanceled || task.IsFaulted)
                {
                    var ex = task.Exception?.Flatten().InnerException?.Message;
                    StatusTextUI.Instance.UpdateStatus("로그인 실패: " + ex);
                    LobbyLoadingUI.Instance?.HideAfterMinimum();
                    return;
                }

                user = task.Result.User;
                DebugManager.Log($"[Firebase] Login success: {user?.Email}");

                // 🔥 로그인 성공 플로우 시작
                StartCoroutine(LoginSuccessFlow(user));
            });
    }

    private IEnumerator LoginSuccessFlow(FirebaseUser user)
    {
        // 최소 로딩 연출
        yield return new WaitForSecondsRealtime(0.8f);

        // 유저 데이터 로드
        LoadUserDataFromFirebase(user);

        // 약간 대기 (데이터 반영 안정화)
        yield return new WaitForSecondsRealtime(0.5f);

        // 🔥 3초 보장 후 MainPanel 열기
        LobbyLoadingUI.Instance?.HideAfterMinimum(() =>
        {
            UIManager.Instance.HideAuthPanel();      // 🔥 Fade 시작 순간 Auth 끄고
            UIManager.Instance.SafeShowMainPanel();  // 🔥 Main 켜기
        });
    }

    private void LoadUserDataFromFirebase(FirebaseUser user)
    {
        DatabaseReference dbRef = FirebaseDatabase.DefaultInstance
            .RootReference.Child("Users").Child(user.UserId);

        dbRef.GetValueAsync().ContinueWith(task =>
        {
            if (task.IsFaulted || task.Result == null || !task.Result.Exists)
            {
                Debug.LogWarning("[Firebase] No user data found for this UID.");
                return;
            }

            var snapshot = task.Result;

            // 닉네임
            if (snapshot.Child("nickname").Exists)
            {
                string nickname = snapshot.Child("nickname").Value.ToString();
                UnityMainThreadDispatcher.Instance().Enqueue(() =>
                {
                    UserInfoUI.Instance.userNameText.text = nickname;
                });
            }

            // 재화
            if (snapshot.Child("currency").Exists)
            {
                var currency = snapshot.Child("currency");
                GameManager.Instance.totalCoin = Convert.ToInt32(currency.Child("coin").Value ?? 0);
                GameManager.Instance.totalTrophy = Convert.ToInt32(currency.Child("trophy").Value ?? 0);
                GameManager.Instance.totalExp = Convert.ToInt32(currency.Child("exp").Value ?? 0);
            }

            // 스테이지
            if (snapshot.Child("stages").Exists)
            {
                foreach (var stage in snapshot.Child("stages").Children)
                {
                    int stageNum = int.Parse(stage.Key);
                    var record = GameManager.Instance.GetStageRecord(stageNum);
                    if (record == null) continue;

                    record.isUnlocked = Convert.ToBoolean(stage.Child("isUnlocked").Value ?? false);
                    record.isCleared = Convert.ToBoolean(stage.Child("isCleared").Value ?? false);
                    record.starCount = Convert.ToInt32(stage.Child("starCount").Value ?? 0);

                    record.reward.coin = Convert.ToInt32(stage.Child("reward/coin").Value ?? 0);
                    record.reward.trophy = Convert.ToInt32(stage.Child("reward/trophy").Value ?? 0);
                    record.reward.exp = Convert.ToInt32(stage.Child("reward/exp").Value ?? 0);
                }
            }

            Debug.Log("[Firebase] User data loaded successfully.");
        });
    }
}