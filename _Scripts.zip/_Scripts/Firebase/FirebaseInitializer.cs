﻿using UnityEngine;
using Firebase;
using Firebase.Auth;
using System;
using System.Collections;

public class FirebaseInitializer : MonoBehaviour
{
    public static FirebaseInitializer Instance { get; private set; }

    public static event Action OnFirebaseReady;
    public static FirebaseAuth AuthInstance { get; private set; }
    public static FirebaseApp AppInstance { get; private set; }

    private bool isReady = false;

    void Awake()
    {
        Debug.Log("FirebaseInitializer instance: " + GetInstanceID());

        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        DebugManager.LogSilent("[FirebaseTrace] Awake() called.");
    }

    void Start()
    {
        if (!isReady)
            StartCoroutine(InitializeFirebaseCoroutine());
    }

    private IEnumerator InitializeFirebaseCoroutine()
    {
        DebugManager.LogSilent("[FirebaseTrace] Coroutine started.");

        if (DebugStateAnimator.Instance != null)
        {
            DebugStateAnimator.Instance.autoStart = false;
            DebugManager.LogSilent("[FirebaseTrace] DebugStateAnimator disabled during initialization.", LogType.Warning);
        }

        // ✅ 로딩창 활성화
        if (LoadingUI.Instance != null)
            LoadingUI.Instance.Show();
        else
            DebugManager.LogSilent("[FirebaseTrace] LoadingUI.Instance is null! (Check if LoadingUI prefab is in the scene)", LogType.Warning);

        int totalSteps = 9;
        int completed = 0;

        // ✅ 로깅 + 시각화 겸용 Step 함수
        void Step(string msg, bool success = true)
        {
            completed++;
            float p = Mathf.Clamp01(completed / (float)totalSteps);

            if (LoadingUI.Instance != null)
            {
                LoadingUI.Instance.SetProgress(p, msg);
            }

            string prefix = success
                ? "<color=#4AFF4A>[SUCCESS]: </color>"  // Green
                : "<color=#FF4A4A>[FAILED]: </color>";  // Red
            LogType type = success ? LogType.Info : LogType.Error;
            DebugManager.LogSilent($"[FirebaseTrace] Step {completed}/{totalSteps}: {prefix} → {msg}", type);
        }

#if UNITY_EDITOR
        Step("[EDITOR] Running in Unity Editor environment.");
        yield return new WaitForSeconds(1.5f);

        if (FirebaseApp.DefaultInstance != null)
        {
            DebugManager.LogSilent("[FirebaseTrace] [EDITOR] DefaultInstance exists, disposing...");
            FirebaseApp.DefaultInstance.Dispose();
        }

        try
        {
            var options = new AppOptions
            {
                ApiKey = "AIzaSyBo6d94Py6cudNzQJPdbgobRXWAs9yRuKI",
                AppId = "1:975791283115:web:572add02bfd915d41890ee",
                ProjectId = "ai-mech-brawl",
                MessageSenderId = "975791283115"
            };

            AppInstance = FirebaseApp.Create(options);
            Step("[EDITOR] FirebaseApp manually created.", true);
        }
        catch (Exception ex)
        {
            Step($"[EDITOR] FirebaseApp creation failed: {ex.Message}", false);
            LoadingUI.Instance?.SetProgress(1f, "Firebase initialization failed.");
            yield break;
        }

#else
    Step("[ANDROID] Running on Android device (runtime).");
    yield return new WaitForSeconds(1.5f);
#endif

        // 🔹 Dependency Check
        Step("Checking Firebase dependencies...");
        var dependencyTask = FirebaseApp.CheckAndFixDependenciesAsync();
        yield return new WaitUntil(() => dependencyTask.IsCompleted);

        if (dependencyTask.Result != DependencyStatus.Available)
        {
            Step($"Firebase dependencies not available: {dependencyTask.Result}", false);
            LoadingUI.Instance?.SetProgress(1f, "Firebase dependencies missing.");
            yield break;
        }
        else
        {
            Step("Dependencies resolved successfully.", true);
        }

        yield return new WaitForSeconds(1.5f);

        // 🔹 FirebaseApp instance 확인
        AppInstance ??= FirebaseApp.DefaultInstance;
        if (AppInstance == null)
        {
            Step("FirebaseApp.DefaultInstance is NULL", false);
            yield break;
        }
        Step("FirebaseApp instance confirmed.", true);
        yield return new WaitForSeconds(1.5f);

        // 🔹 Auth 초기화
        Step("Initializing Firebase Authentication...");
        float timeout = 8f;
        float elapsed = 0f;
        bool authSuccess = false;

        while (elapsed < timeout)
        {
            try
            {
                AuthInstance = FirebaseAuth.GetAuth(AppInstance);
                if (AuthInstance != null)
                {
                    authSuccess = true;
                    Step("FirebaseAuth connected successfully!", true);
                    break;
                }
            }
            catch (Exception e)
            {
                DebugManager.LogSilent($"[FirebaseTrace] Auth attempt failed: {e.Message}", LogType.Warning);
            }

            float progress = 0.6f + Mathf.Clamp01(elapsed / timeout) * 0.3f;
            LoadingUI.Instance?.SetProgress(progress, "Connecting Firebase Auth...");
            yield return new WaitForSeconds(0.5f);
            elapsed += 0.5f;
        }

        if (!authSuccess)
        {
            Step("FirebaseAuth initialization failed (timeout or error)", false);
            yield break;
        }

        yield return new WaitForSeconds(1.0f);

        // 🔹 완료
        isReady = true;
        Step("Firebase initialization complete!", true);
        yield return new WaitForSeconds(1.0f);

        DebugManager.LogSilent("[FirebaseTrace] Firebase + Auth fully initialized.");

        try
        {
            OnFirebaseReady?.Invoke();
            Step("OnFirebaseReady invoked successfully.", true);
        }
        catch (Exception e)
        {
            Step($"OnFirebaseReady exception: {e.Message}", false);
        }

        if (DebugStateAnimator.Instance != null)
        {
            DebugStateAnimator.Instance.autoStart = true;
            Step("DebugStateAnimator re-enabled after Firebase initialization.", true);
        }

        yield return new WaitForSeconds(1.0f);
        LoadingUI.Instance?.Hide();
    }

    public bool IsReady() => isReady;
}