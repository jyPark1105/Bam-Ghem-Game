using UnityEngine;
using TMPro;

public class EmailSelector : MonoBehaviour
{
    [Header("UI References")]
    public TMP_InputField idInputField;   // ID_InputField ����
    public TMP_Dropdown domainDropdown;   // DomainDropdown ����

    private readonly string[] domains = { "tarii.com", "bbok.com", "ggoong.com" };

    void Start()
    {
        // Dropdown �ʱ�ȭ
        domainDropdown.ClearOptions();
        domainDropdown.AddOptions(new System.Collections.Generic.List<string>(domains));

        // ID �Ǵ� Dropdown ���� �ٲ� ������ �̸�����/���� ����
        //idInputField.onValueChanged.AddListener(_ => PreviewEmail());
        //domainDropdown.onValueChanged.AddListener(_ => PreviewEmail());
    }

    /// <summary>
    /// �ϼ��� �̸��� ��ȯ (���̵� + ������)
    /// </summary>
    public string GetFullEmail()
    {
        string idPart = idInputField.text.Trim();
        string domainPart = domains[domainDropdown.value];
        if (string.IsNullOrEmpty(idPart))
            return "";

        return $"{idPart}@{domainPart}";
    }

    private void PreviewEmail()
    {
        string email = GetFullEmail();
        Debug.Log($"[Preview Email] {email}");
    }
}
