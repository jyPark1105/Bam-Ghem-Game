﻿using UnityEngine;
using Firebase;
using Firebase.Auth;
using Firebase.Extensions;
using TMPro;
using System.Text.RegularExpressions;

public class FirebaseAuthManager : MonoBehaviour
{
    [Header("UI References_Register")]
    public TMP_InputField idInput;
    public TMP_Dropdown domainDropdown;
    public TMP_InputField pwInput;
    public TMP_InputField pwCheckInput;
    public TMP_Text pwMatchText;

    private FirebaseAuth auth;
    private FirebaseUser user;
    private bool initialized = false;
    private bool pwMatched = false;

    private readonly string[] domains = { "tarii.com", "bbok.com", "ggoong.com" };

    void Update()
    {
        if (pwInput == null || pwCheckInput == null || pwMatchText == null)
            return;

        TrackPassword();
    }

    // =========================================================
    // 🔹 초기화 (FirebaseInitializer 이벤트 등록)
    // =========================================================
    void OnEnable()
    {
        DebugManager.LogSilent("[FirebaseTrace] AuthManager.OnEnable() - Subscribing to OnFirebaseReady");
        FirebaseInitializer.OnFirebaseReady += InitializeAuth;
    }

    void OnDisable()
    {
        DebugManager.LogSilent("[FirebaseTrace] AuthManager.OnDisable() - Unsubscribing from OnFirebaseReady");
        FirebaseInitializer.OnFirebaseReady -= InitializeAuth;
    }

    // =========================================================
    // 🔹 Firebase Auth 초기화
    // =========================================================
    private void InitializeAuth()
    {
        DebugManager.LogSilent("[FirebaseTrace] AuthManager.InitializeAuth() called.");
        auth = FirebaseInitializer.AuthInstance;

        if (auth == null)
        {
            StatusTextUI.Instance.UpdateStatus("Firebase Auth failed to initialize.");
            DebugManager.Log("[FirebaseTrace] ERROR: AuthInstance is null.", LogType.Error);
            return;
        }

        initialized = true;
        StatusTextUI.Instance.UpdateStatus("Firebase Auth Ready.");
        DebugManager.Log("[FirebaseTrace] Firebase Auth initialized successfully.");

#if UNITY_EDITOR
        DebugManager.LogSilent("[FirebaseTrace] [EDITOR] AuthManager running in Editor mode.");
#else
        DebugManager.LogSilent("[FirebaseTrace] [ANDROID] AuthManager running on Android device.");
#endif

        if (auth.CurrentUser != null)
            DebugManager.LogSilent("[FirebaseTrace] Existing user detected: " + auth.CurrentUser.Email);
        else
            DebugManager.LogSilent("[FirebaseTrace] No user currently signed in.");
    }

    public void OnRegisterButtonClicked()
    {
        if (!initialized)
        {
            StatusTextUI.Instance.UpdateStatus("Firebase not initialized yet.");
            return;
        }

        string id = idInput.text.Trim();
        string domain = domains[domainDropdown.value];
        string email = $"{id}@{domain}";
        string password = pwInput.text.Trim();
        string pwCheck = pwCheckInput.text.Trim();

        // =====================
        // --- ID Validation ---
        // =====================
        if (string.IsNullOrEmpty(id))
        {
            StatusTextUI.Instance.UpdateStatus("아이디를 입력해주세요.");
            return;
        }
        if (Regex.IsMatch(id, @"[^a-zA-Z0-9_]"))
        {
            StatusTextUI.Instance.UpdateStatus("아이디에 특수문자를 사용할 수 없습니다.");
            return;
        }

        // =====================
        // --- PW Validation ---
        // =====================
        if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(pwCheck))
        {
            StatusTextUI.Instance.UpdateStatus("비밀번호를 입력해주세요.");
            return;
        }
        if (password.Length < 6 || password.Length > 12)
        {
            StatusTextUI.Instance.UpdateStatus("비밀번호는 6~12자여야 합니다.");
            return;
        }

        bool hasLetter = Regex.IsMatch(password, @"[a-zA-Z]");
        bool hasDigit = Regex.IsMatch(password, @"[0-9]");
        bool hasSpecial = Regex.IsMatch(password, @"[!@#$%^&*(),.?""':{}|<>]");

        if (!hasLetter || !hasDigit || !hasSpecial)
        {
            StatusTextUI.Instance.UpdateStatus("비밀번호는 영문, 숫자, 특수문자를 각각 1개 이상 포함해야 합니다.");
            return;
        }
        if (password != pwCheck)
        {
            StatusTextUI.Instance.UpdateStatus("비밀번호가 일치하지 않습니다.");
            return;
        }

        // =========================
        // --- Firebase 회원가입 ---
        // =========================
        DebugManager.LogSilent($"[Firebase] Trying to register user: {email}");

        auth.CreateUserWithEmailAndPasswordAsync(email, password)
            .ContinueWithOnMainThread(task =>
            {
                if (task.IsCanceled)
                {
                    StatusTextUI.Instance.UpdateStatus("Register canceled.");
                    DebugManager.Log("[Firebase] Register canceled.");
                    return;
                }

                if (task.IsFaulted)
                {
                    var ex = task.Exception?.Flatten().InnerException?.Message;
                    StatusTextUI.Instance.UpdateStatus("Register failed: " + ex);
                    DebugManager.Log("[Firebase] Register failed: " + ex, LogType.Warning);
                    return;
                }

                user = task.Result.User;
                StatusTextUI.Instance.UpdateStatus("Registration successful!");
                DebugManager.Log($"[Firebase] Registration successful! User: {user?.Email}");
            });
    }

    /// <summary>
    /// 비밀번호 확인 함수 (PW + PW_Check)
    /// </summary>
    void TrackPassword()
    {
        string pw = pwInput.text;
        string pwCheck = pwCheckInput.text;

        if (string.IsNullOrEmpty(pw) && string.IsNullOrEmpty(pwCheck))
        {
            pwMatchText.text = "";
            pwMatched = false;
            return;
        }

        if (pw == pwCheck)
        {
            if (!pwMatched)
            {
                pwMatchText.text = "<color=#4FC12E>비밀번호가 일치합니다.</color>";
                pwMatched = true;
            }
        }
        else
        {
            if (pwMatched || string.IsNullOrEmpty(pwCheck))
            {
                pwMatchText.text = "<color=#E44A4A>비밀번호가 일치하지 않습니다.</color>";
                pwMatched = false;
            }
        }
    }
}