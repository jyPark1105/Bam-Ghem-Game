﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class DebugStateAnimator : MonoBehaviour
{
    public static DebugStateAnimator Instance { get; private set; }

    [Header("Target UI Elements")]
    public RectTransform condFrame;
    public Image statusFrame;

    [Header("Animation Settings")]
    public float duration = 1.0f;
    public float messageHoldTime = 2.0f;

    [Header("Behavior Settings")]
    public bool autoStart = true; // ✅ 새 옵션 (Firebase 로딩 중엔 끄기 위함)

    [Header("UI Sound")]
    public AudioSource audioSource;
    public AudioClip notifyClip;
    public bool playSound = true;

    private Coroutine messageRoutine;
    private Queue<string> messageQueue = new Queue<string>();

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        if (condFrame != null) condFrame.gameObject.SetActive(false);
        if (statusFrame != null) statusFrame.gameObject.SetActive(false);
    }

    private void OnEnable()
    {
        if (!autoStart) return; // 🔹 autoStart가 false면 자동 시작 안 함
    }

    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public void AnimateAll(string message)
    {
        if (!autoStart) return; // 🔹 로딩 중엔 메시지 표시 안 함
        if (string.IsNullOrEmpty(message)) return;

        messageQueue.Enqueue(message);
        if (messageRoutine == null)
            messageRoutine = StartCoroutine(MessageLoop());
    }

    private IEnumerator MessageLoop()
    {
        while (messageQueue.Count > 0)
        {
            string msg = messageQueue.Dequeue();
            yield return StartCoroutine(ShowMessageRoutine(msg));
        }
        messageRoutine = null;
    }

    // 🔹 StatusTextUI가 로딩 전엔 없을 수 있음 → 안전검사
    private IEnumerator ShowMessageRoutine(string message)
    {
        if (StatusTextUI.Instance == null || StatusTextUI.Instance.statusText == null)
            yield break;

        // 🔔 UI Sound
        if (playSound && audioSource != null && notifyClip != null)
            audioSource.PlayOneShot(notifyClip);

        StatusTextUI.Instance.UpdateStatus(message);

        if (condFrame != null && !condFrame.gameObject.activeSelf)
            condFrame.gameObject.SetActive(true);
        if (statusFrame != null && !statusFrame.gameObject.activeSelf)
            statusFrame.gameObject.SetActive(true);

        yield return MoveAndFade(100f, -5f, 0f, 1f, duration);
        yield return new WaitForSeconds(messageHoldTime);
        yield return MoveAndFade(-5f, 100f, 1f, 0f, duration);

        condFrame.gameObject.SetActive(false);
        statusFrame.gameObject.SetActive(false);
        StatusTextUI.Instance.ClearStatus();
    }
    
    private IEnumerator MoveAndFade(float startY, float endY, float startAlpha, float endAlpha, float time)
    {
        float elapsed = 0f;
        while (elapsed < time)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.Clamp01(elapsed / time);
            float newY = Mathf.Lerp(startY, endY, t);

            if (condFrame != null)
            {
                Vector3 pos = condFrame.anchoredPosition;
                pos.y = newY;
                condFrame.anchoredPosition = pos;
            }

            if (StatusTextUI.Instance?.statusText != null)
            {
                float newAlpha = Mathf.Lerp(startAlpha, endAlpha, t);
                Color c = StatusTextUI.Instance.statusText.color;
                c.a = newAlpha;
                StatusTextUI.Instance.statusText.color = c;
            }

            if (statusFrame != null)
            {
                float newAlpha = Mathf.Lerp(startAlpha, endAlpha, t);
                Color c = statusFrame.color;
                c.a = newAlpha;
                statusFrame.color = c;
            }

            yield return null;
        }
    }
}