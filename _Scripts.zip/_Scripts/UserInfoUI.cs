﻿using UnityEngine;
using TMPro;
using Firebase.Auth;
using Firebase.Database;
using Firebase;

public class UserInfoUI : MonoBehaviour
{
    public static UserInfoUI Instance { get; private set; }

    [Header("UI References")]
    public TMP_Text userNameText;

    // ✅ 프로젝트의 Realtime Database URL (싱가포르 리전)
    private const string DB_URL = "https://ai-mech-brawl-default-rtdb.asia-southeast1.firebasedatabase.app";

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    private void Start()
    {
        if (userNameText != null) userNameText.text = "이름 없음";
    }

    // ✅ 항상 URL을 지정해서 안전하게 DB 인스턴스 가져오기
    private FirebaseDatabase GetDatabase()
    {
        var app = FirebaseApp.DefaultInstance;

        // 옵션에 URL이 없으면 넣어주고,
        if (app.Options.DatabaseUrl == null)
            app.Options.DatabaseUrl = new System.Uri(DB_URL);

        // 그래도 기존 DefaultInstance가 null URL로 만들어졌을 수 있으니
        // URL로 직접 인스턴스를 받아 사용 (이게 가장 확실함)
        return FirebaseDatabase.GetInstance(DB_URL);
    }

    public void UpdateUserName()
    {
        var user = FirebaseAuth.DefaultInstance.CurrentUser;
        if (user == null)
        {
            SetName("이름 없음");
            Debug.LogWarning("[UserInfoUI] 로그인된 유저 없음.");
            return;
        }

        string uid = user.UserId;
        var db = GetDatabase(); // ✅ 여기서 강제 URL 경로 사용
        var dbRef = db.GetReference("users").Child(uid).Child("nickname");

        dbRef.GetValueAsync().ContinueWith(task =>
        {
            if (task.IsFaulted || !task.IsCompleted)
            {
                Debug.LogWarning("[UserInfoUI] 닉네임 로드 실패.");
                SetName("_NULL");
                return;
            }

            var snapshot = task.Result;
            string nickname = snapshot.Exists && !string.IsNullOrEmpty(snapshot.Value?.ToString())
                ? snapshot.Value.ToString()
                : "_NULL";

            UnityMainThreadDispatcher.Instance().Enqueue(() =>
            {
                SetName(nickname);
                Debug.Log($"[UserInfoUI] 닉네임 표시됨: {nickname}");
            });
        });
    }

    private void SetName(string name)
    {
        if (userNameText != null) userNameText.text = name;
    }
}