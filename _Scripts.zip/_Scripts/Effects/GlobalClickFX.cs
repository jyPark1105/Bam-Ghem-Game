﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Collections.Generic;

public class GlobalClickFX : MonoBehaviour
{
    private Camera uiCamera;
    private Canvas canvas;

    void Awake()
    {
        uiCamera = GameObject.Find("UICamera")?.GetComponent<Camera>();
        if (uiCamera == null)
        {
            uiCamera = Camera.main;
            Debug.LogWarning("[GlobalClickFX] UICamera not found, using MainCamera.");
        }

        canvas = Object.FindFirstObjectByType<Canvas>();
        DontDestroyOnLoad(gameObject);
    }

    void Update()
    {
        // 💻 마우스 클릭
        if (Input.GetMouseButtonDown(0))
            TryTriggerUIButtonFX(Input.mousePosition);

        // 📱 터치 (모바일)
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Began)
                TryTriggerUIButtonFX(touch.position);
        }
    }

    private void TryTriggerUIButtonFX(Vector2 screenPos)
    {
        if (EventSystem.current == null) return;

        PointerEventData pointerData = new PointerEventData(EventSystem.current)
        {
            position = screenPos
        };

        var results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(pointerData, results);

        foreach (var hit in results)
        {
            Button button = hit.gameObject.GetComponent<Button>();
            if (button != null)
            {
                // ✅ 버튼의 RectTransform 중심 위치 계산
                RectTransform rect = button.GetComponent<RectTransform>();
                Vector3 buttonCenterScreenPos = RectTransformUtility.WorldToScreenPoint(uiCamera, rect.position);

                // ✅ FX 재생
                if (ParticleController.Instance != null)
                    ParticleController.Instance.PlayFX("ButtonClickFX", buttonCenterScreenPos);

                break; // 첫 번째 버튼만 처리
            }
        }
    }
}