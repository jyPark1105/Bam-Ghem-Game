﻿using UnityEngine;

public class ParticleController : MonoBehaviour
{
    public static ParticleController Instance;
    public Camera uiCamera;
    private Canvas canvas;

    void Awake()
    {
        // ✅ 싱글톤 & 유지
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // 모든 씬에서 유지
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        // ✅ UICamera 자동 검색
        uiCamera = GameObject.Find("UICamera")?.GetComponent<Camera>();
        if (uiCamera == null)
        {
            Debug.LogWarning("[ParticleController] UICamera not found! Using MainCamera as fallback.");
            uiCamera = Camera.main;
        }

        // ✅ Canvas 연결 (Screen Space - Camera)
        canvas = GetComponentInParent<Canvas>();
        if (canvas != null)
        {
            canvas.worldCamera = uiCamera;
        }
    }

    /// <summary>
    /// 특정 화면 좌표에서 FX 재생 (예: 버튼 클릭 위치)
    /// </summary>
    public void PlayFX(string fxName, Vector3 screenPosition)
    {
        if (string.IsNullOrEmpty(fxName))
        {
            Debug.LogWarning("[ParticleController] FX name is empty!");
            return;
        }

        var fxTransform = transform.Find(fxName);
        if (fxTransform == null)
        {
            Debug.LogWarning($"[ParticleController] FX '{fxName}' not found under ParticleEffects.");
            return;
        }

        var fx = fxTransform.GetComponent<ParticleSystem>();
        if (fx == null)
        {
            Debug.LogWarning($"[ParticleController] No ParticleSystem found on '{fxName}'!");
            return;
        }

        // ✅ 스크린 좌표 → UI 월드 좌표 변환
        Vector3 worldPos = screenPosition;
        if (canvas != null)
        {
            RectTransformUtility.ScreenPointToWorldPointInRectangle(
                canvas.transform as RectTransform,
                screenPosition,
                uiCamera,
                out worldPos
            );
        }

        // ✅ 파티클 위치 세팅 후 재생
        fxTransform.position = worldPos;
        fx.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        fx.Play();

        Debug.Log($"[ParticleController] Played FX '{fxName}' at {worldPos}");
    }
}